﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    class Casino
    {
        List<List<Tile>> casinoMap;
        Rectangle pokerTable;
        Texture2D pokerTableTexture;
        public enum Direction { up, down, left, right};
        MapReader casinoMapReader;
        
        public Casino(ContentManager Content)
        {
            casinoMapReader = new MapReader(@"Content/Casino/casinoLayout.txt", Content);
            casinoMap = casinoMapReader.tiles;
        }


        public void move(Direction direction)
        {
            KeyboardState kb = Keyboard.GetState(PlayerIndex.One);
            GamePadState gp = GamePad.GetState(PlayerIndex.One);

            if(direction == Direction.right && casinoMap[0][casinoMap[0].Count - 1].rect.X > 700 && Input.right(kb, gp))
            {
                for(int i = 0; i < casinoMap.Count; i++)
                {
                    for(int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.X -= 5;
                    }
                }
            }

            
            if (direction == Direction.left && casinoMap[0][0].rect.X < 0 && Input.left(kb, gp))
            {
                for (int i = 0; i < casinoMap.Count; i++)
                {
                    for (int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.X += 5;
                    }
                }
            }
            
            if (direction == Direction.up && casinoMap[0][0].rect.Y < 0 && Input.up(kb, gp))
            {
                for (int i = 0; i < casinoMap.Count; i++)
                {
                    for (int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.Y += 5;
                    }
                }
            }
            //Console.WriteLine(casinoMapRect[casinoMapRect.GetLength(0) - 1, 0].Y);
            if (direction == Direction.down && casinoMap[casinoMap.Count-2][0].rect.Y > 500 && Input.down(kb, gp))
            {
                for (int i = 0; i < casinoMap.Count; i++)
                {
                    for (int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.Y -= 5;
                    }
                }
            }
        }

        public Boolean collision(Rectangle feet)
        {
            Boolean collision = false;
            for(int i = 0; i < casinoMap.Count; i++)
            {
                for(int j = 0; j < casinoMap[i].Count; j++)
                {
                    Rectangle currRect = casinoMap[i][j].rect;
                    if(feet.Intersects(currRect) && casinoMap[i][j].isObstacle)
                    {
                        collision = true;
                    }
                }
            }
            return collision;
        }

        public void Draw(SpriteBatch sb)
        {
            sb.Begin();
            for(int i = 0; i < casinoMap.Count; i++)
            {
                for(int j = 0; j < casinoMap[i].Count; j++)
                {
                    Texture2D currText = casinoMap[i][j].texture;
                    Rectangle currRect = casinoMap[i][j].rect;
                    sb.Draw(currText, currRect, Color.White);
                }
            }
            sb.End();
            
        }
    }
}
