﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class PokerPlayer
    {
        private string name;
        public int initialBalance;
        private int balance;
        public int currentBet;
        private int handsWon;
        private string catchphrase;
        private Vector2 location;
        private bool cpu;
        private bool allIn;
        public Card[] holeCards;
        public int raiseBy;

        public PokerPlayer(string name, int balance)
        {
            this.name = name;
            this.balance = balance;
            this.initialBalance = balance;
            cpu = false;
        }
        public PokerPlayer(string name, int balance, bool cpu)
        {
            this.name = name;
            this.balance = balance;
            this.initialBalance = balance;
            this.cpu = cpu;
        }
        public void addHoleCards(Card[] holeCards)
        {
            this.holeCards = holeCards;
        }
        public void reset()
        {
            currentBet = 0;
            allIn = false;
            holeCards = new Card[2];
        }
        /// <summary>
        /// adds earnings to balance and says catchprase
        /// </summary>
        /// <param name="earnings"> money won in the hand </param>
        public void wonHand(int earnings)
        {
            balance += earnings;
            handsWon++;
        }
        /// <summary>
        /// can player buy into a game
        /// </summary>
        /// <param name="buyIn"> the buyin for the game </param>
        /// <returns></returns>
        public bool canBuyIn(int buyIn)
        {
            return balance >= buyIn;
        }
        /// <summary>
        /// returns whether or not the player has funds to continue in the game
        /// </summary>
        /// <param name="tableMinimum"> the minimum balance to stay at the table </param>
        /// <returns></returns>
        public bool canContinue(int tableMinimum)
        {
            return balance > tableMinimum;
        }
        /// <summary>
        /// get a bet from the player
        /// </summary>
        /// <param name="highBet"></param>
        /// <returns> a number equal to betToMatch to call
        ///           a number higher than betToMatch to raise
        ///           -1 to fold
        ///           0 to check
        /// </returns>
        public int getBet(int betToMatch)
        {
            if (allIn)
            {
                return -5;
            }
            if (cpu)
            {
                currentBet += betToMatch;
                balance -= betToMatch;
                if (balance == 0)
                {
                    allIn = true;
                    return -5;
                }
                return betToMatch;
            }
            bool canCheck = betToMatch == 0;
            KeyboardState kb = Keyboard.GetState();
            if (kb.IsKeyDown(Keys.F)) //fold
            {
                return -1;
            }
            if (kb.IsKeyDown(Keys.C)) //call
            {
                if (canCheck)
                {
                    return 0;
                }
                currentBet += betToMatch;
                balance -= betToMatch;
                return betToMatch;
            }
            if (kb.IsKeyDown(Keys.R) && raiseBy != -1) //raise
            {
                do
                {
                    raiseBy = -1;
                    Form1 form = new Form1();
                    form.ShowDialog();
                    while (form.IsDisposed == false)
                    {

                    }
                    int bet = form.raiseBy;
                    if (bet > balance - betToMatch)
                    {
                        Console.WriteLine("Insufficient funds.");
                        continue;
                    }
                    if (bet + betToMatch == balance) allIn = true;
                    int tot = bet + betToMatch;
                    currentBet += tot;
                    balance -= tot;
                    raiseBy = 0;
                    return bet;
                } while (true);
            }
            return -2;
        }
        /// <summary>
        /// called to force the player to bet a small or big blind
        /// </summary>
        /// <param name="blind"> the blind the player is forced to bet </param>
        public void setBet(int blind)
        {
            currentBet += blind;
            balance -= blind;
        }
        public string getName() { return name; }
        public int getBalance() { return balance; }
        public int getHandsWon() { return handsWon; }
        public string getCatchphrase() { return catchphrase; }
        public Vector2 getLocation() { return location; }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

        }
        public override string ToString()
        {
            return this.name;
        }
    }
}