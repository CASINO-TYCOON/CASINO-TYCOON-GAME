﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;


namespace CasinoTycoon_v1._1
{
    class Animation
    {

        /*
         * The way this works is that the frameCounter will count the amount of frames
         * and the switch frame tells when to switch the frame
         */
        int frameCounter;
        int switchFrame;

        // Dimensions for drawing the rectangle
        int width;
        int height;

        // Is the character moving?
        public bool Active
        {
            get { return active; }
            set { active = value; }
        }
        bool active;

        Vector2 amountofFrames;

        // The spriteSheet
        Texture2D image;
        public Texture2D AnimationImage
        {
            set { image = value; }
        }

        //What part of the image we are drawing from
        Rectangle sourceRect;

        // Current Frame
        Vector2 currentFrame;
        public Vector2 CurrentFrame
        {
            get { return currentFrame; }
            set { currentFrame = value; }
        }

        // Current Position
        Vector2 position;
        public Vector2 Position
        {
            get { return position; }
            set { position = value; }
        }

        // How many sprites horizontally are in the sprite sheet
        public int FrameWidth
        {
            get { return image.Width / (int)amountofFrames.X; }
        }

        // How many sprites vertically are in the sprite sheet
        public int FrameHeight
        {
            get { return image.Height / (int)amountofFrames.Y; }
        }

        public Animation(Vector2 position, Vector2 Frames, int w, int h)
        {
            active = false;
            switchFrame = 100;
            Position = position;
            amountofFrames = Frames;
            width = w;
            height = h;
        }

        public void Update(GameTime gameTime)
        {
            if (active)
            {
                frameCounter += (int)gameTime.ElapsedGameTime.TotalMilliseconds;
            }
            else
            {
                frameCounter = 0;
                currentFrame.X = FrameWidth;
            }
            if (frameCounter >= switchFrame)
            {
                frameCounter = 0;
                currentFrame.X += FrameWidth;
                if (currentFrame.X >= image.Width)
                {
                    currentFrame.X = 0;
                }
            }
            sourceRect = new Rectangle((int)currentFrame.X, (int)currentFrame.Y*FrameHeight, FrameWidth, FrameHeight);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(image, new Rectangle((int)Position.X, (int)Position.Y, width, height), sourceRect, Color.White);
        }
    }
}
