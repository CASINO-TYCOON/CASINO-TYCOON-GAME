﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CasinoTycoon_v1._1
{
    public partial class PokerExit : Form
    {
        public bool yess;

        public PokerExit()
        {
            InitializeComponent();
        }

        private void yes_Click(object sender, EventArgs e)
        {
            yess = true;
            Dispose(true);
            Close();
        }

        private void no_Click(object sender, EventArgs e)
        {
            yess = false;
            Dispose(true);
            Close();
        }

        private void PokerExit_FormClosing(object sender, FormClosingEventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
