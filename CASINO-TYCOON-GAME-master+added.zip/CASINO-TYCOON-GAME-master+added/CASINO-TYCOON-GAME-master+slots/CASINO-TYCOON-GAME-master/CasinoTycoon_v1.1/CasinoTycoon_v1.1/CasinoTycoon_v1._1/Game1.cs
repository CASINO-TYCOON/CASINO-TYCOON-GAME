using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        SpriteFont spritefont1;
        SpriteFont font1;
        public enum GameState { poker, slots, frogger, blackjack, start, play, pause, end};
        GameState state;
        Texture2D intro;
        Rectangle introRect;
        Texture2D introTitle;
        Rectangle introTitleRect;
        int screenWidth;
        int screenHeight;

        public enum Direction { up, down, left, right};
        //Direction direction;

        Casino casino;



        PokerGame pokerGame;
        KeyboardState oldKB;

        SlotMachine slotMachine;

        Frogger frogger;

        Player player;

        bool formOpen = false;

        bool canMovePlayer;

        Blackjack bj;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content"; graphics.PreferredBackBufferWidth = 700; graphics.PreferredBackBufferHeight = 600; graphics.ApplyChanges();
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            screenWidth = GraphicsDevice.Viewport.Width;
            screenHeight = GraphicsDevice.Viewport.Height;
            player = new Player(screenWidth, screenHeight);
            state = GameState.start;
            introRect = new Rectangle(0, 0, screenWidth, screenHeight);
            introTitleRect = new Rectangle(200, 165, 320, 130);
            casino = new Casino( Content);
            canMovePlayer = true;
            IsMouseVisible = true;
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spritefont1 = Content.Load<SpriteFont>("SpriteFont1");
            // TODO: use this.Content to load your game content here
            intro = Content.Load<Texture2D>("Intro/introScreen");
            introTitle = Content.Load<Texture2D>("Intro/introTitle");
            font1 = Content.Load<SpriteFont>("SpriteFont2");
            player.loadContent(Content);
            LoadPoker();
            LoadSlots();
            //LoadBlackjack();
            
        }
        /// <summary>
        /// builds the assets for poker
        /// </summary>
        private void LoadPoker()
        {
            Card[] cards = new Card[52];
            char[] suits = new char[4];
            suits[0] = 'c'; suits[1] = 'd';
            suits[2] = 'h'; suits[3] = 's';
            int count = 0;
            for (int j = 0; j < 4; j++)
            {
                char currentSuit = suits[j];
                for (int i = 1; i < 14; i++)
                {
                    if (i < 10)
                        cards[count] = (new Card(Content.Load<Texture2D>("Poker/Cards/" + currentSuit + "0" + i),
                                            currentSuit, i));
                    else
                    {
                        cards[count] = (new Card(Content.Load<Texture2D>("Poker/Cards/" + currentSuit + i),
                                            currentSuit, i));
                    }
                    count++;
                }
            }
            string basePath = "Poker/Cards/card back ";
            string[] colors = { "black", "blue", "green", "orange", "purple", "red" };
            Texture2D[] backs = new Texture2D[colors.Length];
            for (int i = 0; i < backs.Length; i++)
            {
                backs[i] = Content.Load<Texture2D>(basePath + colors[i]);
            }
            Random rand = new Random();
            Deck pokerDeck = new Deck(cards, backs[rand.Next(backs.Length)]);
            pokerGame = new PokerGame(Content.Load<Texture2D>("Poker/Table/pokertable1"), 4, 1000, Content.Load<SpriteFont>("Poker/pokerFont"), spriteBatch,
                                      700, 500, pokerDeck, Content.Load<SpriteFont>("Poker/smallFont"),
                                      Content.Load<Texture2D>("Poker/Table/dealerbutton"));
            pokerGame.addSounds(Content.Load<SoundEffect>("Poker/Sounds/bg music(softer)"), Content.Load<SoundEffect>("Poker/Sounds/card dealt"),
                                Content.Load<SoundEffect>("Poker/Sounds/gather winnings"), Content.Load<SoundEffect>("Poker/Sounds/place bet"));
        }
        /// <summary>
        /// builds the assets for slots
        /// </summary>
        private void LoadSlots()
        {
            slotMachine = new SlotMachine(Content.Load<Texture2D>("Slots/slotMachine"), Content.Load<Texture2D>("Slots/reel sheets"), spriteBatch,
                                          GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height, Content.Load<Texture2D>("Slots/ball"),
                                          Content.Load<Texture2D>("Slots/rod"), Content.Load<Texture2D>("Slots/slotmachine payouts2"), 10,
                                          Content.Load<SpriteFont>("Slots/font"));
        }

        /// <summary>
        /// builds the assets for frogger
        /// </summary>
        private void LoadFrogger()
        {
            graphics.PreferredBackBufferWidth = 700;
            graphics.PreferredBackBufferHeight = 800;
            graphics.ApplyChanges();
            frogger = new Frogger(GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height, Content.Load<Texture2D>("Frogger/frogger bg"),
                                   Content.Load<Texture2D>("Frogger/froggerspritesheet"), this.spriteBatch,
                                   Content.Load<Texture2D>("Frogger/frogger intro credits0"), Content.Load<Texture2D>("Frogger/frogger intro credits1"),
                                   Content.Load<Texture2D>("Frogger/frogger gameover"), Content.Load<Texture2D>("Frogger/frogger time bar"),
                                   Content.Load<Texture2D>("Frogger/frogger time word"));
            graphics.PreferredBackBufferWidth = 700;
            graphics.PreferredBackBufferHeight = 850;
            graphics.ApplyChanges();
            frogger.setScreen(GraphicsDevice.Viewport.Bounds);
            frogger.addSounds(Content.Load<SoundEffect>("Frogger/coin in"), Content.Load<SoundEffect>("Frogger/frogger song"), Content.Load<SoundEffect>("Frogger/plunk"),
                              Content.Load<SoundEffect>("Frogger/squash"), Content.Load<SoundEffect>("Frogger/time running out"), Content.Load<SoundEffect>("Frogger/hop"));
        }

        public void LoadBlackjack()
        {
            Card[] cards = new Card[52];
            char[] suits = new char[4];
            suits[0] = 'c'; suits[1] = 'd';
            suits[2] = 'h'; suits[3] = 's';
            int count = 0;
            for (int j = 0; j < 4; j++)
            {
                char currentSuit = suits[j];
                for (int i = 1; i < 14; i++)
                {
                    if (i < 10)
                        cards[count] = (new Card(Content.Load<Texture2D>("Poker/Cards/" + currentSuit + "0" + i),
                                            currentSuit, i));
                    else
                    {
                        cards[count] = (new Card(Content.Load<Texture2D>("Poker/Cards/" + currentSuit + i),
                                            currentSuit, i));
                    }
                    count++;
                }
            }
            string basePath = "Poker/Cards/card back ";
            string[] colors = { "black", "blue", "green", "orange", "purple", "red" };
            Texture2D[] backs = new Texture2D[colors.Length];
            for (int i = 0; i < backs.Length; i++)
            {
                backs[i] = Content.Load<Texture2D>(basePath + colors[i]);
            }
            Random rand = new Random();
            Deck bjdeck = new Deck(cards, backs[rand.Next(backs.Length)]);
            bj = new Blackjack(Content.Load<Texture2D>("Blackjack/bjboard"), bjdeck, spriteBatch, font1);
        }
        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            KeyboardState kb = Keyboard.GetState();
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here
            if(state == GameState.start)
            {
                //Allow for GamePad support
                if(kb.IsKeyDown(Keys.Enter))
                {
                    state = GameState.play;
                }
            }

            if(state == GameState.play)
            {

                player.Update(gameTime, casino);
            
                if (player.position.X + player.width >= screenWidth)
                {
                    casino.move(Casino.Direction.right);
                }
                if (player.position.X <= 0)
                {
                    casino.move(Casino.Direction.left);
                }
                if (player.position.Y <= 0)
                {
                    casino.move(Casino.Direction.up);
                }
                if (player.position.Y + player.height >= screenHeight)
                {
                    casino.move(Casino.Direction.down);
                }
            }
            if (state == GameState.poker)
            {
                if (kb.IsKeyDown(Keys.Space) && !oldKB.IsKeyDown(Keys.Space))
                {
                    pokerGame.Update(gameTime);
                }
                if (pokerGame.betting)
                {
                    pokerGame.Update(gameTime);
                }
                if (pokerGame.gameOver)
                {
                    state = GameState.play;
                    player.adjustMoney(pokerGame.userWinnings);
                }
                if (kb.IsKeyDown(Keys.Escape) && !oldKB.IsKeyDown(Keys.Escape) && !formOpen)
                {
                    PokerExit form = new PokerExit();
                    formOpen = true;
                    form.ShowDialog();
                    if (form.yess)
                    {
                        pokerGame.endGame();
                        player.adjustMoney(pokerGame.userWinnings);
                    }
                    formOpen = false;
                }
            }
            else
            {
                if (kb.IsKeyDown(Keys.P) && !oldKB.IsKeyDown(Keys.P) && state != GameState.start && !formOpen)
                {
                    PokerEnter form = new PokerEnter();
                    formOpen = true;
                    form.ShowDialog();
                    if (form.yess)
                    {
                        graphics.PreferredBackBufferWidth = 700;
                        graphics.PreferredBackBufferHeight = 500;
                        graphics.ApplyChanges();
                        pokerGame.startGame();
                        state = GameState.poker;
                    }
                    formOpen = false;
                }
            }
            if (kb.IsKeyDown(Keys.N) && !oldKB.IsKeyDown(Keys.N) && state != GameState.start)
            {
                graphics.PreferredBackBufferWidth = 700;
                graphics.PreferredBackBufferHeight = 500;
                graphics.ApplyChanges();
                slotMachine.setScreenDimensions(GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
                state = GameState.slots;
                IsMouseVisible = true;
            }
            if (state == GameState.slots)
            {
                if (kb.IsKeyDown(Keys.Escape) && !oldKB.IsKeyDown(Keys.Escape))
                {
                    state = GameState.play;
                    Random rand = new Random();
                    int winnings = slotMachine.gameOver();
                    Console.WriteLine("You won $"+winnings+" from slot machine "+(char)rand.Next(65,91)+(rand.Next(10)+1));
                    player.adjustMoney(winnings);
                    graphics.PreferredBackBufferWidth = 700; graphics.PreferredBackBufferHeight = 600; graphics.ApplyChanges();
                }
                else
                {
                    slotMachine.Update(gameTime);
                }
            }
            if (state == GameState.frogger)
            {
                if (kb.IsKeyDown(Keys.Escape) && !oldKB.IsKeyDown(Keys.Escape))
                {
                    state = GameState.play;
                    graphics.PreferredBackBufferWidth = 700; graphics.PreferredBackBufferHeight = 600; graphics.ApplyChanges();
                }
                frogger.Update(gameTime);
            }
            if (state == GameState.play && kb.IsKeyDown(Keys.F))
            {
                LoadFrogger();
                state = GameState.frogger;
            }
            if(state == GameState.play && kb.IsKeyDown(Keys.B))
            {
                LoadBlackjack();
                bj.launch();
                state = GameState.blackjack;
            }
            if (state == GameState.blackjack)
                bj.Update(gameTime);
            if (kb.IsKeyDown(Keys.Escape) && state == GameState.blackjack)
            {
                state = GameState.play;
                bj.reset();
            }
                
            oldKB = kb;
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here
            switch(state)
            {
                case GameState.start:
                    drawStart();
                    break;
                case GameState.play:
                    drawPlay();
                    break;
                //case GameState.pause:
                //    drawPause();
                //    break;
                //case GameState.end:
                //    drawEnd();
                //    break;
                case GameState.poker:
                    pokerGame.Draw(gameTime);
                    break;
                case GameState.slots:
                    slotMachine.Draw(gameTime);
                    break;
                case GameState.frogger:
                    frogger.Draw(gameTime);
                    break;
                case GameState.blackjack:
                    bj.Draw(gameTime);
                    break;
            }
            base.Draw(gameTime);
        }

        public void drawStart()
        {
            spriteBatch.Begin();
            spriteBatch.Draw(intro, introRect, Color.White);
            spriteBatch.Draw(introTitle, introTitleRect, Color.White);
            spriteBatch.DrawString(spritefont1, "Press Enter to Start", new Vector2(450, 525), Color.White);
            spriteBatch.End();
        }
        public void drawPlay()
        {
            casino.Draw(spriteBatch);
            spriteBatch.Begin();
            player.Draw(spriteBatch);
            spriteBatch.End();
        }
    }
}
