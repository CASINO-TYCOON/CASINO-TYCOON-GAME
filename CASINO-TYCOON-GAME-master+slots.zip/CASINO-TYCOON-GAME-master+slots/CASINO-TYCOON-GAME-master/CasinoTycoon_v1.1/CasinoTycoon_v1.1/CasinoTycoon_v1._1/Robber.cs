﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    class Robber
    {
        /// <summary>
        /// At the current phase robbers should be functional albeit stupid. If there is extra development time we can make them smarter.
        /// </summary>

        public static int SPEED = 2; //How fast the robber moves (adjust this at testing phase)

        enum robberState
        {
            IDLE, //The player is not close enough, moves randomly
            CHASE, //Follow the player
            RESET, //Used if the robber catches the player, moves him away before returning to idle
        }

        private robberState status; //Determines the behavior of the robber

        private Rectangle rect;
        private Texture2D currentText; //The texture that will be displayed at any given frame
        private Texture2D[] animationFrames; //Stores all the textures for animating the robber

        Tile[] tiles;

        Player player; //The player object used to determine behavior

        public Robber(Rectangle rect2, Texture2D[] animationFrames2, Tile[] tiles2, Player player2)
        {
            status = robberState.IDLE;
            currentText = animationFrames2[0];
            animationFrames = animationFrames2;
            tiles = tiles2;
            player = player2;
        }

        private void moveHorizontally(int distance)
        {
            Vector2 center = new Vector2((rect.X + rect.Width / 2) + distance, rect.Y + rect.Height / 2);
            Tile endingTile = null;

            for (int i = 0; i < tiles.Length; i++)
            {
                //Find the tile that the robber would be within
                if (center.X >= tiles[i].rect.X && center.X < tiles[i].rect.X + tiles[i].rect.Width && center.Y >= tiles[i].rect.Y && center.Y < tiles[i].rect.Y + tiles[i].rect.Height) //Placeholder logic until tile class is implemented
                {
                    endingTile = tiles[i];
                }
            }

            if (endingTile != null && !endingTile.isObstacle) //Move robber if it is possible
            {
                rect.X += distance;
            }
        }

        private void moveVertically(int distance)
        {
            Vector2 center = new Vector2(rect.X + rect.Width / 2, (rect.Y + rect.Height / 2) + distance);
            Tile endingTile = null;

            for (int i = 0; i < tiles.Length; i++)
            {
                //Find the tile that the robber would be within
                if (center.X >= tiles[i].rect.X && center.X < tiles[i].rect.X + tiles[i].rect.Width && center.Y >= tiles[i].rect.Y && center.Y < tiles[i].rect.Y + tiles[i].rect.Height) //Placeholder logic until tile class is implemented
                {
                    endingTile = tiles[i];
                }
            }

            if (endingTile != null && !endingTile.isObstacle) //Move robber if it is possible
            {
                rect.Y += distance;
            }
        }

        private void update()
        {
            if (status == robberState.IDLE) //Simple random movements. Further updates can make them smarter but for now they just go anywhere.
            {
                Random rand = new Random();

                int RNG = rand.Next(3);
                if (RNG == 1)
                {
                    moveHorizontally(SPEED);
                }
                if (RNG == 1)
                {
                    moveHorizontally(SPEED * -1);
                }
                if (RNG == 1)
                {
                    moveVertically(SPEED);
                }
                if (RNG == 1)
                {
                    moveVertically(SPEED * -1);
                }
                if (playerNear())
                {
                    status = robberState.CHASE;
                }
            }
            if (status == robberState.CHASE) //Moves toward the player. They will realistically move twice each frame (once horizontally, once vertically)
            {
                if (player.position.Y > rect.Y)
                {
                    moveVertically(SPEED);
                }
                if (player.position.Y < rect.Y)
                {
                    moveVertically(SPEED * -1);
                }
                if (player.position.X > rect.X)
                {
                    moveHorizontally(SPEED);
                }
                if (player.position.X < rect.X)
                {
                    moveHorizontally(SPEED * -1);
                }
                if (!playerNear())
                {
                    status = robberState.IDLE;
                }
                if (Math.Abs(player.position.X - rect.X) < 5 && Math.Abs(player.position.Y - rect.Y) < 5)
                {
                    status = robberState.RESET;
                }
            }
            if (status == robberState.RESET) //Moves away from the player. Based on the player's movements it may be possible to get them stuck in a corner, this might need to be adressed later
            {
                if (player.position.Y > rect.Y)
                {
                    moveVertically(SPEED * 2); //They go faster than normal so the player can't catch them during a reset phase
                }
                if (player.position.Y < rect.Y)
                {
                    moveVertically(SPEED * -2);
                }
                if (player.position.X < rect.X)
                {
                    moveHorizontally(SPEED * 2);
                }
                if (player.position.X > rect.X)
                {
                    moveHorizontally(SPEED * -2);
                }
                if (!playerNear()) //Once they are far away they will again become aggressive
                {
                    status = robberState.IDLE;
                }
            }
        }

        private bool playerNear() //returns true if the player is near enough to chase, false otherwise
        {
            int Xproximity = Math.Abs((int)player.position.X - rect.X);
            int Yproximity = Math.Abs((int)player.position.Y - rect.Y);

            if (Xproximity < 200 && Yproximity < 200)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

