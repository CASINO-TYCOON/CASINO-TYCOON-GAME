﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    /*
     *  1.  To use this class to read files:
     *  
     *  You have to make an instance of this class
     *  when you do, the map will load
     *  to get the map make a List<List<Tile>> variable (2D list of tiles)
     *  and set it equal to the [instance].tiles
     *  
     *  Look in the casino class' constructor for an example
     *  
     *  
     *  2.  To make images compatible with this class:
     *  
     *  Make sure that if the tile is passable it is in COMPLETE lower case
     *  For example: casino floor.png, you can have spaces in image names
     *  If you want the tile to be impassable make sure it is in COMPLETE upper case
     *  For example: SLOTS.png, you can have spaces in image names
     *  
     *  
     */
    class MapReader
    {
        public List<List<Tile>> tiles;
        List<Tile> tempMap;
        List<bool> obstacles;
        List<Texture2D> textures;
        String path;
        int lineIndex;
        enum Loadstate { Texture, Map};
        Loadstate state;

        public MapReader(String p, ContentManager Content)
        {
            path = p;
            lineIndex = 0;
            tiles = new List<List<Tile>>();
            tempMap = new List<Tile>();
            textures = new List<Texture2D>();
            obstacles = new List<bool>();
            load(Content);
        }

        /// <summary>
        /// Loads the .txt map file as a 2D Tile List
        /// </summary>
        /// <param name="Content"> To Load the textures </param>
        public void load(ContentManager Content)
        {
            String line;
            String[] lineArray;
            try
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    while (!reader.EndOfStream)
                    {
                        line = reader.ReadLine().TrimEnd(' ').TrimStart(' ');
                        while (line.IndexOf("  ") != -1)
                            line = line.Replace("  ", " ");

                        if (line.Contains("[Textures]"))
                        {
                            state = Loadstate.Texture;
                            continue;
                        }
                        else if (line.Contains("[Map]"))
                        {
                            state = Loadstate.Map;
                            continue;
                        }

                        switch (state)
                        {
                            case Loadstate.Texture:
                                if (line != String.Empty)
                                {
                                    textures.Add(Content.Load<Texture2D>(line));
                                    lineArray = line.Split('/');
                                    if (!lineArray[lineArray.Length - 1].Equals(lineArray[lineArray.Length - 1].ToLower()))
                                    {
                                        obstacles.Add(true);
                                    }
                                    else
                                    {
                                        obstacles.Add(false);
                                    }
                                }    
                                break;

                            case Loadstate.Map:
                                lineArray = line.Split(' ');

                                for (int i = 0; i < lineArray.Length; i++)
                                {
                                    int temp = int.Parse(lineArray[i]);
                                    tempMap.Add(new Tile(textures[temp], new Rectangle(i * 50, lineIndex * 50, 50, 50), obstacles[temp]));
                                }
                                tiles.Add(tempMap);
                                lineIndex++;
                                tempMap = new List<Tile>();
                                break;
                        }               
                    }
                }
            }
            catch (Exception e)
            {
                //Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }
}

    }
}
