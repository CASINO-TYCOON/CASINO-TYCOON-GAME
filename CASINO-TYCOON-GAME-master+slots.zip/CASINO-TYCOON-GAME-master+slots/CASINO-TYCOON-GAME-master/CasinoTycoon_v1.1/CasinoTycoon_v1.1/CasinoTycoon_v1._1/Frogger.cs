﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Frogger
    {
        private Rectangle endFrogSource = new Rectangle(104, 176, 16, 16);
        private Rectangle[] flyPoss = new Rectangle[]
        {
            new Rectangle(32, 35, 30, 30),
            new Rectangle(181, 35, 30, 30),
            new Rectangle(333, 35, 30, 30),
            new Rectangle(477, 35, 30, 30),
            new Rectangle(633, 35, 30, 30),
        };
        private Rectangle[] topPoss = new Rectangle[]
        {
            new Rectangle(22, 25, 45, 45),
            new Rectangle(173, 25, 45, 45),
            new Rectangle(323, 25, 45, 45),
            new Rectangle(471, 25, 45, 45),
            new Rectangle(623, 25, 45, 45),
        };
        private Rectangle[] turtleSourceRecs = new Rectangle[]
        {
            new Rectangle(49,148,13,9), //fins in
            new Rectangle(72,147,15,11), //fins out
            new Rectangle(96,147,15,11), //swimming
            new Rectangle(131,147,10,10), //partly submerged
            new Rectangle(153,146,14,13) //fully submerged
        };
        private Rectangle[] turtleSourcesSub = new Rectangle[]
        {
            new Rectangle(96,147,15,11), //swimming
            new Rectangle(131,147,10,10), //partly submerged
            new Rectangle(153,146,14,13) //fully submerged
        };
        private Rectangle[] turtleSourcesReg = new Rectangle[]
        {
            new Rectangle(49,148,13,9), //fins in
            new Rectangle(72,147,15,11), //fins out
            new Rectangle(96,147,15,11) //swimming
        };
        private Rectangle deadSymbolSource = new Rectangle(17, 112, 15, 16);
        private Rectangle logSource = new Rectangle(115, 307, 42, 10);
        private int[] ys = new int[]
        {
            692, 635, 575, 505, 452
        };
        private int[] heights = new int[]
        {
            35, 30, 30, 50, 35
        };
        private int[] velocities = new int[]
        {
            3, -1, 2, -3, 1
        };
        private int[] widths = new int[5];
        private Rectangle[] carSourceRecs = new Rectangle[]
        {
            new Rectangle(16, 337, 16, 14), //yellow racecar
            new Rectangle(105, 339, 15, 10), //pink car
            new Rectangle(41, 338, 14, 12), //white car
            new Rectangle(67, 339, 27, 10), //truck
            new Rectangle(128, 337, 16, 14) //gray racecar
        };
        private int[] logVelocities = new int[]
        {
            1, 2, 3
        };
        private int[] logYs = new int[]
        {
            270, 210, 90
        };
        private int[] turtleVels = new int[]
        {
            -2, -1
        };
        private int[] turtleYs = new int[]
        {
            325, 150
        };
        private int[] frogSpaces = new int[]
        {
            125, 150
        };
        private int[] spaces = new int[5];
        private int screenWidth;
        private int screenHeight;
        private Rectangle wholeScreen;
        private Texture2D background;
        private Texture2D sheet;
        private SpriteBatch spriteBatch;
        private Frog frog;
        private List<Car>[] cars;
        private List<Log>[] logs;
        private List<Turtles>[] turtles;
        private int addSubmerging;
        private int died;
        private Rectangle deadFrogPos;
        private Fly fly;
        private List<int> gotTo; //indexes of where frog got to on other side

        public Frogger(int screenWidth, int screenHeight, Texture2D background, Texture2D spriteSheet, SpriteBatch spriteBatch)
        {
            this.sheet = spriteSheet;
            this.spriteBatch = spriteBatch;
            this.background = background;
            this.frog = new Frog(new Rectangle(369, 750, 40, 40), spriteSheet, spriteBatch, screenWidth, screenHeight);
            this.wholeScreen = new Rectangle(0, 0, screenWidth, screenHeight);
            this.screenWidth = screenWidth;
            this.screenHeight = screenHeight;
            Random rand = new Random();
            for (int i = 0; i < this.spaces.Length; i++)
            {
                spaces[i] = rand.Next(150, 250);
            }
            this.fly = new Fly(sheet, spriteBatch, flyPoss);
            this.gotTo = new List<int>();
            this.setUpRoad();
            this.setUpRiver();
        }
        public void Update(GameTime gameTime)
        {
            if (died > 0)
            {
                died--;
            }
            Rectangle frogPos = frog.Update(gameTime);
            if (frogPos.Y == 30)
            {
                for (int i = 0; i < flyPoss.Length; i++)
                {
                    if (frogPos.Intersects(flyPoss[i]))
                    {
                        gotTo.Add(i);
                        fly.removeOption(i);
                        resetFrog();
                        return;
                    }
                }
                frogDied(frogPos);
                return;
            }
            for (int i = 0; i < cars.Length; i++)
            {
                if (i % 2 == 0)
                {
                    if (cars[i][0].pos.X >= spaces[i])
                    {
                        cars[i].Insert(0, new Car(carSourceRecs[i], new Rectangle(-widths[i], ys[i], widths[i], heights[i]), screenWidth, screenHeight, velocities[i]));
                    }
                }
                else
                {
                    Car temp = cars[i][cars[i].Count - 1];
                    if (temp.pos.X + temp.pos.Width <= screenWidth - spaces[i])
                    {
                        cars[i].Add(new Car(carSourceRecs[i], new Rectangle(screenWidth, ys[i], widths[i], heights[i]), screenWidth, screenHeight, velocities[i]));
                    }
                }
                for (int j = cars[i].Count - 1; j >= 0; j--)
                {
                    if (cars[i][j].pos.Intersects(frogPos))
                    {
                        frogDied(frogPos);
                    }
                    if (cars[i][j].Update(gameTime))
                    {
                        cars[i].RemoveAt(j);
                    }
                }
            }
            bool frogOn = false;
            for (int i = 0; i < logs.Length; i++)
            {
                if (logs[i][0].pos.X >= spaces[i])
                {
                    Rectangle temp = logs[i][0].pos;
                    logs[i].Insert(0, new Log(logSource, new Rectangle(-temp.Width, logYs[i], temp.Width, temp.Height), screenWidth, screenHeight, logVelocities[i]));
                }
                for (int j = logs[i].Count - 1; j >= 0; j--)
                {
                    if (!frogOn && logs[i][j].pos.Intersects(frogPos))
                    {
                        frogOn = true;
                        frog.velocity = logs[i][j].velocity;
                        //frogPos = logs[i][j].findPlaceForFrog(frogPos);
                    }
                    if (logs[i][j].Update(gameTime))
                    {
                        logs[i].RemoveAt(j);
                    }
                }
            }
            for (int i = 0; i < turtles.Length; i++)
            {
                int numOfTurtles = i == 0 ? 3 : 2;
                Rectangle temp = turtles[i][turtles[i].Count - 1].turtles[numOfTurtles - 1];
                if (temp.X + temp.Width <= screenWidth - frogSpaces[i])
                {
                    if (addSubmerging == 0)
                    {
                        turtles[i].Add(new Turtles(new Vector2(screenWidth + frogSpaces[i], turtleYs[i]), turtleVels[i], numOfTurtles, spriteBatch, sheet, turtleSourcesSub, true));
                        addSubmerging = 4;
                    }
                    else
                    {
                        turtles[i].Add(new Turtles(new Vector2(screenWidth + frogSpaces[i], turtleYs[i]), turtleVels[i], numOfTurtles, spriteBatch, sheet, turtleSourcesReg, false));
                    }
                    addSubmerging--;
                }
                for (int j = 0; j < turtles[i].Count; j++)
                {
                    if (!frogOn && turtles[i][j].contains(frogPos))
                    {
                        frogOn = true;
                        frog.velocity = turtles[i][j].velocity;
                    }
                    turtles[i][j].Update(gameTime);
                }
            }
            if (frogPos.Y < 390 && (750-frogPos.Y) % 60==0 && !frogOn && !frog.isJumping())
            {
                frogDied(frogPos);
            }
            if (frogOn)
            {
                frog.pos = frogPos;
            }
            else
            {
                frog.velocity = 0;
            }
            fly.Update(gameTime);
        }
        public void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(background, wholeScreen, Color.White);
            for (int i = 0; i < cars.Length; i++)
            {
                for (int j = 0; j < cars[i].Count; j++)
                {
                    Car temp = cars[i][j];
                    spriteBatch.Draw(sheet, temp.pos, temp.source, Color.White);
                }
            }
            for (int i = 0; i < logs.Length; i++)
            {
                for (int j = 0; j < logs[i].Count; j++)
                {
                    Log temp = logs[i][j];
                    spriteBatch.Draw(sheet, temp.pos, temp.source, Color.White);
                }
            }
            for (int i = 0; i < turtles.Length; i++)
            {
                for (int j = 0; j < turtles[i].Count; j++)
                {
                    turtles[i][j].Draw(gameTime);
                }
            }
            if (died > 0)
            {
                spriteBatch.Draw(sheet, deadFrogPos, deadSymbolSource, Color.White);
            }
            for (int i = 0; i < gotTo.Count; i++)
            {
                spriteBatch.Draw(sheet, topPoss[gotTo[i]], endFrogSource, Color.White);
            }
            frog.Draw(gameTime);
            fly.Draw(gameTime);
            spriteBatch.End();
        }
        private void setUpRoad()
        {
            cars = new List<Car>[5];
            for (int i = 0; i < ys.Length; i++)
            {
                cars[i] = new List<Car>();
                int x = new Random().Next(20);
                Rectangle source = carSourceRecs[i];
                float factor = (float)heights[i] / source.Height;
                int width = (int)(source.Width * factor);
                widths[i] = width;
                int height = heights[i];
                int velocity = i % 2 == 0 ? -2 : 2;
                while (x < screenWidth)
                {
                    cars[i].Add(new Car(source, new Rectangle(x, ys[i], width, height), screenWidth, screenHeight, velocities[i]));
                    x += width+spaces[i];
                }
            }
        }
        private void setUpRiver()
        {
            logs = new List<Log>[3];
            Random rand = new Random();
            for (int i = 0; i < logs.Length; i++)
            {
                logs[i] = new List<Log>();
                int x = rand.Next(20);
                int width = (rand.Next(3)+2)*51; //51 is the moveByX for the frog
                int height = 40;
                while (x < screenWidth)
                {
                    logs[i].Add(new Log(logSource, new Rectangle(x, logYs[i], width, height), screenWidth, screenHeight, logVelocities[i]));
                    x += width + spaces[rand.Next(spaces.Length)];
                }
            }
            turtles = new List<Turtles>[2];
            addSubmerging = 4;
            for (int i = 0; i < turtles.Length; i++)
            {
                int numOfTurtles = i == 0 ? 3 : 2;
                turtles[i] = new List<Turtles>();
                Vector2 start = new Vector2(rand.Next(20), turtleYs[i]);
                while (start.X < screenWidth)
                {
                    if (addSubmerging == 0)
                    {
                        turtles[i].Add(new Turtles(start, turtleVels[i], numOfTurtles, spriteBatch, sheet, turtleSourcesSub, true));
                        addSubmerging = 4;
                    }
                    else
                    {
                        turtles[i].Add(new Turtles(start, turtleVels[i], numOfTurtles, spriteBatch, sheet, turtleSourcesReg, false));
                    }
                    start.X += turtles[i][0].WIDTH*numOfTurtles+frogSpaces[i];
                    addSubmerging--;
                }
            }
        }
        private void frogDied(Rectangle frogPos)
        {
            died = 30;
            deadFrogPos = frogPos;
            if (frog.loseLife())
            {
                gameOver();
            }
        }
        private void resetFrog()
        {
            frog.reset();
        }
        private void gameOver()
        {

        }
    }
}
