﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Log
    {
        public Rectangle pos;
        private int[] frogPoss;
        public Rectangle source;
        private int screenWidth;
        private int screenHeight;
        public int velocity;
        private bool movingRight;

        public Log(Rectangle source, Rectangle pos, int screenWidth, int screenHeight, int velocity)
        {
            this.source = source;
            this.pos = pos;
            frogPoss = new int[pos.Width / 51]; //51 is moveByX in frog
            int x = pos.X;
            this.screenWidth = screenWidth;
            this.screenHeight = screenHeight;
            this.velocity = velocity;
            this.movingRight = velocity > 0;
        }
        public bool Update(GameTime gameTime)
        {
            this.pos.X += velocity;
            int x = pos.X;
            for (int i = 0; i < frogPoss.Length; i++)
            {
                frogPoss[i] = x;
                x += 51;
            }
            return movingRight ? pos.X > screenWidth : pos.X + pos.Width < 0;
        }
        public Rectangle findPlaceForFrog(Rectangle frogPos)
        {
            int closestX = -1;
            int smallestDistance = screenWidth;
            for (int i = 0; i < frogPoss.Length; i++)
            {
                int temp = Math.Abs(frogPoss[i] - frogPos.X);
                if (temp < smallestDistance)
                {
                    smallestDistance = temp;
                    closestX = i;
                }
            }
            frogPos.X = frogPoss[closestX];
            return frogPos;
        }
    }
}
