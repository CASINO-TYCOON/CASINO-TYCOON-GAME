﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Input
    {

        public static bool right(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.Right) || kb.IsKeyDown(Keys.D) || gp.ThumbSticks.Left.X > 0);
        }

        public static bool left(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.Left) || kb.IsKeyDown(Keys.A) || gp.ThumbSticks.Left.X < 0);
        }

        public static bool up(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.Up) || kb.IsKeyDown(Keys.W) || gp.ThumbSticks.Left.Y < 0);
        }

        public static bool down(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.Down) || kb.IsKeyDown(Keys.S) || gp.ThumbSticks.Left.Y > 0);
        }

        public static bool shift(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.LeftShift) || gp.IsButtonDown(Buttons.LeftShoulder));
        }
    }
}
