﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    public enum Suit
    {
        clubs, diamonds, hearts, spades
    }
    class Card : IComparable
    {
        private Texture2D image;
        private Suit suit;
        private int value;

        public Card(Texture2D image, char suit, int value)
        {
            this.image = image;
            switch (suit)
            {
                case 'c':
                    this.suit = Suit.clubs; break;
                case 'd':
                    this.suit = Suit.diamonds; break;
                case 'h':
                    this.suit = Suit.hearts; break;
                case 's':
                    this.suit = Suit.spades; break;
            }
            this.value = value;
        }
        public Texture2D getImage() { return image; }
        public Suit getSuit() { return suit; }
        public int getValue() { return value; }
        public override String ToString()
        {
            String s = "";
            if (value < 11 && value > 1)
                s += value + " of ";
            else
            {
                switch (value)
                {
                    case 1:
                        s += "Ace (" + value + ") of "; break;
                    case 11:
                        s += "Jack (" + value + ") of "; break;
                    case 12:
                        s += "Queen (" + value + ") of "; break;
                    case 13:
                        s += "King (" + value + ") of "; break;
                }
            }
            s += suit.ToString();
            return s;
        }
        public int CompareTo(object obj)
        {
            int comp = this.value.CompareTo(((Card)obj).getValue());
            if (this.value == 1)
            {
                return comp == 0 ? 0 : 1;
            }
            else if (((Card)obj).getValue() == 1)
            {
                return -1;
            }
            else
            {
                return comp;
            }
        }
    }
}