﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    public enum Hand
    {
        HighCard, OnePair, TwoPair, ThreeOfAKind, Straight, Flush, FullHouse, FourOfAKind, StraightFlush, RoyalFlush
    }
    //to later implement full screen, must add a update screenwidth/screenheight and related variables
    class PokerGame
    {
        enum State
        {
            WaitForStart, Beginning, Preflop, Flop, Turn, River, HandOver
        }
        private const double CardAspectRatio = 1063.0 / 768;
        private Texture2D table;
        private PokerPlayer[] players; //0-user/bottom 1-cpu/right 2-cpu/top 3-cpu/left
        private Rectangle[,] pLocations; //parallel array of player hole card locations
        private int[] bets;
        private int[] betToMatch;
        private Vector2[] nums; //parallel array of player balance and bet locations
        private Vector2[] names; //parallel array of player name locations
        private Card[] communityCards;
        private Rectangle[] ccLocations; //parallel array of community card locations
        private int buyIn;
        private SpriteFont font;
        private int pot;
        private int screenWidth, screenHeight;
        private Vector2 center;
        private Rectangle wholeScreen;
        private Deck baseDeck;
        private int tableMinimum;
        private State gameState;
        private SpriteFont smallFont;
        private Texture2D dealerButton;
        private int currentDealer;
        private int smallBlind;
        private int bigBlind;
        public bool betting;
        private int currentBet;
        private int returnTo;
        private Rectangle dealer;
        private KeyboardState oldKB;
        private bool show;
        public bool gameOver;
        public bool xray;
        public SpriteBatch spriteBatch;

        public PokerGame(Texture2D table, int numOfPlayers, int buyIn, SpriteFont font, SpriteBatch spriteBatch, int screenWidth, int screenHeight, Deck baseDeck, SpriteFont smallFont,
                         Texture2D dealerButton)
        {
            this.table = table;
            this.players = new PokerPlayer[numOfPlayers];
            this.pLocations = new Rectangle[numOfPlayers, 2];
            this.names = new Vector2[numOfPlayers];
            this.bets = new int[numOfPlayers];
            this.nums = new Vector2[numOfPlayers];
            this.betToMatch = new int[numOfPlayers];
            this.communityCards = new Card[5];
            this.buyIn = buyIn;
            this.font = font;
            this.screenWidth = screenWidth;
            this.screenHeight = screenHeight;
            this.center = new Vector2(screenWidth / 2 - 50, (int)(screenHeight / 3.5)-4);
            this.wholeScreen = new Rectangle(0, 0, screenWidth, screenHeight);
            this.ccLocations = new Rectangle[5];
            this.smallFont = smallFont;
            this.dealerButton = dealerButton;
            this.dealer = new Rectangle(screenWidth - 120, screenHeight - 70, 70, 70);
            this.currentDealer = 0;
            this.currentBet = 3;
            this.returnTo = 3;
            int space = 5; //pixel space between each card
            int width = (int)(screenWidth / 2 / 5);
            int height = (int)(width * CardAspectRatio);
            int x = screenWidth / 3 - (int)Math.Ceiling(space * 2.5 * communityCards.Length);
            int y = screenHeight / 2 - height / 2;
            this.smallBlind = 5;
            this.bigBlind = 10;
            for (int i = 0; i < ccLocations.Length; i++)
            {
                ccLocations[i] = new Rectangle(x, y, width, height);
                x += width + space;
            }
            double userFactor = 1.1;
            Vector2 userHoleCardSize = new Vector2((int)(width * userFactor), (int)(height * userFactor)); //x-width, y-height
            int userSpace = (int)(space * userFactor);
            double cpuFactor = 0.75;
            Vector2 cpuHoleCardSize = new Vector2((int)(width * cpuFactor), (int)(height * cpuFactor)); //x-width, y-height
            int cpuSpace = (int)(space * cpuFactor);
            int[] offsets = new int[] { 35, 20, 30, 20 };
            pLocations[0, 0] = new Rectangle(screenWidth / 2 - userSpace / 2 - (int)userHoleCardSize.X, screenHeight - offsets[0] - (int)userHoleCardSize.Y,
                                          (int)userHoleCardSize.X, (int)userHoleCardSize.Y);
            names[0] = new Vector2(pLocations[0, 0].X, pLocations[0, 0].Y + pLocations[0, 0].Height);
            pLocations[0, 1] = new Rectangle(screenWidth / 2 + userSpace / 2, screenHeight - offsets[0] - (int)userHoleCardSize.Y,
                                           (int)userHoleCardSize.X, (int)userHoleCardSize.Y);
            nums[0] = new Vector2(pLocations[0, 1].X + pLocations[0, 1].Width + userSpace * 2, pLocations[0, 1].Y + pLocations[0, 1].Height / 3);
            pLocations[1, 0] = new Rectangle(screenWidth - (int)(cpuHoleCardSize.X * 2) - cpuSpace - offsets[1], screenHeight / 2 - (int)cpuHoleCardSize.Y / 2,
                                             (int)cpuHoleCardSize.X, (int)cpuHoleCardSize.Y);
            nums[1] = new Vector2(pLocations[1, 0].X, pLocations[1, 0].Y + pLocations[1, 0].Height);
            names[1] = new Vector2(pLocations[1, 0].X, pLocations[1, 0].Y - 30);
            pLocations[1, 1] = new Rectangle(pLocations[1, 0].X + (int)(cpuHoleCardSize.X) + cpuSpace, screenHeight / 2 - (int)cpuHoleCardSize.Y / 2,
                                              (int)cpuHoleCardSize.X, (int)cpuHoleCardSize.Y);
            pLocations[2, 0] = new Rectangle(screenWidth / 2 - cpuSpace / 2 - (int)cpuHoleCardSize.X, offsets[2],
                                           (int)cpuHoleCardSize.X, (int)cpuHoleCardSize.Y);
            names[2] = new Vector2(pLocations[2, 0].X, 0);
            pLocations[2, 1] = new Rectangle(screenWidth / 2 + cpuSpace / 2, offsets[2],
                                           (int)cpuHoleCardSize.X, (int)cpuHoleCardSize.Y);
            nums[2] = new Vector2(pLocations[2, 1].X + pLocations[2, 1].Width + cpuSpace * 2, pLocations[2, 0].Y + pLocations[2, 0].Height / 3);
            pLocations[3, 0] = new Rectangle(offsets[3], screenHeight / 2 - (int)cpuHoleCardSize.Y / 2,
                                             (int)cpuHoleCardSize.X, (int)cpuHoleCardSize.Y);
            nums[3] = new Vector2(pLocations[3, 0].X, pLocations[3, 0].Y + pLocations[1, 0].Height);
            names[3] = new Vector2(pLocations[3, 0].X, pLocations[3, 0].Y - 30);
            pLocations[3, 1] = new Rectangle(pLocations[3, 0].X + (int)(cpuHoleCardSize.X) + cpuSpace, screenHeight / 2 - (int)cpuHoleCardSize.Y / 2,
                                              (int)cpuHoleCardSize.X, (int)cpuHoleCardSize.Y);
            this.tableMinimum = this.bigBlind;
            this.baseDeck = baseDeck;
            this.spriteBatch = spriteBatch;
            this.gameState = State.WaitForStart;
            addPlayers();
        }
        public void startGame()
        {
            gameState = State.Beginning;
        }
        private void addPlayers()
        {
            players[0] = new PokerPlayer("user", 1000);
            for (int i = 1; i < players.Length; i++)
            {
                players[i] = new PokerPlayer("cpu " + i, 1000, true);
            }
        }
        public void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.X))
            {
                xray = true;
            }
            else
            {
                xray = false;
            }
            if (gameState == State.Beginning)
            {
                show = false;
                resetForNextHand();
                if (gameOver)
                {
                    return;
                }
                for (int i = 0; i < players.Length; i++)
                {
                    players[i].addHoleCards(new Card[] { baseDeck.getCard(), baseDeck.getCard() });
                }
                pot = 0;
                int sb = (currentDealer + 1) % players.Length;
                int bb = (currentDealer + 2) % players.Length;
                bets[sb] = smallBlind;
                betToMatch[sb] = bigBlind - smallBlind;
                bets[bb] = bigBlind;
                for (int i = 0; i < bets.Length; i++)
                {
                    if (i != sb && i != bb)
                    {
                        betToMatch[i] = bigBlind;
                    }
                }
                betToMatch[bb] = 0;
                players[sb].setBet(smallBlind);
                players[bb].setBet(bigBlind);
                pot += smallBlind;
                pot += bigBlind;
                returnTo = bb;
                currentBet = (bb+1)% players.Length;
                Console.WriteLine("\nPreflop betting::: ");
                Console.WriteLine(players[sb] + " has placed the small blind of $" + smallBlind);
                Console.WriteLine(players[bb] + " has placed the big blind of $" + bigBlind);
                gameState++;
            }
            if (betting)
            {
                getBet();
            }
            else if (gameState == State.Preflop)
            {
                betting = true;
            }
            else if (gameState == State.Flop)
            {
                Console.WriteLine("\nFlop betting::: ");
                communityCards[0] = baseDeck.getCard();
                communityCards[1] = baseDeck.getCard();
                communityCards[2] = baseDeck.getCard();
                betting = true;
            }
            else if (gameState == State.Turn)
            {
                Console.WriteLine("\nTurn betting::: ");
                communityCards[3] = baseDeck.getCard();
                betting = true;
            }
            else if (gameState == State.River)
            {
                Console.WriteLine("\nRiver betting::: ");
                communityCards[4] = baseDeck.getCard();
                betting = true;
            }
            else if (gameState == State.HandOver)
            {
                List<Card>[] lists = new List<Card>[players.Length];
                int[] hands = new int[players.Length];
                for (int i = 0; i < players.Length; i++)
                {
                    if (bets[i] != -1)
                    {
                        Object[] temp = bestHand(players[i].holeCards);
                        hands[i] = (int)temp[0];
                        lists[i] = (List<Card>)temp[1];
                    }
                }
                int[] indexOfBestARR = bestHandOfHands(lists, hands);
                int indexOfBest = -1;
                Console.WriteLine();
                if (indexOfBestARR.Length == 1)
                {
                    indexOfBest = indexOfBestARR[0];
                    Console.WriteLine(players[indexOfBest] + " won $" + pot + " with a " + (Hand)hands[indexOfBest]);
                    players[indexOfBest].wonHand(pot);
                }
                else
                {
                    Console.Write("The following players all had the same hand (" + (Hand)hands[indexOfBestARR[0]] + "):: ");
                    for (int i = 0; i < indexOfBestARR.Length; i++)
                    {
                        indexOfBest = indexOfBestARR[i];
                        Console.Write(players[indexOfBest]);
                        players[indexOfBest].wonHand(pot / 2);
                        if (i != indexOfBestARR.Length - 1)
                        {
                            Console.Write(" | ");
                        }
                    }
                    Console.WriteLine("\nThey won $" + pot / indexOfBestARR.Length + " each.");
                }
                for (int k = 0; k < lists.Length; k++)
                {
                    Console.Write(players[k] + "::");
                    List<Card> list = lists[k];
                    if (list != null)
                    {
                        for (int i = 0; i < list.Count; i++)
                        {
                            Console.Write(" " + list[i].ToString());
                            if (i != list.Count - 1)
                            {
                                Console.Write(" | ");
                            }
                        }
                        Console.WriteLine(" || " + (Hand)hands[k]);
                    }
                    else
                    {
                        Console.WriteLine(" folded ");
                    }
                }
                show = true;
                gameState = State.Beginning;
            }
        }
        public void endGame()
        {
            int ib = players[0].initialBalance;
            int b = players[0].getBalance();
            Console.WriteLine("\n\n\n\n\nYou started with $" + ib + " and ended with $" + b + " (Profit of $" + (b - ib) + ")\n\n\n\n\n");
            gameOver = true;
        }
        private void resetForNextHand()
        {
            if (!players[0].canContinue(tableMinimum))
            {
                endGame();
                return;
            }
            players[0].reset();
            for (int i = 1; i < players.Length; i++)
            {
                if (!players[i].canContinue(tableMinimum))
                {
                    Console.WriteLine(players[i] + " ran out of money.");
                    players[i] = new PokerPlayer("cpu "+i+".0", buyIn, true);
                    Console.WriteLine(players[i] + " has bought in to the game.");
                }
                else
                {
                    players[i].reset();
                }
            }
            currentDealer = (currentDealer + 1) % players.Length;
            bets = new int[players.Length];
            resetCommunityCards();
        }
        private void resetCommunityCards()
        {
            communityCards = new Card[5];
        }
        private void getBet()
        {
            int i = currentBet;
            int playersAllIn = 0;
            int folded = 0;
            int playersInGame = players.Length;
            for (int j = 0; j < players.Length; j++)
            {
                if (players[j].isAllIn())
                {
                    playersAllIn++;
                    betToMatch[j] = 0;
                }
                if (bets[j] == -1)
                {
                    folded++;
                    playersInGame--;
                }
            }
            if (playersAllIn == playersInGame || folded == 3)
            {
                betting = false;
                gameState++;
                return;
            }
            if (bets[i] == -1 || players[i] == null)
            {
                currentBet = (currentBet + 1) % players.Length;
                return;
            }
            KeyboardState kb = Keyboard.GetState();
            int btm = betToMatch[i];
            int bet = players[i].getBet(btm, kb, oldKB);
            if (bet == -2 || bet == -7)
            {
                oldKB = kb;
                return;
            }
            if (bet == -5)
            {
                Console.WriteLine(players[currentBet] + " is all in.");
                currentBet = (currentBet + 1) % players.Length;
                return;
            }
            currentBet = (currentBet + 1) % players.Length;
            bets[i] += bet;
            if (btm == 0 && bet == 0)
            {
                Console.WriteLine(players[i] + " checked.");
                betToMatch[i] = 0;
            }
            else if (bet > btm)
            {
                if (players[i].isAllIn())
                {
                    Console.WriteLine(players[i] + " is all in.");
                }
                else
                {
                    Console.WriteLine(players[i] + " raised $" + (bet - btm));
                }
                returnTo = i;
                for (int j = 0; j < betToMatch.Length; j++)
                {
                    if (j != i)
                    {
                        betToMatch[j] += (bet - btm);
                    }
                    else
                    {
                        betToMatch[j] = 0;
                    }
                }
                pot += bet;
            }
            else if (bet == -1)
            {
                Console.WriteLine(players[i] + " folded.");
                bets[i] = -1;
            }
            else if (bet == btm)
            {
                if (players[i].isAllIn())
                {
                    Console.WriteLine(players[i] + " is all in.");
                    pot += bet;
                }
                else
                {
                    Console.WriteLine(players[i] + " called.");
                    betToMatch[i] = 0;
                    pot += bet;
                }
            }
            if (playersAllIn == playersInGame - 1)
            {
                betting = false;
                gameState++;
                return;
            }
            if (currentBet == returnTo)
            {
                betting = false;
                gameState++;
            }
            oldKB = kb;
        }
        public void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(table, this.wholeScreen, Color.White);
            spriteBatch.DrawString(font, "Pot: $" + pot, center, Color.White);
            for (int i = 0; i < communityCards.Length; i++)
            {
                Card temp = communityCards[i];
                if (temp != null)
                {
                    spriteBatch.Draw(temp.getImage(), ccLocations[i], Color.White);
                }
            }
            for (int i = 0; i < players.Length; i++)
            {
                Card[] holeCards = players[i].holeCards;
                if ((i == 0 && holeCards != null) || show)
                {
                    spriteBatch.Draw(holeCards[0].getImage(), pLocations[i, 0], Color.White);
                    spriteBatch.Draw(holeCards[1].getImage(), pLocations[i, 1], Color.White);
                }
                else
                {
                    spriteBatch.Draw(baseDeck.backOfCards, pLocations[i, 0], Color.White);
                    spriteBatch.Draw(baseDeck.backOfCards, pLocations[i, 1], Color.White);
                    if (xray)
                    {
                        spriteBatch.Draw(holeCards[0].getImage(), pLocations[i, 0], new Color(255, 255, 255, 10));
                        spriteBatch.Draw(holeCards[1].getImage(), pLocations[i, 1], new Color(255, 255, 255, 10));
                    }
                }
                spriteBatch.DrawString(font, players[i].getName(), names[i], Color.White);
                if (bets[i] == -1)
                {
                    spriteBatch.DrawString(smallFont, "\n\n(folded)", nums[i], Color.White);
                }
                spriteBatch.DrawString(smallFont, "Bet: $" + players[i].currentBet + "\nBalance: $" + players[i].getBalance(), nums[i], Color.White);
                spriteBatch.Draw(dealerButton, dealer, Color.White);
                spriteBatch.DrawString(smallFont, players[currentDealer].ToString(), new Vector2(dealer.X + dealer.Width + 1, dealer.Y + dealer.Height / 3), Color.White);
            }
            spriteBatch.End();
        }
        public void addPlayer(PokerPlayer player)
        {
            for (int i = 0; i < players.Length; i++)
            {
                if (players[i] == null)
                {
                    players[i] = player;
                    return;
                }
            }
        }
        private int[] bestHandOfHands(List<Card>[] lists, int[] hands)
        {
            int[] indexOfBest = new int[] { -1 };
            int bestHan = -1;
            for (int i = 0; i < hands.Length; i++)
            {
                if (hands[i] > bestHan)
                {
                    indexOfBest = new int[1];
                    indexOfBest[0] = i;
                    bestHan = hands[i];
                }
                else if (hands[i] == bestHan)
                {
                    if (lists[i] != null)
                    {
                        int comp = compareHands(lists[i], lists[indexOfBest[0]]);
                        if (comp == 1)
                        {
                            indexOfBest = new int[1];
                            indexOfBest[0] = i;
                        }
                        else if (comp == 0)
                        {
                            int[] temp = indexOfBest;
                            indexOfBest = new int[indexOfBest.Length + 1];
                            for (int j = 0; j < temp.Length; j++)
                            {
                                if (temp[j] != -1)
                                {
                                    indexOfBest[j] = temp[j];
                                }
                            }
                            indexOfBest[indexOfBest.Length - 1] = i;
                        }
                    }
                }
            }
            return indexOfBest;
        }
        /// <summary>
        /// compares two hands who are the same(ex. both one pairs) to see which is better
        /// </summary>
        /// <param name="one"></param>
        /// <param name="two"></param>
        /// <returns></returns>
        private int compareHands(List<Card> one, List<Card> two)
        {
            for (int i = 0; i < one.Count; i++)
            {
                int compare = one[i].CompareTo(two[i]);
                if (compare != 0)
                {
                    return compare;
                }
            }
            return 0;
        }
        /// <summary>
        /// finds the best hand avaiable based on the holeCards passed in and the community cards
        /// </summary>
        /// <param name="holeCards"> a players hole cards to use with the community cards to find the best hand available </param>
        /// <returns></returns>
        private Object[] bestHand(Card[] holeCards)
        {
            /**
             * REMEMBER TO ADD THE COMMUNITY CARDS TO THE CARDS DICTIONARY IN AN EARLIER METHOD
             */
            List<Card> ret = new List<Card>();
            Card[] allCards = new Card[7];
            int[] values = new int[7];
            Suit[] suits = new Suit[7];
            for (int i = 0; i < communityCards.Length; i++)
            {
                values[i] = communityCards[i].getValue();
                suits[i] = communityCards[i].getSuit();
                allCards[i] = communityCards[i];
            }
            values[5] = holeCards[0].getValue(); suits[5] = holeCards[0].getSuit(); allCards[5] = holeCards[0];
            values[6] = holeCards[1].getValue(); suits[6] = holeCards[1].getSuit(); allCards[6] = holeCards[1];
            int[] hasStraight = containsStraight(values);
            int hasFlush = containsFlush(suits);
            Array.Sort(allCards);
            if (hasFlush != -1 && hasStraight == null)
            {
                for (int i = 6; i >= 0; i--)
                {
                    if ((int)allCards[i].getSuit() == hasFlush)
                    {
                        ret.Add(allCards[i]);
                    }
                    if (ret.Count == 5)
                    {
                        return new Object[] { Hand.Flush, ret };
                    }
                }
            }
            if (hasStraight != null)
            {
                int[] straightflush = containsStraightFlush(allCards);
                if (straightflush != null)
                {
                    for (int i = 0; i < allCards.Length; i++)
                    {
                        if (straightflush.Contains(allCards[i].getValue()) && (int)allCards[i].getSuit() == hasFlush)
                        {
                            ret.Add(allCards[i]);
                        }
                    }
                    if (straightflush.Contains(1) && straightflush.Contains(10) && straightflush.Contains(13))
                    {
                        return new Object[] { Hand.RoyalFlush, ret };
                    }
                    return new Object[] { Hand.StraightFlush, ret };
                }
                for (int i = 0; i < allCards.Length; i++)
                {
                    if (hasStraight.Contains(allCards[i].getValue()))
                    {
                        ret.Add(allCards[i]);
                    }
                    if (ret.Count == 5)
                    {
                        return new Object[] { Hand.Straight, ret };
                    }
                }
            }
            int[] occurences = new int[14];
            for (int i = 0; i < values.Length; i++)
            {
                occurences[values[i]]++;
            }
            for (int i = occurences.Length - 1; i >= 0; i--)
            {
                int val = occurences[i];
                if (val >= 4)
                {
                    ret = new List<Card>();
                    for (int j = 6; j >= 0; j--)
                    {
                        if (allCards[j].getValue() == i)
                        {
                            ret.Add(allCards[j]);
                        }
                        else if (j == 6)
                        {
                            ret.Add(allCards[j]);
                        }
                        else if (ret.Count == 4)
                        {
                            ret.Add(allCards[j]);
                        }
                        if (ret.Count == 5) return new Object[] { Hand.FourOfAKind, ret };
                    }
                }
            }
            for (int i = occurences.Length - 1; i >= 0; i--)
            {
                int val = occurences[i];
                if (val == 3)
                {
                    for (int j = 6; j >= 0; j--)
                    {
                        if (allCards[j].getValue() == i)
                        {
                            ret.Add(allCards[j]);
                        }
                        if (ret.Count == 5)
                        {
                            return new Object[] { Hand.FullHouse, ret };
                        }
                    }
                    if (!occurences.Contains(2))
                    {
                        for (int j = 6; j >= 0; j--)
                        {
                            if (!ret.Contains(allCards[j]))
                            {
                                ret.Add(allCards[j]);
                                if (ret.Count == 5)
                                {
                                    return new Object[] { Hand.ThreeOfAKind, ret };
                                }
                            }
                        }
                    }
                }
            }
            int pairs = 0;
            for (int i = occurences.Length - 1; i >= 0; i--)
            {
                int val = occurences[i];
                if (val == 2)
                {
                    pairs++;
                    for (int j = 6; j >= 0; j--)
                    {
                        if (allCards[j].getValue() == i)
                        {
                            ret.Add(allCards[j]);
                            if (ret.Count == 2 || ret.Count == 5)
                            {
                                j = -1;
                            }
                        }
                        if (ret.Count == 5)
                        {
                            return new Object[] { Hand.FullHouse, ret };
                        }
                        if (pairs == 2 && ret.Count == 4)
                        {
                            for (int k = 6; k >= 0; k--)
                            {
                                if (!ret.Contains(allCards[k]))
                                {
                                    ret.Add(allCards[k]);
                                    break;
                                }
                            }
                            return new Object[] { Hand.TwoPair, ret };
                        }
                    }
                }
            }
            if (ret.Count == 2)
            {
                for (int j = 6; j >= 0; j--)
                {
                    if (!ret.Contains(allCards[j]))
                    {
                        ret.Add(allCards[j]);
                        if (ret.Count == 5) return new Object[] { Hand.OnePair, ret };
                    }
                }
            }
            for (int i = 6; i >= 2; i--)
            {
                ret.Add(allCards[i]);
            }
            return new Object[] { Hand.HighCard, ret };
        }
        /// <summary>
        /// returns whether or not there is a straight present in the cards.
        /// </summary>
        /// <param name="cards"></param>
        /// <returns></returns>
        public int[] containsStraight(int[] values)
        {
            int[] vals = new int[5];
            for (int i = 10; i >= 0; i--)
            {
                for (int j = 0; j < 5; j++)
                {
                    int val = i + j;
                    if (val > 13)
                    {
                        val -= 13;
                    }
                    vals[j] = val;
                }
                if (values.Contains(vals[0]) && values.Contains(vals[1]) && values.Contains(vals[2]) &&
                    values.Contains(vals[3]) && values.Contains(vals[4]))
                {
                    return vals;
                }
            }
            return null;
        }
        /// <summary>
        /// returns whether or not there is a flush present in the cards
        /// </summary>
        /// <param name="suits"> an array of all the suits of the cards </param>
        /// <returns></returns>
        public int containsFlush(Suit[] suits)
        {
            int[] occurrences = new int[4];
            for (int i = 0; i < suits.Length; i++)
            {
                occurrences[(int)suits[i]]++;
            }
            for (int i = 0; i < occurrences.Length; i++)
            {
                if (occurrences[i] >= 5)
                {
                    return i;
                }
            }
            return -1;
        }
        public int[] containsStraightFlush(Card[] cards)
        {
            Array.Sort(cards);
            List<Card> list = new List<Card>();
            Suit[] suits = new Suit[cards.Length];
            for (int i = 0; i < cards.Length; i++)
            {
                list.Add(cards[i]);
                suits[i] = cards[i].getSuit();
            }
            Suit suit = (Suit)containsFlush(suits);
            if ((int)suit == -1)
            {
                return null;
            }
            int[] values = new int[cards.Length];
            for (int i = list.Count - 1; i >= 0; i--)
            {
                if (list[i].getSuit() != suit)
                {
                    list.RemoveAt(i);
                }
                else
                {
                    values[i] = list[i].getValue();
                }
            }
            return containsStraight(values);
        }
    }
}