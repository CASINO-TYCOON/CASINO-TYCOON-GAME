﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class SlotMachine
    {
        enum State
        {
            Start, Spinning, End
        }
        private Texture2D background;
        private Texture2D reelSheet;
        private SpriteBatch spriteBatch;
        private Rectangle wholeScreen;
        private float sourceWidth;
        private float sourceHeight;
        private Rectangle[] slots;
        private Vector2[] sourcePoss;
        private Rectangle[] sourceRecs;
        private int[] indexes;
        private int[] speeds;
        private State state;
        private int frame;
        private int totalItems;
        private float duration; //how long slots will spin in frames
        private Dictionary<int, Rectangle> dict;
        private Texture2D texHandle;
        private Rectangle handle;
        private Texture2D texBall;
        private Rectangle ball;
        private Rectangle resetHandle;
        private Rectangle resetBall;
        private Random rand;
        private int maxBallY;
        private int centerHandle;
        private bool handleWasReseted;
        private Vector2 velocityBall;
        private float by;
        private Texture2D texPayout;
        private Rectangle payout;
        private int bet;
        private int totalWinnings;
        public bool spinning;

        public SlotMachine(Texture2D background, Texture2D reelSheet, SpriteBatch spriteBatch, int screenWidth, int screenHeight, Texture2D ball, Texture2D handle, Texture2D payouts, int bet)
        {
            this.background = background;
            this.reelSheet = reelSheet;
            this.spriteBatch = spriteBatch;
            this.wholeScreen = new Rectangle(0, 0, screenWidth, screenHeight);
            this.sourceWidth = reelSheet.Width / 7;
            this.sourceHeight = reelSheet.Height / 2;
            this.slots = new Rectangle[3];
            this.sourceRecs = new Rectangle[slots.Length];
            this.sourcePoss = new Vector2[sourceRecs.Length];
            this.indexes = new int[] { 2, 2, 2 };
            this.speeds = new int[3];
            this.totalItems = 14;
            int x = 50;
            int y = 100;
            int[] widths = new int[] { 160, 170, 160 };
            int sum = 0;
            foreach (int i in widths)
            {
                sum += i;
            }
            int space = 0;
            int height = 345;
            for (int i = 0; i < slots.Length; i++)
            {
                slots[i] = new Rectangle(x, y, widths[i], height);
                x += widths[i] + space;
            }
            dict = new Dictionary<int, Rectangle>();
            float xx = 0;
            for (int i = 0; i < 7; i++)
            {
                dict.Add(i, new Rectangle((int)xx, 0, (int)sourceWidth, (int)sourceHeight));
                xx += sourceWidth;
            }
            xx = 0;
            for (int i = 7; i < 14; i++)
            {
                dict.Add(i, new Rectangle((int)xx, (int)sourceHeight, (int)sourceWidth, (int)sourceHeight));
                xx += sourceWidth;
            }
            for (int i = 0; i < sourceRecs.Length; i++)
            {
                sourceRecs[i] = dict[indexes[i]];
                sourcePoss[i] = new Vector2(0, 0);
            }
            this.centerHandle = 275;
            this.texBall = ball;
            this.resetBall = this.ball = new Rectangle(580, 80, 100, 100);
            this.by = this.ball.Y;
            this.texHandle = handle;
            this.resetHandle = this.handle = new Rectangle(563, this.ball.Bottom, 140, this.centerHandle - this.ball.Bottom);
            this.velocityBall = Vector2.Zero;
            rand = new Random();
            speeds = new int[] { rand.Next(2, 3), rand.Next(2, 3), rand.Next(2, 3) };
            maxBallY = 370;
            handleWasReseted = true;
            this.texPayout = payouts;
            this.payout = new Rectangle(15, 5, 670, 73);
            this.bet = bet;
        }
        public void setScreenDimensions(int screenWidth, int screenHeight)
        {
            wholeScreen = new Rectangle(0, 0, screenWidth, screenHeight);
        }
        private void resetForSpin()
        {
            frame = 0;
            duration = rand.Next(4, 5) * rand.Next(50, 61);
            handleWasReseted = false;
        }
        private void spin()
        {
            for (int i = 0; i < speeds.Length; i++)
            {
                if (frame % speeds[i] == 0)
                {
                    /**
                     * THIS WORKS
                     */
                    //if (rand.NextDouble() > 0.75)
                    //{
                    //    indexes[i] = rand.Next(0, 7);
                    //    sourcePoss[i] = new Vector2(indexes[i] * sourceWidth, 0);
                    //    sourceRecs[i].X = (int)sourcePoss[i].X;
                    //    sourceRecs[i].Y = (int)sourcePoss[i].Y;
                    //}
                    //else if (rand.NextDouble() > 0.5)
                    //{
                    //    indexes[i] = rand.Next(7, totalItems);
                    //    sourcePoss[i] = new Vector2((indexes[i] - 7) * sourceWidth, sourceHeight);
                    //    sourceRecs[i].X = (int)sourcePoss[i].X;
                    //    sourceRecs[i].Y = (int)sourcePoss[i].Y;
                    //}
                    //else
                    //{
                    //    indexes[i] = (indexes[i] + 1) % totalItems;
                    //    int check = indexes[i];
                    //    if (check == 7)
                    //    {
                    //        sourcePoss[i] = new Vector2(0, sourceHeight);
                    //        sourceRecs[i].X = (int)sourcePoss[i].X;
                    //        sourceRecs[i].Y = (int)sourcePoss[i].Y;
                    //    }
                    //    else if (check == 0)
                    //    {
                    //        sourcePoss[i] = new Vector2(0, 0);
                    //        sourceRecs[i].X = (int)sourcePoss[i].X;
                    //        sourceRecs[i].Y = (int)sourcePoss[i].Y;
                    //    }
                    //    else
                    //    {
                    //        sourcePoss[i].X += sourceWidth;
                    //        sourceRecs[i].X = (int)sourcePoss[i].X;
                    //        sourceRecs[i].Y = (int)sourcePoss[i].Y;
                    //    }
                    //}
                    if (rand.NextDouble() > 0.5)
                    {
                        indexes[i] = rand.Next(0, 14);
                    }
                    indexes[i] = (indexes[i] + 1) % totalItems;
                }
            }
        }
        private int getPayout()
        {
            int[] indexes = this.indexes;
            int a = indexes[0];
            int b = indexes[1];
            int c = indexes[2];
            if (a == 6 || a == 8)
            {
                a = 0;
            }
            if (b == 6 || b == 8)
            {
                b = 0;
            }
            if (c == 6 || c == 8)
            {
                c = 0;
            }
            if (a == b && b == c) //3 are the same
            {
                if (a == 0 || a == 6 || a == 8)
                {
                    return this.bet;
                }
                if (a == 2)
                {
                    return this.bet*5;
                }
                if (a == 4)
                {
                    return (int)((double)this.bet * 1.5);
                }
                if (a == 10)
                {
                    return (int)((double)this.bet * 1.5);
                }
                if (a == 12)
                {
                    return (int)(this.bet * 2);
                }
            }
            if (a == b || a == c || b == c)
            {
                return (int)((double)this.bet * 0.5);
            }
            return 0;
        }
        public int gameOver()
        {
            return this.totalWinnings;
        }
        public void Update(GameTime gameTime)
        {
            if (spinning)
            {
                spin();
                frame++;
                if (frame == duration)
                {
                    for (int i = 0; i < indexes.Length; i++)
                    {
                        if (indexes[i] % 2 != 0)
                        {
                            indexes[i] = (indexes[i] + 1) % totalItems;
                        }
                    }
                    int payout = getPayout();
                    totalWinnings += payout - this.bet;
                    Console.WriteLine(" and won $" + payout);
                    spinning = false;
                    handleWasReseted = ball.Y == resetBall.Y;
                }
            }
            MouseState mouse = Mouse.GetState();
            if (mouse.LeftButton == ButtonState.Pressed && mouse.X > this.ball.Left && mouse.X < this.ball.Right)
            {
                velocityBall = Vector2.Zero;
                this.ball.Y = Clamp(mouse.Y-this.ball.Height/2, this.resetBall.Y, this.maxBallY);
                if (!spinning && this.ball.Y == this.maxBallY && handleWasReseted)
                {
                    resetForSpin();
                    spinning = true;
                    Console.Write("You bet $" + this.bet);
                }
            }
            else if (velocityBall == Vector2.Zero)
            {
                velocityBall = new Vector2(0, this.resetBall.Y - this.ball.Y);
                if (velocityBall.Y != 0)
                {
                    velocityBall.Normalize();
                }
                
                by = ball.Y;
            }
            else
            {
                by += velocityBall.Y*20;
                ball.Y = Clamp((int)by, this.resetBall.Y, this.maxBallY);
                if (ball.Y == this.resetBall.Y)
                {
                    velocityBall = Vector2.Zero;
                    handleWasReseted = true;
                }
            }
            if (ball.Y <= this.centerHandle)
            {
                this.handle.Y = this.ball.Bottom;
                this.handle.Height = this.centerHandle - this.ball.Bottom;
            }
            else
            {
                this.handle.Y = this.centerHandle;
                this.handle.Height = this.ball.Top - this.centerHandle;
            }
        }
        public void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            for (int i = 0; i < sourceRecs.Length; i++)
            {
                spriteBatch.Draw(reelSheet, slots[i], dict[indexes[i]], Color.White);
            }
            spriteBatch.Draw(background, wholeScreen, Color.White);
            spriteBatch.Draw(texBall, ball, Color.White);
            spriteBatch.Draw(texHandle, handle, Color.White);
            spriteBatch.Draw(texPayout, payout, Color.White);
            spriteBatch.End();
        }
        private int Clamp(int val, int min, int max)
        {
            if (val.CompareTo(min) < 0) return min;
            else if (val.CompareTo(max) > 0) return max;
            else return val;
        }
    }
}