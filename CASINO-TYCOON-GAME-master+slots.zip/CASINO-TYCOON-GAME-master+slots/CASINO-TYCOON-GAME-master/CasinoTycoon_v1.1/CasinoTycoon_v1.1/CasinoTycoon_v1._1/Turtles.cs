﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Turtles
    {
        const int SPACE_BETWEEN_TURTLES = 5;
        public  int WIDTH = 50;
        const int HEIGHT = 50;
        const int SWITCH_ON = 15;
        private Rectangle[] sources;
        public Rectangle[] turtles;
        private SpriteBatch spriteBatch;
        private Texture2D spriteSheet;
        private int curIndex = 0;
        private bool submerging;
        private int frameCounter;
        public int velocity;
        private bool movingRight;

        public Turtles(Vector2 start, int velocity, int numOfTurtles, SpriteBatch spriteBatch, Texture2D spriteSheet, Rectangle[] sources, bool submerging)
        {
            this.turtles = new Rectangle[numOfTurtles];
            this.spriteSheet = spriteSheet;
            this.spriteBatch = spriteBatch;
            this.submerging = submerging;
            this.sources = sources;
            int x = (int)start.X;
            int y = (int)start.Y;
            for (int i = 0; i < this.turtles.Length; i++)
            {
                this.turtles[i] = new Rectangle(x, y, WIDTH, HEIGHT);
                x += SPACE_BETWEEN_TURTLES+WIDTH;
            }
            this.velocity = velocity;
            this.movingRight = velocity > 0;
        }
        public void Update(GameTime gameTime)
        {
            if (frameCounter == SWITCH_ON)
            {
                curIndex = (curIndex + 1) % sources.Length;
                frameCounter = 0;
            }
            frameCounter++;
            for (int i = 0; i < turtles.Length; i++)
            {
                turtles[i].X += velocity;
            }
        }
        public void Draw(GameTime gameTime)
        {
            for (int i = 0; i < turtles.Length; i++)
            {
                spriteBatch.Draw(spriteSheet, turtles[i], sources[curIndex], Color.White);
            }
        }
        public bool contains(Rectangle pos)
        {
            if (submerging && curIndex != 0)
            {
                return false;
            }
            for (int i = 0; i < turtles.Length; i++)
            {
                if (turtles[i].Intersects(pos))
                {
                    return Rectangle.Intersect(turtles[i], pos).Width > 10;
                }
            }
            return false;
        }
    }
}
