﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Fly
    {
        private Rectangle source = new Rectangle(83, 180, 11, 9);
        private Rectangle[] poss;
        private SpriteBatch spriteBatch;
        private Texture2D sheet;
        private int resetDelay;
        private int delay;
        private int resetLifetime;
        private int lifetime;
        private bool alive;
        private int index;

        public Fly(Texture2D sheet, SpriteBatch spriteBatch, Rectangle[] poss)
        {
            this.sheet = sheet;
            this.spriteBatch = spriteBatch;
            this.poss = poss;
            this.resetDelay = 300;
            this.delay = resetDelay;
            this.resetLifetime = 210;
            this.lifetime = resetLifetime;
            this.alive = true;
        }
        public void Update(GameTime gameTime)
        {
            if (alive)
            {
                
                lifetime--;
            }
            else
            {
                delay--;
                if (delay == 0)
                {
                    alive = true;
                    index = new Random().Next(poss.Length);
                    if (poss[index].X == -1)
                    {
                        for (int i = 0; i < poss.Length; i++)
                        {
                            if (poss[i].X != -1)
                            {
                                index = i;
                                i = 100;
                            }
                        }
                    }
                }
            }
            if (lifetime == 0)
            {
                alive = false;
                lifetime = resetLifetime;
                delay = resetDelay;
            }
        }
        public void Draw(GameTime gameTime)
        {
            if (alive)
            {
                spriteBatch.Draw(sheet, poss[index], source, Color.White);
            }
        }
        public void removeOption(int index)
        {
            poss[index] = new Rectangle(-1, -1, -1, -1);
        }
    }
}
