﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Car
    {
        public Rectangle pos;
        public Rectangle source;
        private int screenWidth;
        private int screenHeight;
        private int velocity;
        private bool movingRight;

        public Car(Rectangle source, Rectangle pos, int screenWidth, int screenHeight, int velocity)
        {
            this.source = source;
            this.pos = pos;
            this.screenWidth = screenWidth;
            this.screenHeight = screenHeight;
            this.velocity = velocity;
            this.movingRight = velocity > 0;
        }
        public bool Update(GameTime gameTime)
        {
            this.pos.X += velocity;
            return movingRight ? pos.X > screenWidth : pos.X + pos.Width < 0;
        }
    }
}
