﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CasinoTycoon_v1._1
{
    class Character
    {
    }
}
