﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class PokerPlayer
    {
        private string name;
        private float balance;
        private int handsWon;
        private string catchphrase;
        private Vector2 location;

        public PokerPlayer(string name, float balance)
        {
            this.name = name;
            this.balance = balance;
        }
        /// <summary>
        /// adds earnings to balance and says catchprase
        /// </summary>
        /// <param name="earnings"> money won in the hand </param>
        public void wonHand(int earnings)
        {

        }
        /// <summary>
        /// returns whether or not the player has funds to continue in the game
        /// </summary>
        /// <param name="tableMinimum"> the minimum balance to stay at the table </param>
        /// <returns></returns>
        public bool canContinue(int tableMinimum)
        {
            return balance > tableMinimum;
        }
        public string getName() { return name; }
        public float getBalance() { return balance; }
        public int getHandsWon() { return handsWon; }
        public string getCatchphrase() { return catchphrase; }
        public Vector2 getLocation() { return location; }
    }
}
