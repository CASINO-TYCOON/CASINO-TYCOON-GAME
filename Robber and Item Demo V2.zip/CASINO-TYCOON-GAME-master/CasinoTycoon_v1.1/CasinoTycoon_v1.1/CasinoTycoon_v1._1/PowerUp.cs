﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    class PowerUp 
    {
        private Texture2D[] textures;
        public Texture2D currentTexture;
        public string name;

        public enum powerUpType //Value accessed by the main logic class. Can be used to determine what a powerup should do if it is found to be active
        {
            shield, //Ignore any damage while active
            hourglass //Double any money gained
        }

        public enum powerUpStatus
        {
            ground, //Not yet collected, must be drawn on the overworld
            inventory, //If it is picked up it will go into the inventory
            used //It has run its course and needs to be removed from the inventory (inventory logic will be able to check for used powerUps and remove them)
        }

        private static int width = 40;
        private static int height = 40;
        public Vector2 location;

        public int activeTime; //Amount of time the powerup lasts before wearing off
        public Boolean active; //True if the powerup is being used, false otherwise
        public powerUpType type;

        public powerUpStatus status;

        public PowerUp(Vector2 location2, powerUpType type2)
        {
            status = powerUpStatus.ground;
            location = location2;

            activeTime = 600;
            active = false;
            type = type2;
        }

        public void loadContent(ContentManager Content)
        {
            textures = new Texture2D[2];
            textures[0] = Content.Load<Texture2D>("Items/PowerUps/shield");
            textures[1] = Content.Load<Texture2D>("Items/PowerUps/hourglass");

            if (type == powerUpType.shield)
            {
                name = "Shield";
                currentTexture = textures[0];
            }
            if (type == powerUpType.hourglass)
            {
                name = "Hourglass";
                currentTexture = textures[1];
            }
        }

        public void activate() //Begins the powerup's effects
        {
            active = true;
        }

        public void update()
        {
            activeTime--;
            if(activeTime == 0)
            {
                status = powerUpStatus.used;
            }
        }

        public bool canGrab(Player player) //Returns true if the player is able to pick the powerUp up
        {
            if(new Rectangle((int)player.position.X, (int)player.position.Y, player.width, player.height).Intersects(new Rectangle((int)location.X, (int)location.Y, width, height)))
            {
                return true;
            }
            return false;
        }

        public void draw(SpriteBatch spriteBatch)
        {
            if(status == powerUpStatus.ground)
            {
                spriteBatch.Draw(currentTexture, new Rectangle((int)location.X, (int)location.Y, width, height), Color.White);
            }
        }
    }
}
