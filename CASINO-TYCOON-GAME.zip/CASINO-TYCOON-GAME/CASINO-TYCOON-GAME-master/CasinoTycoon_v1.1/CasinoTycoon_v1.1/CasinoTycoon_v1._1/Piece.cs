﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;

namespace CasinoTycoon_v1._1
{
    public enum ChessPiece
    {
        ROOK, KNIGHT, BISHOP, QUEEN, KING, PAWN
    }
    public enum Colour
    {
        WHITE, BLACK
    }
    public class Piece
    {
        public Rectangle rect;
        public Texture2D image;
        public ChessPiece type;
        public Colour color;
        public Piece() { }
        public Piece(Texture2D image, Rectangle rect)
        {
            this.image = image;
            this.rect = rect;
        }
        public void setType(ChessPiece type) { this.type = type; }
        public void setColor(Colour color) { this.color = color; }
    }
}
