﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Item
    {
        public Rectangle rect;
        public String name;
        Texture2D texture;
        public bool isObstacle;

        public Item(Rectangle r, String n, Texture2D t, bool o,ContentManager Content)
        {
            rect = r;
            name = n;
            texture = t;
            isObstacle = o;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, rect, Color.White);
        }

        public Vector2 Origin
        {
            get { return new Vector2(rect.X + rect.Width / 2, rect.Y + rect.Height / 2); }
        }
    }   
}
