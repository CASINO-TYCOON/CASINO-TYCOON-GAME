﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Deck
    {
        private const float NUM_OF_DECKS = 2.5f;
        private const int CARDS_PER_DECK = 52;
        public Card[] deck;
        public Texture2D backOfCards;
        private int index;

        ///<summary>
        /// builds deck with empty card array of size 52
        /// </summary>
        public Deck()
        {
            deck = new Card[52];
        }
        ///<summary>
        /// creates deck based on a prebuilt card array
        /// </summary>
        public Deck(Card[] deck, Texture2D backOfCards)
        {
            this.deck = new Card[(int)(NUM_OF_DECKS * CARDS_PER_DECK)];
            for (int i = 0; i < this.deck.Length; i++)
            {
                this.deck[i] = deck[i % deck.Length];
            }
            this.backOfCards = backOfCards;
            for (int i = 0; i < 100; i++)
                shuffleDeck();
        }
        public Card getCard()
        {
            if (index >= deck.Length)
            {
                shuffleDeck();
                index = 1;
            }
            index++;
            return deck[index - 1];
        }
        /// <summary>
        /// will add one card to first available spot in the deck
        /// </summary>
        /// <param name="card"> the card to add </param>
        public void add(Card card)
        {
            for (int i = 0; i < deck.Length; i++)
            {
                if (deck[i] == null)
                {
                    deck[i] = card;
                    return;
                }
            }
            Card[] temp = deck;
            deck = new Card[deck.Length + 1];
            for (int i = 0; i < temp.Length; i++)
            {
                deck[i] = temp[i];
            }
            deck[deck.Length - 1] = card;
        }
        ///<summary>
        /// normal shuffle of deck
        /// </summary>
        public void shuffleDeck()
        {
            Random random = new Random();
            for (var i = deck.Length - 1; i > 0; i--)
            {
                var temp = deck[i];
                var index = random.Next(0, i + 1);
                deck[i] = deck[index];
                deck[index] = temp;
            }
            //for (int i = 0; i < deck.Length; i++)
            //    swapCards(i, r.Next(deck.Length));
        }

        /// <summary>
        /// used to make a hand appear
        /// </summary>
        /// <param name="forceHand"> the hand you want to force </param>
        public void shuffleDeck(int forceHand)
        {
            switch (forceHand)
            {
                case 9: //force a royal flush
                    swapCards(0, locationOf(10, Suit.hearts));
                    swapCards(1, locationOf(13, Suit.hearts));
                    swapCards(2, locationOf(11, Suit.hearts));
                    swapCards(3, locationOf(1, Suit.hearts));
                    swapCards(4, locationOf(12, Suit.hearts));
                    break;
                case 8: //force a straight flush
                    swapCards(0, locationOf(4, Suit.diamonds));
                    swapCards(1, locationOf(3, Suit.diamonds));
                    swapCards(2, locationOf(5, Suit.diamonds));
                    swapCards(3, locationOf(1, Suit.diamonds));
                    swapCards(4, locationOf(2, Suit.diamonds));
                    break;
                case 7: //force a 4 of a kind
                    swapCards(0, locationOf(11, Suit.diamonds));
                    swapCards(1, locationOf(11, Suit.clubs));
                    swapCards(2, locationOf(11, Suit.spades));
                    swapCards(3, locationOf(4, Suit.hearts));
                    swapCards(4, locationOf(11, Suit.hearts));
                    break;
                case 6: //force a full house
                    swapCards(0, locationOf(12, Suit.diamonds));
                    swapCards(1, locationOf(7, Suit.clubs));
                    swapCards(2, locationOf(12, Suit.spades));
                    swapCards(3, locationOf(7, Suit.hearts));
                    swapCards(4, locationOf(12, Suit.hearts));
                    break;
                case 5: //force a flush
                    swapCards(0, locationOf(4, Suit.hearts));
                    swapCards(1, locationOf(7, Suit.hearts));
                    swapCards(2, locationOf(9, Suit.hearts));
                    swapCards(3, locationOf(13, Suit.hearts));
                    swapCards(4, locationOf(2, Suit.hearts));
                    break;
                case 4: //force a straight
                    swapCards(0, locationOf(4, Suit.spades));
                    swapCards(1, locationOf(6, Suit.diamonds));
                    swapCards(2, locationOf(5, Suit.spades));
                    swapCards(3, locationOf(8, Suit.hearts));
                    swapCards(4, locationOf(7, Suit.clubs));
                    break;
                case 3: //force a straight (ace high)
                    swapCards(0, locationOf(12, Suit.spades));
                    swapCards(1, locationOf(10, Suit.diamonds));
                    swapCards(2, locationOf(11, Suit.spades));
                    swapCards(3, locationOf(1, Suit.hearts));
                    swapCards(4, locationOf(13, Suit.clubs));
                    break;
                case 2: //force 3 of a kind
                    swapCards(0, locationOf(5, Suit.spades));
                    swapCards(1, locationOf(5, Suit.diamonds));
                    swapCards(2, locationOf(2, Suit.diamonds));
                    swapCards(3, locationOf(5, Suit.hearts));
                    swapCards(4, locationOf(6, Suit.clubs));
                    break;
                case 1: //force two pair
                    swapCards(0, locationOf(2, Suit.spades));
                    swapCards(1, locationOf(6, Suit.diamonds));
                    swapCards(2, locationOf(2, Suit.diamonds));
                    swapCards(3, locationOf(12, Suit.hearts));
                    swapCards(4, locationOf(6, Suit.clubs));
                    break;
                case 0: //force high pair
                    swapCards(0, locationOf(1, Suit.spades));
                    swapCards(1, locationOf(6, Suit.clubs));
                    swapCards(2, locationOf(1, Suit.diamonds));
                    swapCards(3, locationOf(9, Suit.diamonds));
                    swapCards(4, locationOf(2, Suit.clubs));
                    break;
                default:
                    shuffleDeck();
                    break;

            }
        }
        ///<summary>
        /// swaps the cards at position a and b
        /// </summary>
        public void swapCards(int a, int b)
        {
            Card temp;
            temp = deck[a];
            deck[a] = deck[b];
            deck[b] = temp;
        }
        ///<summary>
        /// gets the location in the deck of a card with the value and suit
        /// </summary>
        private int locationOf(int val, Suit suit)
        {
            for (int i = 0; i < deck.Length; i++)
                if (deck[i].getValue() == val && deck[i].getSuit() == suit)
                    return i;
            return -1; //card does not exist in deck
        }

        public void remove(Card card)
        {
            int index = Array.IndexOf(deck, card);
            for(int i = index+1; i < deck.Length-1; i++)
            {
                deck[i - 1] = deck[i];
            }
        }
    }
}