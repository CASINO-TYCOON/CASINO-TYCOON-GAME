﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    /*
     *  1.  To use this class to read files:
     *  
     *  You have to make an instance of this class
     *  when you do, the map will load
     *  to get the map make a List<List<Tile>> variable (2D list of tiles)
     *  and set it equal to the [instance].tiles
     *  
     *  Look in the casino class' constructor for an example
     *  
     *  
     *  2.  To make images compatible with this class:
     *  
     *  Make sure that if the tile is passable it is in COMPLETE lower case
     *  For example: casino floor.png, you can have spaces in image names
     *  If you want the tile to be impassable make sure it is in COMPLETE upper case
     *  For example: SLOTS.png, you can have spaces in image names
     *  
     *  
     */
    class MapReader
    {
        public List<List<Tile>> tiles;
        public List<Item> items;
        List<Tile> tempMap;
        List<bool> obstacles;
        List<Texture2D> textures;
        String path;
        int lineIndex;

        bool isSlot;

        public List<Robber> robberList;
        public List<PowerUp> powerUpList;
        public List<Collectable> collectableList;
        public List<InteractiveSpot> spotsList;

        private List<String> names;

        int numLine;

        //for reference when creating robbers
        Player player;

        enum Loadstate { Texture, Map, Robbers, PowerUps, Collectables, InteractiveSpot, Item, ItemMap };
        Loadstate state;

        public MapReader(String p, ContentManager Content, Player player2)
        {
            path = p;
            lineIndex = 0;
            tiles = new List<List<Tile>>();
            tempMap = new List<Tile>();
            textures = new List<Texture2D>();
            obstacles = new List<bool>();

            robberList = new List<Robber>();
            powerUpList = new List<PowerUp>();
            collectableList = new List<Collectable>();
            spotsList = new List<InteractiveSpot>();

            items = new List<Item>();

            names = new List<string>();

            player = player2;

            numLine = 0;

            load(Content);
        }

        /// <summary>
        /// Loads the .txt map file as a 2D Tile List
        /// </summary>
        /// <param name="Content"> To Load the textures </param>
        public void load(ContentManager Content)
        {
            String line;
            String[] lineArray;
            try
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    while (!reader.EndOfStream)
                    {
                        line = reader.ReadLine().TrimEnd(' ').TrimStart(' ');
                        while (line.IndexOf("  ") != -1)
                            line = line.Replace("  ", " ");

                        if (line.Contains("[Textures]"))
                        {
                            state = Loadstate.Texture;
                            continue;
                        }
                        else if (line.Contains("[Map]"))
                        {
                            state = Loadstate.Map;
                            continue;
                        }
                        else if (line.Contains("[Robbers]"))
                        {
                            state = Loadstate.Robbers;
                            textures = new List<Texture2D>();
                            continue;
                        }
                        else if (line.Contains("[PowerUps]"))
                        {
                            state = Loadstate.PowerUps;
                            continue;
                        }
                        else if (line.Contains("[Collectables]"))
                        {
                            state = Loadstate.Collectables;
                            continue;
                        }
                        else if (line.Contains("[InteractiveSpots]"))
                        {
                            state = Loadstate.InteractiveSpot;
                            continue;
                        }
                        else if (line.Contains("[Item]"))
                        {
                            state = Loadstate.Item;
                            names = new List<string>();
                            continue;
                        }
                        else if (line.Contains("[ItemMap]"))
                        {
                            state = Loadstate.ItemMap;
                            continue;
                        }

                        switch (state)
                        {
                            case Loadstate.Texture:
                                if (line != String.Empty)
                                {
                                    textures.Add(Content.Load<Texture2D>(line));
                                    lineArray = line.Split('/');
                                    if (!lineArray[lineArray.Length - 1].Equals(lineArray[lineArray.Length - 1].ToLower()))
                                    {
                                        obstacles.Add(true);
                                    }
                                    else
                                    {
                                        obstacles.Add(false);
                                    }
                                    names.Add(lineArray[lineArray.Length - 1]);

                                }
                                break;

                            case Loadstate.Map:
                                lineArray = line.Split(' ');

                                for (int i = 0; i < lineArray.Length; i++)
                                {
                                    int temp = int.Parse(lineArray[i]);
                                    tempMap.Add(new Tile(textures[temp], new Rectangle(i * 50, lineIndex * 50, 50, 50), obstacles[temp], names[temp]));
                                }
                                tiles.Add(tempMap);
                                lineIndex++;
                                tempMap = new List<Tile>();
                                break;

                            case Loadstate.Robbers:
                                lineArray = line.Split(' ');

                                robberList.Add(new Robber(new Vector2(int.Parse(lineArray[0]), int.Parse(lineArray[1]))));
                                break;


                            case Loadstate.PowerUps:
                                lineArray = line.Split(' ');

                                //default to hourglass in case of an error
                                PowerUp.powerUpType Ptype = PowerUp.powerUpType.hourglass;

                                Random powerRand = new Random();
                                int powerNum = powerRand.Next(100);

                                if (powerNum > 50)
                                {
                                    Ptype = PowerUp.powerUpType.hourglass;
                                }
                                else
                                {
                                    Ptype = PowerUp.powerUpType.shield;
                                }

                                powerUpList.Add(new PowerUp(new Vector2(int.Parse(lineArray[0]), int.Parse(lineArray[1])), Ptype));
                                break;


                            case Loadstate.Collectables:
                                lineArray = line.Split(' ');

                                //defualt to coin in case of an error
                                Collectable.collectableType Ctype = Collectable.collectableType.coin;

                                Random CollRand = new Random();
                                int CollNum = CollRand.Next(100);

                                if (CollNum > 90)
                                {
                                    Ctype = Collectable.collectableType.moneybag;
                                }
                                else if (CollNum > 50)
                                {
                                    Ctype = Collectable.collectableType.dollar;
                                }
                                else
                                {
                                    Ctype = Collectable.collectableType.coin;
                                }

                                collectableList.Add(new Collectable(new Vector2(int.Parse(lineArray[0]), int.Parse(lineArray[1])), Ctype));
                                break;

                            case Loadstate.InteractiveSpot:
                                lineArray = line.Split(' ');

                                //default to Poker in case of an error
                                InteractiveSpot.InteractiveType Stype = InteractiveSpot.InteractiveType.Poker;

                                if (int.Parse(lineArray[4]) == 0)
                                {
                                    Stype = InteractiveSpot.InteractiveType.Poker;
                                }
                                if (int.Parse(lineArray[4]) == 1)
                                {
                                    Stype = InteractiveSpot.InteractiveType.Blackjack;
                                }
                                if (int.Parse(lineArray[4]) == 2)
                                {
                                    Stype = InteractiveSpot.InteractiveType.Frogger;
                                }
                                if (int.Parse(lineArray[4]) == 3)
                                {
                                    Stype = InteractiveSpot.InteractiveType.NPCtalk;
                                }

                                spotsList.Add(new InteractiveSpot(int.Parse(lineArray[0]), int.Parse(lineArray[1]), int.Parse(lineArray[2]), int.Parse(lineArray[3]), Stype));
                                break;

                            case Loadstate.Item:
                                lineArray = line.Split(' ');
                                textures.Add(Content.Load<Texture2D>(lineArray[0]));
                                lineArray = line.Split('/');
                                names.Add(lineArray[lineArray.Length - 1]);
                                break;

                            case Loadstate.ItemMap:
                                lineArray = line.Split(' ');
                                for (int i = 0; i < lineArray.Length; i++)
                                {
                                    if (!lineArray[i].Equals("."))
                                    {
                                        int num = int.Parse(lineArray[i]);
                                        String[] parts = names[num].Split(' ');
                                        String[] size = parts[parts.Length - 1].Split('x');
                                        int width = int.Parse(size[0]);
                                        int height = int.Parse(size[1]);
                                        bool impassable = !parts[0].Equals(parts[0].ToLower());
                                        items.Add(new Item(new Rectangle(i * 50, numLine * 50, width, height), parts[0], textures[num], impassable,Content));
                                    }
                                }
                                numLine++;
                                break;
                        }

                        //Now that every entity is wrapped into a list, they need to load their content
                        for (int i = 0; i < robberList.Count; i++)
                        {
                            robberList[i].loadContent(Content);
                        }
                        for (int i = 0; i < powerUpList.Count; i++)
                        {
                            powerUpList[i].loadContent(Content);
                        }
                        for (int i = 0; i < collectableList.Count; i++)
                        {
                            collectableList[i].loadContent(Content);
                        }
                        for (int i = 0; i < spotsList.Count; i++)
                        {
                            spotsList[i].loadContent(Content);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                //Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }
        }

    }
}
