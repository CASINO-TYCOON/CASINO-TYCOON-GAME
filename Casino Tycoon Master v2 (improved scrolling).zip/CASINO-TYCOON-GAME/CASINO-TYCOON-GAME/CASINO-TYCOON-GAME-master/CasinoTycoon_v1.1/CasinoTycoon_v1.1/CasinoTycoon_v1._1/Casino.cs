﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    class Casino
    {
        //how fast the screen moves
        int scrollSpeed = 3;
        bool sprint;

        //pixel values for the width and height of the room
        public int width;
        public int height;

        List<List<Tile>> casinoMap;
        Rectangle pokerTable;
        Texture2D pokerTableTexture;
        public enum Direction { up, down, left, right};
        MapReader casinoMapReader;
        List<Item> items;

        //values that determine if the map is at the edge for use in the player class. False = the screen has room to move, True = it is at the edge
        public bool upScroll;
        public bool downScroll;
        public bool leftScroll;
        public bool rightScroll;

        //entities found in the room
        Player player;

        public List<Robber> robberList;
        public List<PowerUp> powerUpList;
        public List<Collectable> collectableList;
        public List<InteractiveSpot> spotsList;

        KeyboardState oldKb;
        GamePadState oldGp;

        public Casino(ContentManager Content, Player player2)
        {
            casinoMapReader = new MapReader(@"Content/Casino/casinoLayout.txt", Content, player);
            casinoMap = casinoMapReader.tiles;
            items = casinoMapReader.items;

            player = player2;
            robberList = casinoMapReader.robberList;
            powerUpList = casinoMapReader.powerUpList;
            collectableList = casinoMapReader.collectableList;
            spotsList = casinoMapReader.spotsList;

            upScroll = false;
            downScroll = false;
            leftScroll = false;
            rightScroll = false;

            width = casinoMap.Count * 50;
            height = casinoMap[0].Count * 50;

            oldKb = Keyboard.GetState();
            oldGp = GamePad.GetState(PlayerIndex.One);
        }

        public void updateEntities(GameTime gameTime, Menu menu, Inventory inventory, Player player) //apply update logic to all the entities in the room
        {
            KeyboardState kb = Keyboard.GetState();
            GamePadState gp = GamePad.GetState(PlayerIndex.One);

            //robber update logic
            for (int i = 0; i < robberList.Count; i++)
            {
                robberList[i].update(gameTime, this, inventory.activeItems, player);
            }

            //powerUp update logic
            for (int i = 0; i < powerUpList.Count; i++)
            {
                if (powerUpList[i].active)
                {
                    powerUpList[i].update();
                }
                if (powerUpList[i].status == PowerUp.powerUpStatus.ground)
                {
                    if (powerUpList[i].canGrab(player) && Input.keyPressEnter(kb, gp, oldKb, oldGp))
                    {
                        if (inventory.addItem(powerUpList[i]) == true)
                        {
                            powerUpList[i].status = PowerUp.powerUpStatus.inventory;
                        }
                    }
                }
            }

            //collectable update logic
            for (int i = 0; i < collectableList.Count; i++)
            {
                if (collectableList[i].status == Collectable.collectableStatus.ground)
                {
                    if (collectableList[i].canGrab(player) && Input.keyPressEnter(kb, gp, oldKb, oldGp))
                    {
                        collectableList[i].use(player);
                    }
                }
            }

            oldKb = kb;
            oldGp = gp;

        }


        public void move(Direction direction)
        {
            KeyboardState kb = Keyboard.GetState(PlayerIndex.One);
            GamePadState gp = GamePad.GetState(PlayerIndex.One);

            if(Input.shift(kb, gp))
            {
                scrollSpeed = 6;
            }
            else
            {
                scrollSpeed = 3;
            }

            if(direction == Direction.right && casinoMap[0][casinoMap[0].Count - 1].rect.X > 700 && Input.right(kb, gp) && !collision(new Rectangle(player.feet.X - scrollSpeed, player.feet.Y, player.feet.Width, player.feet.Height)) && player.position.X > 350)
            {
                for(int i = 0; i < casinoMap.Count; i++)
                {
                    for(int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.X -= scrollSpeed;
                    }
                }
                for (int x = 0; x < robberList.Count; x++)
                {
                    robberList[x].rect.X -= scrollSpeed;
                }
                for (int x = 0; x < powerUpList.Count; x++)
                {
                    powerUpList[x].location.X -= scrollSpeed;
                }
                for (int x = 0; x < collectableList.Count; x++)
                {
                    collectableList[x].location.X -= scrollSpeed;
                }
                for (int x = 0; x < spotsList.Count; x++)
                {
                    spotsList[x].rect.X -= scrollSpeed;
                }
                for (int i = 0; i < items.Count; i++)
                {
                    items[i].rect.X -= scrollSpeed;
                }
            }

            if (casinoMap[0][casinoMap[0].Count - 1].rect.X <= 700 || player.position.X < 350)
            {
                rightScroll = true;
            }
            else
            {
                rightScroll = false;
            }

            
            if (direction == Direction.left && casinoMap[0][0].rect.X < 0 && Input.left(kb, gp) && !collision(new Rectangle(player.feet.X + scrollSpeed, player.feet.Y, player.feet.Width, player.feet.Height)) && player.position.X < 350)
            {
                for (int i = 0; i < casinoMap.Count; i++)
                {
                    for (int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.X += scrollSpeed;
                    }
                }
                for (int x = 0; x < robberList.Count; x++)
                {
                    robberList[x].rect.X += scrollSpeed;
                }
                for (int x = 0; x < powerUpList.Count; x++)
                {
                    powerUpList[x].location.X += scrollSpeed;
                }
                for (int x = 0; x < collectableList.Count; x++)
                {
                    collectableList[x].location.X += scrollSpeed;
                }
                for (int x = 0; x < spotsList.Count; x++)
                {
                    spotsList[x].rect.X += scrollSpeed;
                }
                for (int i = 0; i < items.Count; i++)
                {
                    items[i].rect.X += scrollSpeed;
                }
            }


            if (casinoMap[0][0].rect.X >= 0 || player.position.X > 350)
            {
                leftScroll = true;
            }
            else
            {
                leftScroll = false;
            }

            if (direction == Direction.up && casinoMap[0][0].rect.Y < 0 && Input.up(kb, gp) && !collision(new Rectangle(player.feet.X, player.feet.Y - scrollSpeed, player.feet.Width, player.feet.Height)) && player.position.Y < 300)
            {
                for (int i = 0; i < casinoMap.Count; i++)
                {
                    for (int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.Y += scrollSpeed;
                    }
                }
                for (int x = 0; x < robberList.Count; x++)
                {
                    robberList[x].rect.Y += scrollSpeed;
                }
                for (int x = 0; x < powerUpList.Count; x++)
                {
                    powerUpList[x].location.Y += scrollSpeed;
                }
                for (int x = 0; x < collectableList.Count; x++)
                {
                    collectableList[x].location.Y += scrollSpeed;
                }
                for (int x = 0; x < spotsList.Count; x++)
                {
                    spotsList[x].rect.Y += scrollSpeed;
                }
                for (int i = 0; i < items.Count; i++)
                {
                    items[i].rect.Y += scrollSpeed;
                }
            }

            if (casinoMap[0][0].rect.Y >= 0 || player.position.Y > 300)
            {
                upScroll = true;
            }
            else
            {
                upScroll = false;
            }
            //Console.WriteLine(casinoMapRect[casinoMapRect.GetLength(0) - 1, 0].Y);
            if (direction == Direction.down && casinoMap[casinoMap.Count-2][0].rect.Y > 500 && Input.down(kb, gp) && !collision(new Rectangle(player.feet.X, player.feet.Y + scrollSpeed, player.feet.Width, player.feet.Height)) && player.position.Y > 300)
            {
                for (int i = 0; i < casinoMap.Count; i++)
                {
                    for (int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.Y -= scrollSpeed;
                    }
                }
                for (int x = 0; x < robberList.Count; x++)
                {
                    robberList[x].rect.Y -= scrollSpeed;
                }
                for (int x = 0; x < powerUpList.Count; x++)
                {
                    powerUpList[x].location.Y -= scrollSpeed;
                }
                for (int x = 0; x < collectableList.Count; x++)
                {
                    collectableList[x].location.Y -= scrollSpeed;
                }
                for (int x = 0; x < spotsList.Count; x++)
                {
                    spotsList[x].rect.Y -= scrollSpeed;
                }
                for (int i = 0; i < items.Count; i++)
                {
                    items[i].rect.Y -= scrollSpeed;
                }
            }

            if(casinoMap[casinoMap.Count - 2][0].rect.Y <= 500 || player.position.Y < 300)
            {
                downScroll = true;
            }
            else
            {
                downScroll = false;
            }
        }

        public Boolean collision(Rectangle feet)
        {
            Boolean collision = false;
            for(int i = 0; i < casinoMap.Count; i++)
            {
                for(int j = 0; j < casinoMap[i].Count; j++)
                {
                    Rectangle currRect = casinoMap[i][j].rect;
                    if(feet.Intersects(currRect) && casinoMap[i][j].isObstacle)
                    {
                        collision = true;
                    }
                }
            }
            for (int i= 0; i < items.Count; i++)
            {
                if (feet.Intersects(items[i].rect) && items[i].isObstacle)
                {
                    collision = true;
                }
            }
            return collision;
        }

        public String startGame(Player player)
        {
            for (int i = 0; i < casinoMap.Count; i++)
            {
                for (int j = 0; j < casinoMap[i].Count; j++)
                {
                    Tile temp = casinoMap[i][j];
                    if (temp.name.Equals("SLOTS") && Math.Sqrt(Math.Pow(temp.Origin.X - player.Origin.X, 2) + Math.Pow(temp.Origin.Y - player.Origin.Y, 2)) < 55)
                    {
                        return "arcade";
                    }
                }
            }
            for (int i = 0; i < items.Count; i++)
            {
                Item temp = items[i];
                if (temp.name.Equals("TABLE") && Math.Sqrt(Math.Pow(temp.Origin.X - player.Origin.X, 2) + Math.Pow(temp.Origin.Y - player.Origin.Y, 2)) < 100)
                {
                    return "board";
                }
            }
            return "";
        }

        public void Draw(SpriteBatch sb)
        {
            sb.Begin();
            for(int i = 0; i < casinoMap.Count; i++)
            {
                for(int j = 0; j < casinoMap[i].Count; j++)
                {
                    Texture2D currText = casinoMap[i][j].texture;
                    Rectangle currRect = casinoMap[i][j].rect;
                    sb.Draw(currText, currRect, Color.White);
                }
            }
            
            //draw interactive spots (if visible)
            for (int i = 0; i < spotsList.Count; i++)
            {
                spotsList[i].draw(sb);
            }

            //draw powerUps and Collectables
            for (int i = 0; i < powerUpList.Count; i++)
            {
                powerUpList[i].draw(sb);
            }
            for (int i = 0; i < collectableList.Count; i++)
            {
                collectableList[i].draw(sb);
            }

            //draw robbers
            for (int i = 0; i < robberList.Count; i++)
            {
                robberList[i].draw(sb);
            }

            for (int i = 0; i < items.Count; i++)
            {
                items[i].Draw(sb);
            }

            sb.End();
            
        }
    }
}
