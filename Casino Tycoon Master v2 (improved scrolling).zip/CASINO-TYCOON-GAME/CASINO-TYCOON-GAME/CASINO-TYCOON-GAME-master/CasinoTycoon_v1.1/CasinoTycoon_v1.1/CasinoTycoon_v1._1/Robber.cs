﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    class Robber
    {
        /// <summary>
        /// At the current phase robbers should be functional albeit stupid. If there is extra development time we can make them smarter.
        /// </summary>

        public static int SPEED = 2; //How fast the robber moves (adjust this at testing phase)
        static int width, height = 50; //Width and height (should be equal to the player's)

        //Determines powerUp effects on behavior
        bool hourglassActive;
        bool shieldActive;

        enum robberState
        {
            IDLE, //The player is not close enough, moves randomly
            CHASE, //Follow the player
            RESET, //Used if the robber catches the player, moves him away before returning to idle
        }

        private robberState status; //Determines the behavior of the robber
        int RNG; //value used to determine this sad excuse for an AI

        public Rectangle rect;

        enum robberDirection // determines the direction the robber is going for animation
        {
            UP,
            DOWN,
            LEFT,
            RIGHT
        }

        robberDirection direction;
        Texture2D spriteSheet;
        Rectangle current;
        int frameIndex;

        Rectangle[] downFrames;
        Rectangle[] leftFrames;
        Rectangle[] rightFrames;
        Rectangle[] upFrames;

        public Robber(Vector2 position)
        {
            hourglassActive = false;
            shieldActive = false;

            status = robberState.IDLE;
            RNG = 1;

            rect = new Rectangle((int)position.X, (int)position.Y, 50, 50);

            direction = robberDirection.DOWN;
            frameIndex = 0;
        }

        public void loadContent(ContentManager Content)
        {
            spriteSheet = Content.Load<Texture2D>("Enemy/Soldier 01-1");

            downFrames = new Rectangle[3];
            leftFrames = new Rectangle[3];
            rightFrames = new Rectangle[3];
            upFrames = new Rectangle[3];

            for (int i = 0; i < 3; i++)
            {
                downFrames[i] = new Rectangle(i * (spriteSheet.Width / 3), 0, spriteSheet.Width / 3, spriteSheet.Height / 4);
            }
            for (int i = 0; i < 3; i++)
            {
                leftFrames[i] = new Rectangle(i * (spriteSheet.Width / 3), spriteSheet.Height / 4, spriteSheet.Width / 3, spriteSheet.Height / 4);
            }
            for (int i = 0; i < 3; i++)
            {
                rightFrames[i] = new Rectangle(i * (spriteSheet.Width / 3), (spriteSheet.Height / 4) * 2, spriteSheet.Width / 3, spriteSheet.Height / 4);
            }
            for (int i = 0; i < 3; i++)
            {
                upFrames[i] = new Rectangle(i * (spriteSheet.Width / 3), (spriteSheet.Height / 4) * 3, spriteSheet.Width / 3, spriteSheet.Height / 4);
            }

            current = downFrames[0];
        }

        private void moveHorizontally(int distance, Casino casinoRoom)
        {
            //There seems to be a weird offset with collision, not sure if it is an issue with Casino or Robber.
            //Either way I found that increasing the width by 50 when checking collision fixes this issue.
            //Could turn into something more severe down the line but I'm just going with this for now, since it's 2AM and I have no idea what causes it.

            if (!casinoRoom.collision(new Rectangle(rect.X + distance, rect.Y, width + 50, height)) && rect.X + distance > 0 && (rect.X + rect.Width) + distance < 700) //Move robber if it is possible
            {
                rect.X += distance;
            }

            if (distance > 0)
            {
                direction = robberDirection.RIGHT;
                current = rightFrames[frameIndex];
            }
            else
            {
                direction = robberDirection.LEFT;
                current = leftFrames[frameIndex];
            }
        }

        private void moveVertically(int distance, Casino casinoRoom)
        {
            if (!casinoRoom.collision(new Rectangle(rect.X, rect.Y + distance, width + 50, height)) && rect.Y + distance > 0 && (rect.Y + rect.Height) + distance < 600) //Move robber if it is possible
            {
                rect.Y += distance;
            }

            if (distance > 0)
            {
                direction = robberDirection.DOWN;
                current = downFrames[frameIndex];
            }
            else
            {
                direction = robberDirection.UP;
                current = upFrames[frameIndex];
            }
        }

        public void update(GameTime gameTime, Casino casinoRoom, List<PowerUp> activePowerUps, Player player)
        {
            hourglassActive = false;
            shieldActive = false;
            for (int i = 0; i < activePowerUps.Count; i++)
            {
                if (activePowerUps[i].name == "Hourglass")
                {
                    hourglassActive = true;
                }
                if (activePowerUps[i].name == "Shield")
                {
                    shieldActive = true;
                }
            }

            if (status == robberState.IDLE) //Simple random movements. Further updates can make them smarter but for now they just go anywhere.
            {
                if (gameTime.TotalGameTime.Ticks % 50 == 0)
                {
                    Random rand = new Random();
                    RNG = rand.Next(5);
                }
                if (RNG == 1)
                {
                    if (hourglassActive == false)
                    {
                        moveHorizontally(SPEED, casinoRoom);
                    }
                    else
                    {
                        moveHorizontally(SPEED / 2, casinoRoom);
                    }
                }
                if (RNG == 2)
                {
                    if (hourglassActive == false)
                    {
                        moveHorizontally(SPEED * -1, casinoRoom);
                    }
                    else
                    {
                        moveHorizontally((SPEED * -1) / 2, casinoRoom);
                    }
                }
                if (RNG == 3)
                {
                    if (hourglassActive == false)
                    {
                        moveVertically(SPEED, casinoRoom);
                    }
                    else
                    {
                        moveVertically(SPEED / 2, casinoRoom);
                    }
                }
                if (RNG == 4)
                {
                    if (hourglassActive == false)
                    {
                        moveVertically(SPEED * -1, casinoRoom);
                    }
                    else
                    {
                        moveVertically((SPEED * -1) / 2, casinoRoom);
                    }
                }
                if (playerNear(player))
                {
                    //If you're broke or have a shield it would make no sense for robbers to rob you. They will leave you alone.
                    if (player.getMoney() > 0 && shieldActive == false)
                    {
                        status = robberState.CHASE;
                    }
                }
            }
            if (status == robberState.CHASE) //Moves toward the player. They will realistically move twice each frame (once horizontally, once vertically)
            {
                if (player.position.Y > rect.Y)
                {
                    if (hourglassActive == false)
                    {
                        moveVertically(SPEED, casinoRoom);
                    }
                    else
                    {
                        moveVertically(SPEED / 2, casinoRoom);
                    }
                }
                if (player.position.Y < rect.Y)
                {
                    if (hourglassActive == false)
                    {
                        moveVertically(SPEED * -1, casinoRoom);
                    }
                    else
                    {
                        moveVertically((SPEED * -1) / 2, casinoRoom);
                    }
                }
                if (player.position.X > rect.X)
                {
                    if (hourglassActive == false)
                    {
                        moveHorizontally(SPEED, casinoRoom);
                    }
                    else
                    {
                        moveHorizontally(SPEED / 2, casinoRoom);
                    }
                }
                if (player.position.X < rect.X)
                {
                    if (hourglassActive == false)
                    {
                        moveHorizontally(SPEED * -1, casinoRoom);
                    }
                    else
                    {
                        moveHorizontally((SPEED * -1) / 2, casinoRoom);
                    }
                }
                if (!playerNear(player))
                {
                    status = robberState.IDLE;
                }
                if (rect.Intersects(new Rectangle((int)player.position.X + 20, (int)player.position.Y + 20, player.width - 40, player.height - 40)))
                {
                    status = robberState.RESET;
                    if (shieldActive == false)
                    {
                        if (player.getMoney() >= 50)
                        {
                            player.adjustMoney(-50);
                        }
                        else
                        {
                            player.adjustMoney(player.getMoney());
                        }
                    }
                }
            }
            if (status == robberState.RESET) //Moves away from the player. Based on the player's movements it may be possible to get them stuck in a corner, this might need to be adressed later
            {
                if (player.position.Y > rect.Y)
                {
                    if (hourglassActive == false)
                    {
                        moveVertically(SPEED * -3, casinoRoom); //They go faster than normal so the player can't catch them during a reset phase
                    }
                    else
                    {
                        moveVertically((SPEED * -3) / 2, casinoRoom);
                    }
                }
                if (player.position.Y < rect.Y)
                {
                    if (hourglassActive == false)
                    {
                        moveVertically(SPEED * 3, casinoRoom);
                    }
                    else
                    {
                        moveVertically((SPEED * 3) / 2, casinoRoom);
                    }
                }
                if (player.position.X < rect.X)
                {
                    if (hourglassActive == false)
                    {
                        moveHorizontally(SPEED * 3, casinoRoom);
                    }
                    else
                    {
                        moveHorizontally((SPEED * 3) / 2, casinoRoom);
                    }
                }
                if (player.position.X > rect.X)
                {
                    if (hourglassActive == false)
                    {
                        moveHorizontally(SPEED * -3, casinoRoom);
                    }
                    else
                    {
                        moveHorizontally((SPEED * -3) / 2, casinoRoom);
                    }
                }
                if (!playerNear(player)) //Once they are far away they will again become aggressive
                {
                    status = robberState.IDLE;
                }
            }

            if (gameTime.TotalGameTime.Milliseconds % 100 == 0)
            {
                if (frameIndex == 2) //change the animation frame
                {
                    frameIndex = 0;
                }
                else
                {
                    frameIndex++;
                }
            }
        }

        private bool playerNear(Player player) //returns true if the player is near enough to chase, false otherwise
        {
            int Xproximity = Math.Abs((int)player.position.X - rect.X);
            int Yproximity = Math.Abs((int)player.position.Y - rect.Y);

            if (Xproximity < 150 && Yproximity < 150)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(spriteSheet, rect, current, Color.White);
        }
    }
}

