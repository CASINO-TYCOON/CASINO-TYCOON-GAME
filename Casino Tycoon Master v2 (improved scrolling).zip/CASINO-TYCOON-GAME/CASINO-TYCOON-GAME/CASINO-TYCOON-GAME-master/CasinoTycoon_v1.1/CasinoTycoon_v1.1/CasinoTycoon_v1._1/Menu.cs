﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    abstract class Menu
    {
        protected Rectangle rect;
        protected Texture2D texture;
        protected Rectangle selector;
        protected Texture2D selectorT;
        protected KeyboardState oldKb;
        protected GamePadState oldGp;
        protected List<MenuButton> buttons;
        protected int selected;
        protected int speed = 5;

        public Menu(ContentManager Content)
        {
            buttons = new List<MenuButton>();
            selected = 0;
            oldKb = Keyboard.GetState(PlayerIndex.One);
            oldGp = GamePad.GetState(PlayerIndex.One);
        }

        public abstract void Load(ContentManager Content);

        public String Update()
        {
            return selection();
        }

        public String selection()
        {
            KeyboardState kb = Keyboard.GetState();
            GamePadState  gp = GamePad.GetState(PlayerIndex.One);

            String toReturn = "";

            if (Input.keyPressDown(kb, gp, oldKb, oldGp))
            {
                if (selected == buttons.Count - 1) { selected = -1; }
                selected++;
            }
            else if (Input.keyPressUp(kb, gp, oldKb, oldGp))
            {
                if (selected == 0) { selected = buttons.Count; }
                selected--;
            }
            else if (Input.keyPressEnter(kb, gp, oldKb, oldGp) || Input.keyPressSpace(kb, gp, oldKb, oldGp))
            {
                toReturn = execute();
            }
            selector.Y = buttons[selected].rect.Y - 10;

            oldKb = kb;
            oldGp = gp;
            
            
            return toReturn;
        }

        public abstract String execute();

        private void move(int amt)
        {
            rect.Y += amt;
            for (int i = 0; i < buttons.Count; i++)
            {
                buttons[i].setRectangle(new Rectangle(buttons[i].rect.X, buttons[i].rect.Y + amt, buttons[i].rect.Width, buttons[i].rect.Height));
            }
        }

        public abstract void Draw(SpriteBatch spriteBatch);
    }
}
