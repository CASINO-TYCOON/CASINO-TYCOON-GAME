﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Player
    {
        // Sprite Sheet Dimensions -> Width: 96 : Height: 128

        // Src rectangles
        Rectangle[] locs;
        int current;
        // Main Rectangle
        public Vector2 position;
        // Texture
        public Texture2D spriteSheet;

        Animation playerAnimation;
        Vector2 tempCurrentFrame;
        KeyboardState kb;
        GamePadState gp;
        float moveSpeed;

        int screenWidth;
        int screenHeight;

        public int width;
        public int height;

        public Rectangle feet;
        Texture2D feetTest;

        private int money = 10000;

        public Player(int sW, int sH) {
            width = height = 50;
            position = new Vector2(100, 100);
            screenWidth = sW;
            screenHeight = sH;
            //current = 1;
            //locs = new Rectangle[] {new Rectangle(0, 0, 32, 32), new Rectangle(32, 0, 32, 32), new Rectangle(64, 0, 32, 32),
            //                        new Rectangle(0, 32, 32, 32), new Rectangle(32, 32, 32, 32), new Rectangle(64, 32, 32, 32),
            //                        new Rectangle(0, 64, 32, 32), new Rectangle(32, 64, 32, 32), new Rectangle(64, 64, 32, 32),
            //                        new Rectangle(0, 96, 32, 32), new Rectangle(32, 96, 32, 32), new Rectangle(64, 96, 32, 32)};

            playerAnimation = new Animation(position, new Vector2(3, 4), width, height);        
            tempCurrentFrame = Vector2.Zero;
            moveSpeed = 100f;
            feet = new Rectangle((int)position.X + 18, (int)position.Y + height - 10, width - 33, 10);
        }

        public void loadContent(ContentManager Content)
        {
            spriteSheet = Content.Load<Texture2D>("Player/playerMale");
            feetTest = Content.Load<Texture2D>("Slot");
            playerAnimation.AnimationImage = spriteSheet;
        }

        public void Update(GameTime gameTime, Casino casino)
        {
            kb = Keyboard.GetState();
            gp = GamePad.GetState(PlayerIndex.One);
            playerAnimation.Active = true;
            
            position = playerAnimation.Position;

            Rectangle pos = new Rectangle((int)position.X, (int)position.Y, width, height);

            if (Input.shift(kb, gp))
                moveSpeed = 250f;
            else
                moveSpeed = 100f;



            if (Input.down(kb, gp) && position.Y + height < screenHeight)
            {
                if(casino.downScroll)
                {
                    if (!casino.collision(new Rectangle(feet.X, (int)(feet.Y + moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds), feet.Width, feet.Height)))
                    {
                        position.Y += moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                    }
                    feet = new Rectangle((int)position.X + 17, (int)position.Y + height - 10, width - 33, 10);
                }

                //error correction if the player somehow ends up slightly inside collision
                if (casino.collision(feet))
                {
                    position.Y += 5;
                    feet.Y += 5;
                }

                tempCurrentFrame.Y = 0;
            }
            else if (Input.up(kb, gp) && position.Y > 0)
            {
                if (casino.upScroll)
                {
                    if (!casino.collision(new Rectangle(feet.X, (int)(feet.Y - moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds), feet.Width, feet.Height)))
                    {
                        position.Y -= moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                    }
                    feet = new Rectangle((int)position.X + 17, (int)position.Y + height - 12, width - 33, 10);
                }

                //error correction if the player somehow ends up slightly inside collision
                if (casino.collision(feet))
                {
                    position.Y -= 5;
                    feet.Y -= 5;
                }

                tempCurrentFrame.Y = 3;
            }
            else if (Input.right(kb, gp) && position.X + width < screenWidth)
            {
                if (casino.rightScroll)
                {
                    if (!casino.collision(new Rectangle((int)(feet.X + moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds), feet.Y, feet.Width, feet.Height)))
                    {
                        position.X += moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                    }
                    feet = new Rectangle((int)position.X + 20, (int)position.Y + height - 10, width - 35, 7);
                }

                //error correction if the player somehow ends up slightly inside collision
                if (casino.collision(feet))
                {
                    position.X -= 5;
                    feet.X -= 5;
                }

                tempCurrentFrame.Y = 2;
            }
            else if (Input.left(kb, gp) && position.X > 0)
            {
                if (casino.leftScroll)
                {
                    if (!casino.collision(new Rectangle((int)(feet.X - moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds), feet.Y, feet.Width, feet.Height)))
                    {
                        position.X -= moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                    }
                    feet = new Rectangle((int)position.X + 17, (int)position.Y + height - 10, width - 35, 7);
                }

                //error correction if the player somehow ends up slightly inside collision
                if (casino.collision(feet))
                {
                    position.X += 5;
                    feet.X += 5;
                }

                tempCurrentFrame.Y = 1;
            }
            else
            {
                playerAnimation.Active = false;
            }
            tempCurrentFrame.X = playerAnimation.CurrentFrame.X;


            playerAnimation.Position = position;
            playerAnimation.CurrentFrame = tempCurrentFrame;

            playerAnimation.Update(gameTime);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            playerAnimation.Draw(spriteBatch);
            //spriteBatch.Draw(feetTest, feet, Color.White);
        }

        public Vector2 Origin
        {
            get { return new Vector2(position.X + width / 2, position.Y + width / 2); }
        }

        public void adjustMoney(int adjustBy)
        {
            this.money += adjustBy;
        }
        public int getMoney() { return money; }
    }
}
