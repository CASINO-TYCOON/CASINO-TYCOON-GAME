﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    class Collectable
    {
        private Texture2D[] textures;
        public Texture2D currentTexture;
        public string name;

        public enum collectableType //Value accessed by the main logic class. Can be used to determine what the collectable should do
        {
            coin, //Add $1
            dollar, //Add $50
            moneybag //Add $200
        }

        public enum collectableStatus //Value accessed by the main logic class. Can be used to determine what the collectable should do
        {
            ground, //The item is on the ground and waits to be used.
            used //It is used and will not be drawn anymore, and will be removed from the list of collectables in a room.
        }

        private static int width = 40;
        private static int height = 40;
        public Vector2 location;

        public collectableType type;
        public collectableStatus status;

        public Collectable(Vector2 location2, collectableType type2)
        {
            location = location2;

            type = type2;
            status = collectableStatus.ground;
        }

        public void loadContent(ContentManager Content)
        {
            textures = new Texture2D[3];
            textures[0] = Content.Load<Texture2D>("Items/Collectable/coin");
            textures[1] = Content.Load<Texture2D>("Items/Collectable/dollar");
            textures[2] = Content.Load<Texture2D>("Items/Collectable/moneyBag");

            if (type == collectableType.coin)
            {
                name = "Coin";
                currentTexture = textures[0];
            }
            if (type == collectableType.dollar)
            {
                name = "Dollar";
                currentTexture = textures[1];
            }
            if (type == collectableType.moneybag)
            {
                name = "Moneybag";
                currentTexture = textures[2];
            }
        }

        public void use(Player player) //Apply an effect based on the type
        {
            if (type == collectableType.coin)
            {
                player.adjustMoney(10);
                status = collectableStatus.used;
            }
            if (type == collectableType.dollar)
            {
                player.adjustMoney(50);
                status = collectableStatus.used;
            }
            if (type == collectableType.moneybag)
            {
                player.adjustMoney(500);
                status = collectableStatus.used;
            }
        }

        public bool canGrab(Player player) //Returns true if the player is able to pick the collectable up
        {
            if (new Rectangle((int)player.position.X, (int)player.position.Y, player.width, player.height).Intersects(new Rectangle((int)location.X, (int)location.Y, width, height)))
            {
                return true;
            }
            return false;
        }

        public void draw(SpriteBatch spriteBatch)
        {
            if (status == collectableStatus.ground)
            {
                spriteBatch.Draw(currentTexture, new Rectangle((int)location.X, (int)location.Y, width, height), Color.White);
            }
        }
    }
}
