﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class GameSelection : Menu
    {

        String version;

        public GameSelection(String v, ContentManager Content) : base(Content)
        {
            version = v;
            Load(Content);
        }

        public new String Update()
        {
            return selection();
        }

        public override void Load(ContentManager Content)
        {
            if (version.Equals("arcade"))
            {
                buttons.Add(new MenuButton("Slots", Content));
                buttons.Add(new MenuButton("Frogger", Content));
                buttons.Add(new MenuButton("Exit Menu", Content));
            }
            else if (version.Equals("board"))
            {
                buttons.Add(new MenuButton("Poker", Content));
                buttons.Add(new MenuButton("Blackjack", Content));
                buttons.Add(new MenuButton("Chess", Content));
                buttons.Add(new MenuButton("Exit Menu", Content));
            }

            for (int i = 0; i < buttons.Count; i++)
            {
                buttons[i].setRectangle(new Rectangle(300, 250 + i * 50, 100, 50));
            }
            selector = new Rectangle(buttons[0].rect.X - 10, buttons[0].rect.Y, 110, 50);
            rect = new Rectangle(buttons[0].rect.X - 10, buttons[0].rect.Y - 10, buttons[0].rect.Width + 10, buttons.Count*50);
            selectorT = Content.Load<Texture2D>("Menu/Selector");
            texture = Content.Load<Texture2D>("Menu/menu");
        }

        public override string execute()
        {
            return buttons[selected].name;
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture, rect, Color.White);
            for (int i = 0; i < buttons.Count; i++)
            {
                buttons[i].Draw(spriteBatch);
            }
            spriteBatch.Draw(selectorT, selector, Color.White);
            spriteBatch.End();
        }
    }
}
