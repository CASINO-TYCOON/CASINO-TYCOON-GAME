﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Frog
    {
        enum Direction
        {
            Up, Down, Left, Right, None
        }
        public Rectangle pos;
        private Vector2 v;
        private Rectangle[] animJumpStraight = new Rectangle[] {
            new Rectangle(18, 18, 12, 12), //midjump straight
            new Rectangle(43, 18, 10, 14), //beg/end jump straight
            new Rectangle(66, 19, 12, 9), //stationary straight
        };
        private Rectangle[] animJumpSide = new Rectangle[] {
            new Rectangle(90, 18, 13, 12), //midjump side
            new Rectangle(114, 19, 13, 10), //beg/end jump side
            new Rectangle(139, 18, 9, 12), //stationary side
        };
        private Texture2D sheet;
        private SpriteBatch spriteBatch;
        private int frameCounter;
        private bool jumping;
        private float moveByX;
        private float moveByY;
        private SpriteEffects effects;
        private Rectangle source;
        private Direction jumpDirection;
        private int coolDown;
        private float i;
        private int animTime;
        private int screenWidth;
        private int screenHeight;
        private int lives;
        private Rectangle startPos;
        private bool gameover;
        private SoundEffect hop;
        public int velocity;

        public Frog(Rectangle pos, Texture2D sheet, SpriteBatch spriteBatch, int screenWidth, int screenHeight)
        {
            this.pos = pos;
            this.sheet = sheet;
            this.spriteBatch = spriteBatch;
            this.moveByX = 51;
            this.moveByY = 60;
            this.effects = SpriteEffects.None;
            this.source = animJumpStraight[2];
            this.v = new Vector2(pos.X, pos.Y);
            this.animTime = 15;
            this.screenWidth = screenWidth;
            this.screenHeight = screenHeight;
            this.lives = 0;
            this.startPos = pos;
        }
        public Rectangle Update(GameTime gameTime)
        {
            if (!gameover)
            {
                KeyboardState kb = Keyboard.GetState();
                if (!jumping)
                {
                    if (coolDown != 0)
                    {
                        coolDown--;
                        return pos;
                    }
                    if (kb.IsKeyDown(Keys.Up) && !wouldBeOffScreen(Direction.Up))
                    {
                        jumping = true;
                        effects = SpriteEffects.None;
                        jumpDirection = Direction.Up;
                        hop.Play();
                    }
                    else if (kb.IsKeyDown(Keys.Down) && !wouldBeOffScreen(Direction.Down))
                    {
                        jumping = true;
                        effects = SpriteEffects.FlipVertically;
                        jumpDirection = Direction.Down;
                        hop.Play();
                    }
                    else if (kb.IsKeyDown(Keys.Left) && !wouldBeOffScreen(Direction.Left))
                    {
                        jumping = true;
                        effects = SpriteEffects.None;
                        jumpDirection = Direction.Left;
                        hop.Play();
                    }
                    else if (kb.IsKeyDown(Keys.Right) && !wouldBeOffScreen(Direction.Right))
                    {
                        jumping = true;
                        effects = SpriteEffects.FlipHorizontally;
                        jumpDirection = Direction.Right;
                        hop.Play();
                    }
                    frameCounter = 0;
                }
                else
                {
                    if ((int)jumpDirection < 2)
                    {
                        if (frameCounter == 0)
                        {
                            source = animJumpStraight[0];
                        }
                        if (frameCounter == animTime)
                        {
                            source = animJumpStraight[2];
                            jumpDirection = Direction.None;
                            jumping = false;
                            coolDown = 3;
                            return pos;
                        }
                        //if (frameCounter == animTime / 5)
                        //{
                        //    source = animJumpStraight[1];
                        //}
                        //if (frameCounter == animTime / 5 * 2)
                        //{
                        //    source = animJumpStraight[0];
                        //}
                        //if (frameCounter == animTime / 5 * 4)
                        //{
                        //    source = animJumpStraight[2];
                        //}
                        //if (frameCounter == animTime)
                        //{
                        //    source = animJumpStraight[2];
                        //    jumpDirection = Direction.None;
                        //    jumping = false;
                        //    coolDown = 3;
                        //    return pos;
                        //}
                        if ((int)jumpDirection == 0)
                        {
                            v.Y -= moveByY / animTime;
                        }
                        else
                        {
                            v.Y += moveByY / animTime;
                        }
                    }
                    else
                    {
                        //if (frameCounter == animTime / 5)
                        //{
                        //    source = animJumpSide[1];
                        //}
                        //if (frameCounter == animTime / 5 * 2)
                        //{
                        //    source = animJumpSide[0];
                        //}
                        //if (frameCounter == animTime / 5 * 4)
                        //{
                        //    source = animJumpSide[2];
                        //}
                        //if (frameCounter == animTime)
                        //{
                        //    source = animJumpSide[2];
                        //    jumpDirection = Direction.None;
                        //    jumping = false;
                        //    coolDown = 3;
                        //    return pos;
                        //}
                        if (frameCounter == 0)
                        {
                            source = animJumpSide[0];
                        }
                        if (frameCounter == animTime)
                        {
                            source = animJumpSide[2];
                            jumpDirection = Direction.None;
                            jumping = false;
                            coolDown = 3;
                            return pos;
                        }
                        if ((int)jumpDirection == 2)
                        {
                            v.X -= moveByY / animTime;
                        }
                        else
                        {
                            v.X += moveByY / animTime;
                        }
                    }
                    frameCounter++;
                }
            }
            v.X += velocity;
            pos.X = (int)v.X;
            pos.Y = (int)v.Y;
            return pos;
        }
        public void Draw(GameTime gameTime)
        {
            spriteBatch.Draw(this.sheet, this.pos, source, Color.White, 0f, new Vector2(0, 0), effects, 0);
        }
        public void setHopSound(SoundEffect hop)
        {
            this.hop = hop;
        }
        public void setLives(int lives)
        {
            this.lives = lives;
        }
        public void gameOver()
        {
            gameover = true;
        }
        public void forceMove(int dir)
        {
            if (dir==0 && !wouldBeOffScreen(Direction.Up))
            {
                jumping = true;
                effects = SpriteEffects.None;
                jumpDirection = Direction.Up;
            }
            else if (dir==1 && !wouldBeOffScreen(Direction.Down))
            {
                jumping = true;
                effects = SpriteEffects.FlipVertically;
                jumpDirection = Direction.Down;
            }
            else if (dir==2 && !wouldBeOffScreen(Direction.Left))
            {
                jumping = true;
                effects = SpriteEffects.None;
                jumpDirection = Direction.Left;
            }
            else if (dir==3 && !wouldBeOffScreen(Direction.Right))
            {
                jumping = true;
                effects = SpriteEffects.FlipHorizontally;
                jumpDirection = Direction.Right;
            }
            frameCounter = 0;
        }
        public void reset()
        {
            coolDown = 15;
            pos = startPos;
            source = animJumpStraight[2];
            v.X = pos.X;
            v.Y = pos.Y;
            effects = SpriteEffects.None;
            jumpDirection = Direction.None;
            jumping = false;
        }
        public bool loseLife()
        {
            reset();
            lives--;
            return lives == 0;
        }
        public bool isJumping() { return jumping; }
        private bool wouldBeOffScreen(Direction dir)
        {
            if (dir == Direction.Up)
            {
                return false;
            }
            if (dir == Direction.Down)
            {
                return pos.Y + pos.Height + moveByY >= screenHeight;
            }
            if (dir == Direction.Left)
            {
                return pos.X - moveByX <= 0;
            }
            if (dir == Direction.Right)
            {
                return pos.X + pos.Width + moveByX >= screenWidth;
            }
            return true;
        }
    }
}
