﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    class InteractiveSpot
    {
        public Rectangle rect;
        public static bool visible = true; //The spots will never be visible during the final game but it is helpful to see them when developing
        Texture2D testTexture;

        public enum InteractiveType //designates what the spot will do when used
        {
            Poker, //play poker
            Blackjack, //play blackjack
            Frogger, //play frogger
            NPCtalk //talk to an NPC
        }
        public InteractiveType type;

        public InteractiveSpot(int x, int y, int width, int height, InteractiveType type2)
        {
            rect = new Rectangle(x, y, width, height);
            type = type2;
        }

        public void loadContent(ContentManager Content)
        {
            testTexture = Content.Load<Texture2D>("Inventory/WhiteColor");
        }

        public bool playerInsideSpot(Player player)
        {
            if (new Rectangle((int) player.position.X, (int) player.position.Y, player.width, player.height).Intersects(rect))
            {
                return true;
            }

            return false;
        }
        
        public void draw(SpriteBatch spriteBatch) //only does something during debugging phase
        {
            if(visible)
            {
                spriteBatch.Draw(testTexture, rect, Color.Red);
            }
        }
    }
}
