﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    class Casino
    {
        //pixel values for the width and height of the room
        public int width;
        public int height;

        List<List<Tile>> casinoMap;
        Rectangle pokerTable;
        Texture2D pokerTableTexture;
        public enum Direction { up, down, left, right};
        MapReader casinoMapReader;

        //entities found in the room
        public List<Robber> robberList;
        public List<PowerUp> powerUpList;
        public List<Collectable> collectableList;
        public List<InteractiveSpot> spotsList;


        public Casino(ContentManager Content, Player player)
        {
            casinoMapReader = new MapReader(@"Content/Casino/casinoLayout.txt", Content, player);
            casinoMap = casinoMapReader.tiles;

            robberList = casinoMapReader.robberList;
            powerUpList = casinoMapReader.powerUpList;
            collectableList = casinoMapReader.collectableList;
            spotsList = casinoMapReader.spotsList;

            width = casinoMap.Count * 50;
            height = casinoMap[0].Count * 50;
        }

        public void updateEntities(GameTime gameTime, KeyboardState kb, KeyboardState oldKB, Wallet wallet, Inventory inventory, Player player) //apply update logic to all the entities in the room
        {
            //robber update logic
            for (int i = 0; i < robberList.Count; i++)
            {
                robberList[i].update(gameTime, this, wallet, inventory.activeItems);
            }

            //powerUp update logic
            for (int i = 0; i < powerUpList.Count; i++)
            {
                if (powerUpList[i].active)
                {
                    powerUpList[i].update();
                }
                if (powerUpList[i].status == PowerUp.powerUpStatus.ground)
                {
                    if (powerUpList[i].canGrab(player) && kb.IsKeyDown(Keys.E) && !oldKB.IsKeyDown(Keys.E))
                    {
                        if (inventory.addItem(powerUpList[i]) == true)
                        {
                            powerUpList[i].status = PowerUp.powerUpStatus.inventory;
                        }
                    }
                }
            }

            //collectable update logic
            for (int i = 0; i < collectableList.Count; i++)
            {
                if (collectableList[i].status == Collectable.collectableStatus.ground)
                {
                    if (collectableList[i].canGrab(player) && kb.IsKeyDown(Keys.E) && !oldKB.IsKeyDown(Keys.E))
                    {
                        collectableList[i].use(wallet);
                    }
                }
            }

        }


        public void move(Direction direction)
        {
            KeyboardState kb = Keyboard.GetState(PlayerIndex.One);
            GamePadState gp = GamePad.GetState(PlayerIndex.One);

            if(direction == Direction.right && casinoMap[0][casinoMap[0].Count - 1].rect.X > 700 && Input.right(kb, gp))
            {
                for(int i = 0; i < casinoMap.Count; i++)
                {
                    for(int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.X -= 5;
                    }
                }
                for (int x = 0; x < robberList.Count; x++)
                {
                    robberList[x].rect.X -= 5;
                }
                for (int x = 0; x < powerUpList.Count; x++)
                {
                    powerUpList[x].location.X -= 5;
                }
                for (int x = 0; x < collectableList.Count; x++)
                {
                    collectableList[x].location.X -= 5;
                }
                for (int x = 0; x < spotsList.Count; x++)
                {
                    spotsList[x].rect.X -= 5;
                }
            }

            
            if (direction == Direction.left && casinoMap[0][0].rect.X < 0 && Input.left(kb, gp))
            {
                for (int i = 0; i < casinoMap.Count; i++)
                {
                    for (int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.X += 5;
                    }
                }
                for (int x = 0; x < robberList.Count; x++)
                {
                    robberList[x].rect.X += 5;
                }
                for (int x = 0; x < powerUpList.Count; x++)
                {
                    powerUpList[x].location.X += 5;
                }
                for (int x = 0; x < collectableList.Count; x++)
                {
                    collectableList[x].location.X += 5;
                }
                for (int x = 0; x < spotsList.Count; x++)
                {
                    spotsList[x].rect.X += 5;
                }
            }
            
            if (direction == Direction.up && casinoMap[0][0].rect.Y < 0 && Input.up(kb, gp))
            {
                for (int i = 0; i < casinoMap.Count; i++)
                {
                    for (int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.Y += 5;
                    }
                }
                for (int x = 0; x < robberList.Count; x++)
                {
                    robberList[x].rect.Y += 5;
                }
                for (int x = 0; x < powerUpList.Count; x++)
                {
                    powerUpList[x].location.Y += 5;
                }
                for (int x = 0; x < collectableList.Count; x++)
                {
                    collectableList[x].location.Y += 5;
                }
                for (int x = 0; x < spotsList.Count; x++)
                {
                    spotsList[x].rect.Y += 5;
                }
            }
            //Console.WriteLine(casinoMapRect[casinoMapRect.GetLength(0) - 1, 0].Y);
            if (direction == Direction.down && casinoMap[casinoMap.Count-2][0].rect.Y > 500 && Input.down(kb, gp))
            {
                for (int i = 0; i < casinoMap.Count; i++)
                {
                    for (int j = 0; j < casinoMap[i].Count; j++)
                    {
                        casinoMap[i][j].rect.Y -= 5;
                    }
                }
                for (int x = 0; x < robberList.Count; x++)
                {
                    robberList[x].rect.Y -= 5;
                }
                for (int x = 0; x < powerUpList.Count; x++)
                {
                    powerUpList[x].location.Y -= 5;
                }
                for (int x = 0; x < collectableList.Count; x++)
                {
                    collectableList[x].location.Y -= 5;
                }
                for (int x = 0; x < spotsList.Count; x++)
                {
                    spotsList[x].rect.Y -= 5;
                }
            }
        }

        public Boolean collision(Rectangle feet)
        {
            Boolean collision = false;
            for(int i = 0; i < casinoMap.Count; i++)
            {
                for(int j = 0; j < casinoMap[i].Count; j++)
                {
                    Rectangle currRect = casinoMap[i][j].rect;
                    if(feet.Intersects(currRect) && casinoMap[i][j].isObstacle)
                    {
                        collision = true;
                    }
                }
            }
            return collision;
        }

        public void Draw(SpriteBatch sb)
        {
            sb.Begin();
            for(int i = 0; i < casinoMap.Count; i++)
            {
                for(int j = 0; j < casinoMap[i].Count; j++)
                {
                    Texture2D currText = casinoMap[i][j].texture;
                    Rectangle currRect = casinoMap[i][j].rect;
                    sb.Draw(currText, currRect, Color.White);
                }
            }
            
            //draw interactive spots (if visible)
            for (int i = 0; i < spotsList.Count; i++)
            {
                spotsList[i].draw(sb);
            }

            //draw powerUps and Collectables
            for (int i = 0; i < powerUpList.Count; i++)
            {
                powerUpList[i].draw(sb);
            }
            for (int i = 0; i < collectableList.Count; i++)
            {
                collectableList[i].draw(sb);
            }

            //draw robbers
            for (int i = 0; i < robberList.Count; i++)
            {
                robberList[i].draw(sb);
            }

            sb.End();
            
        }
    }
}
