﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CasinoTycoon_v1._1
{
    class Wallet
    {
        public int value; 

        public Wallet()
        {
            value = 0;
        }

        public void add(int ammount) //Exactly what you think
        {
            value += ammount;
        }

        public bool subtract(int ammount) //You can't go in debt. Returns true if the transaction was made.
        {
            if(ammount <= value)
            {
                value -= ammount;
                return true;
            }
            return false;
        }
    }
}
