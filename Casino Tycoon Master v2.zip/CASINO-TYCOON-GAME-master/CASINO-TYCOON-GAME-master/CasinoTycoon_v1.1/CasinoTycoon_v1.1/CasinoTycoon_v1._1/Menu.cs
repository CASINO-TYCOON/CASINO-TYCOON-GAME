﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Menu
    {
        Rectangle rect;
        Texture2D texture;
        Rectangle selector;
        Texture2D selectorT;
        KeyboardState oldKb;
        GamePadState oldGp;
        Rectangle balance;
        Texture2D balanceT;
        SpriteFont balanceF;
        List<MenuButton> buttons;
        int money;
        int selected;
        int speed = 5;

        public Menu(ContentManager Content)
        {
            buttons = new List<MenuButton>();
            selected = 0;
            oldKb = Keyboard.GetState(PlayerIndex.One);
            oldGp = GamePad.GetState(PlayerIndex.One);
            Load(Content);
        }

        public void Load(ContentManager Content)
        {
            buttons.Add(new MenuButton("Profile", Content));
            buttons.Add(new MenuButton("Inventory", Content));
            buttons.Add(new MenuButton("Save", Content));
            buttons.Add(new MenuButton("Quit", Content));
            buttons.Add(new MenuButton("Exit Menu", Content));
            for (int i = 0; i < buttons.Count; i++)
            {
                buttons[i].setRectangle(new Rectangle(590, 20 + i * 50, 100, 50));
            }
            selector = new Rectangle(buttons[0].rect.X - 10, buttons[0].rect.Y, 110, 50);
            rect = new Rectangle(buttons[0].rect.X - 10, buttons[0].rect.Y - 10, buttons[0].rect.Width + 10, buttons[buttons.Count - 1].rect.Y + buttons[buttons.Count - 1].rect.Height - 20);
            balance = new Rectangle(rect.X, rect.Y + rect.Height + 10, 110, 110);
            selectorT = Content.Load<Texture2D>("Menu/Selector");
            texture = Content.Load<Texture2D>("Menu/menu");
            balanceT = Content.Load<Texture2D>("Menu/Balance");
            balanceF = Content.Load<SpriteFont>("Menu/SpriteFont2");
        }

        public String Update(int money, Inventory inventory)
        {
            this.money = money;
            return selection(inventory);
        }

        public String selection(Inventory inventory)
        {
            KeyboardState kb = Keyboard.GetState();
            GamePadState  gp = GamePad.GetState(PlayerIndex.One);

            String toReturn = "";

            if (inventory.status == Inventory.InventoryStatus.inactive)
            {
                if (Input.keyPressDown(kb, gp, oldKb, oldGp))
                {
                    if (selected == buttons.Count - 1) { selected = 0; }
                    selected++;
                }
                else if (Input.keyPressUp(kb, gp, oldKb, oldGp))
                {
                    if (selected == 0) { selected = buttons.Count - 1; }
                    selected--;
                }
                else if (Input.keyPressEnter(kb, gp, oldKb, oldGp))
                {
                    toReturn = execute();
                }
                selector.Y = buttons[selected].rect.Y - 10;

                oldKb = kb;
                oldGp = gp;
            }
            
            return toReturn;
        }

        public String execute()
        {
            if (buttons[selected].name.Equals("Quit"))
            {
                return "Quit";
            }
            if (buttons[selected].name.Equals("Exit Menu"))
            {
                return "Exit Menu";
            }
            if (buttons[selected].name.Equals("Profile"))
            {
                return "Profile";
            }
            if (buttons[selected].name.Equals("Inventory"))
            {
                return "Inventory";
            }
            if (buttons[selected].name.Equals("Save"))
            {
                return "Save";
            }
            return "";
        }

        private void move(int amt)
        {
            rect.Y += amt;
            for (int i = 0; i < buttons.Count; i++)
            {
                buttons[i].setRectangle(new Rectangle(buttons[i].rect.X, buttons[i].rect.Y + amt, buttons[i].rect.Width, buttons[i].rect.Height));
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();

            // Menu
            spriteBatch.Draw(texture, rect, Color.White);
            for (int i = 0; i < buttons.Count; i++)
            {
                buttons[i].Draw(spriteBatch);
            }
            spriteBatch.Draw(selectorT, selector, Color.White);

            // Balance
            spriteBatch.Draw(balanceT, balance, Color.White);
            spriteBatch.DrawString(balanceF, money + "", new Vector2(balance.X + 20, balance.Y + 70), Color.DarkGreen);

            spriteBatch.End();
        }
    }
}
