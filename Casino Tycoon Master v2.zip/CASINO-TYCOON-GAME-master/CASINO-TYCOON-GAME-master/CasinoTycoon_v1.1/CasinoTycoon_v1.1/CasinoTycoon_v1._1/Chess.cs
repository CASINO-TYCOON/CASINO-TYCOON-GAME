﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;

namespace CasinoTycoon_v1._1
{
    class Chess
    {
        SpriteBatch spriteBatch;

        KeyboardState oldKB;
        MouseState oldM;

        Texture2D[] boards;
        Texture2D[] images;
        Texture2D turnIndicator;

        Color[] turnn;
        Colour[] colors;

        Rectangle full;
        Rectangle[] rects;
        Rectangle[] boardRects;
        Rectangle[,] allRects;
        Rectangle locMouse;
        Rectangle lowerRight;

        Piece[] pieces;
        Piece[,] pieceLocations;

        int timer, timer2;
        int x, y;
        int board; //index of which boards chosen
        int turn; //index of which turnIndicators to use
        int moveCount;
        int wKingR, wKingC, wKingI;
        int bKingR, bKingC, bKingI;

        bool selected;
        bool flashing;
        bool test1;
        bool test2;
        bool test3;
        bool started;
        bool start;
        bool canWhiteCastleLeft;
        bool canWhiteCastleRight;
        bool canBlackCastleLeft;
        bool canBlackCastleRight;
        bool whiteInCheck;
        bool blackInCheck;

        int selectRow;
        int selectCol;
        int selectInd;

        Vector2 vec;
        Vector2 startVec;
        SpriteFont font;
        SpriteFont font2;

        int[] retted;

        String notation;

        String[] letters;

        Vector2 bottomOfScreen;

        private int screenWidth, screenHeight;

        public Chess(SpriteFont font, SpriteFont font2, Texture2D turnIndicator, Texture2D[] images, Texture2D[] boards, SpriteBatch spriteBatch, int screenWidth, int screenHeight)
        {
            this.screenWidth = screenWidth;
            this.screenHeight = screenHeight;
            this.font = font;
            this.font2 = font2;
            this.turnIndicator = turnIndicator;
            canWhiteCastleLeft = true;
            canWhiteCastleRight = true;
            canBlackCastleLeft = true;
            canBlackCastleRight = true;
            selectRow = -1;
            selectCol = -1;
            selectInd = -1;
            wKingR = 7; wKingC = 4;
            bKingR = 0; bKingC = 4;
            full = new Rectangle(0, 0, screenWidth, screenHeight);
            locMouse = new Rectangle(0, 0, 50, 50);
            lowerRight = new Rectangle(925, 925, 50, 50);
            pieces = new Piece[32];
            this.images = images;
            rects = new Rectangle[32];
            pieceLocations = new Piece[8, 8];
            turnn = new Color[2];
            turnn[0] = Color.White;
            turnn[1] = Color.Black;
            colors = new Colour[2];
            colors[0] = Colour.WHITE;
            colors[1] = Colour.BLACK;
            this.boards = boards;
            boardRects = new Rectangle[boards.Length];
            boardRects[0] = new Rectangle(100, 100, 300, 300);
            boardRects[1] = new Rectangle(600, 100, 300, 300);
            boardRects[2] = new Rectangle(100, 600, 300, 300);
            boardRects[3] = new Rectangle(600, 600, 300, 300);
            letters = new String[8];
            letters[0] = "a";
            letters[1] = "b";
            letters[2] = "c";
            letters[3] = "d";
            letters[4] = "e";
            letters[5] = "f";
            letters[6] = "g";
            letters[7] = "h";
            allRects = new Rectangle[8, 8];
            for (int i = 1; i < 9; i++)
            {
                for (int j = 1; j < 9; j++)
                {
                    allRects[i - 1, j - 1] = new Rectangle(100 * j, 100 * i, 100, 100);
                }
            }
            vec = new Vector2(510, 450);
            startVec = new Vector2(83, 475);
            bottomOfScreen = new Vector2(360, 975);
            this.spriteBatch = spriteBatch;

            rects[0] = new Rectangle(100, 100, 100, 100);
            for (int i = 1; i < 8; i++)
            {
                rects[i] = new Rectangle(rects[i - 1].X + 100, 100, 100, 100);
            }
            for (int i = 8; i < 16; i++)
            {
                rects[i] = new Rectangle(rects[i - 8].X, 200, 100, 100);
            }
            for (int i = 16; i < 24; i++)
            {
                rects[i] = new Rectangle(rects[i - 8].X, 700, 100, 100);
            }
            for (int i = 24; i < 32; i++)
            {
                rects[i] = new Rectangle(rects[i - 8].X, 800, 100, 100);
            }

            for (int i = 0; i < 5; i++)
            {
                pieces[i] = new Piece(images[i], rects[i]);
            }
            for (int i = 0; i < 3; i++)
            {
                pieces[i + 5] = new Piece(images[2 - i], rects[i + 5]);
            }
            for (int i = 8; i < 16; i++)
            {
                pieces[i] = new Piece(images[5], rects[i]);
            }
            for (int i = 16; i < 24; i++)
            {
                pieces[i] = new Piece(images[11], rects[i]);
            }
            for (int i = 24; i < 29; i++)
            {
                pieces[i] = new Piece(images[i - 18], rects[i]);
            }
            for (int i = 29; i < 32; i++)
            {
                pieces[29 + (i - 29)] = new Piece(images[8 - (i - 29)], rects[29 + (i - 29)]);
            }
            int counter = 0;
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    pieceLocations[i, j] = pieces[counter];
                    counter++;
                }
            }
            for (int i = 6; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    pieceLocations[i, j] = pieces[counter];
                    counter++;
                }
            }
            pieces[0].setType(ChessPiece.ROOK);
            pieces[1].setType(ChessPiece.KNIGHT);
            pieces[2].setType(ChessPiece.BISHOP);
            pieces[3].setType(ChessPiece.QUEEN);
            pieces[4].setType(ChessPiece.KING);
            pieces[5].setType(ChessPiece.BISHOP);
            pieces[6].setType(ChessPiece.KNIGHT);
            pieces[7].setType(ChessPiece.ROOK);
            for (int i = 8; i < 16; i++)
                pieces[i].setType(ChessPiece.PAWN);
            pieces[16 + 8].setType(ChessPiece.ROOK);
            pieces[17 + 8].setType(ChessPiece.KNIGHT);
            pieces[18 + 8].setType(ChessPiece.BISHOP);
            pieces[19 + 8].setType(ChessPiece.QUEEN);
            pieces[20 + 8].setType(ChessPiece.KING);
            pieces[21 + 8].setType(ChessPiece.BISHOP);
            pieces[22 + 8].setType(ChessPiece.KNIGHT);
            pieces[23 + 8].setType(ChessPiece.ROOK);
            for (int i = 16; i < 24; i++)
                pieces[i].setType(ChessPiece.PAWN);
            for (int i = 0; i < 16; i++)
                pieces[i].setColor(Colour.BLACK);
            for (int i = 16; i < 32; i++)
                pieces[i].setColor(Colour.WHITE);
            /*      TO USE WITH "8401148_orig"
            int y = 90;
            rects[0] = new Rectangle(85, y, 95, 95);
            for (int i = 1; i < 8; i++)
            {
                rects[i] = new Rectangle(rects[i - 1].X + 105, y, rects[i - 1].Width, rects[i - 1].Height);
            }
            y += 103;
            for (int i = 8; i < 16; i++)
            {
                rects[i] = new Rectangle(rects[i - 8].X, y, rects[i - 8].Width, rects[i - 8].Height);
            }
            y += 518;
            for (int i = 16; i < 24; i++)
            {
                rects[i] = new Rectangle(rects[i - 8].X, y, rects[i - 8].Width, rects[i - 8].Height);
            }
            y += 103;
            for (int i = 24; i < 32; i++)
            {
                rects[i] = new Rectangle(rects[i - 8].X, y, rects[i - 8].Width, rects[i - 8].Height);
            }
            pieces[0] = new Piece(images[0], )*/
        }

        public void Update(GameTime gameTime)
        {
            MouseState mouse = Mouse.GetState();
            if (start)
            {
                timer2++;
            }
            if (timer2 > 30)
            {
                start = false;
                started = true;
                timer2 = -1;
            }
            if (started)
            {
                KeyboardState kb = Keyboard.GetState();
                retted = new int[3]; //will contain the prospective location to move piece after calling getPos
                if (selected)
                {
                    if (timer % 45 == 0)
                    {
                        flashing = false;
                    }
                    else
                    {
                        flashing = true;
                    }
                }
                if (mouse.LeftButton == ButtonState.Pressed
                    && oldM.LeftButton != ButtonState.Pressed)
                {
                    if (!selected)
                    {
                        x = mouse.X; y = mouse.Y;
                        selected = selectPiece(x, y);
                        if (selectInd == -1)
                            selected = false;
                        else if (pieces[selectInd].color != colors[turn])
                            selected = false;
                        timer = 0;
                        retted[0] = -10;
                    }
                    else
                    {
                        retted = getPos(mouse.X, mouse.Y); //retted[0] is the col, retted[1] is the row, retted[2] is the index
                        test2 = true;
                        if (retted[2] == selectInd || selectInd == -1)
                        {
                            selected = false;
                            test2 = false;
                        }
                    }
                }
                if (selected && test2)
                {
                    if (pieceLocations[retted[0], retted[1]] == null)
                    {
                        if (legalMove(retted))
                        {
                            pieceLocations[retted[0], retted[1]] = pieces[selectInd];
                            pieceLocations[selectRow, selectCol] = null;
                            bool whitInCheck = isWhiteInCheck();
                            bool blacInCheck = isBlackInCheck();
                            if (whiteInCheck || blacInCheck)
                            {
                                pieceLocations[retted[0], retted[1]] = null;
                                pieceLocations[selectRow, selectCol] = pieces[selectInd];
                            }
                            String check = "";
                            if (retted[0] < 0 || retted[1] < 0)
                            {
                                test1 = true;
                            }
                            else if (pieces[selectInd].color == colors[0]
                                     && !whitInCheck)
                            {
                                pieces[selectInd].rect = allRects[retted[0], retted[1]];
                                pieceLocations[retted[0], retted[1]] = pieces[selectInd];
                                pieceLocations[selectRow, selectCol] = null;
                                selected = false;
                                test2 = false;
                                whiteInCheck = isWhiteInCheck();
                                blackInCheck = isBlackInCheck();
                                turn = 1;
                                moveCount++;
                                notation = moveCount + ". ";
                                switch (pieces[selectInd].type)
                                {
                                    case ChessPiece.ROOK:
                                        notation += "R"; break;
                                    case ChessPiece.KNIGHT:
                                        notation += "N"; break;
                                    case ChessPiece.BISHOP:
                                        notation += "B"; break;
                                    case ChessPiece.QUEEN:
                                        notation += "Q"; break;
                                    case ChessPiece.KING:
                                        notation += "K"; break;
                                }
                                if (blackInCheck)
                                    check = "+";
                                notation += letters[retted[1]] + (8 - retted[0]) + check + "  ";
                                Debug.Write(notation);
                                notation = " ";
                            }
                            else if (pieces[selectInd].color == colors[1]
                                     && !blacInCheck)
                            {
                                pieces[selectInd].rect = allRects[retted[0], retted[1]];
                                pieceLocations[retted[0], retted[1]] = pieces[selectInd];
                                pieceLocations[selectRow, selectCol] = null;
                                selected = false;
                                test2 = false;
                                whiteInCheck = isWhiteInCheck();
                                blackInCheck = isBlackInCheck();
                                turn = 0;
                                switch (pieces[selectInd].type)
                                {
                                    case ChessPiece.ROOK:
                                        notation += "Rx"; break;
                                    case ChessPiece.KNIGHT:
                                        notation += "Nx"; break;
                                    case ChessPiece.BISHOP:
                                        notation += "Bx"; break;
                                    case ChessPiece.QUEEN:
                                        notation += "Qx"; break;
                                    case ChessPiece.KING:
                                        notation += "Kx"; break;
                                }
                                if (whiteInCheck)
                                    check = "+";
                                notation += letters[retted[1]] + (8 - retted[0]) + check + "  ";
                                Debug.Write(notation);
                            }
                            else
                            {
                                selected = false;
                                test2 = false;
                            }
                        }
                    }
                    else
                    {
                        if (!pieces[selectInd].color.Equals(pieces[retted[2]].color))
                        {
                            if (legalMove(retted))
                            {
                                pieceLocations[retted[0], retted[1]] = pieces[selectInd];
                                pieceLocations[selectRow, selectCol] = null;
                                bool whitInCheck = isWhiteInCheck();
                                bool blacInCheck = isBlackInCheck();
                                if (whitInCheck || blacInCheck)
                                {
                                    pieceLocations[retted[0], retted[1]] = pieces[retted[2]];
                                    pieceLocations[selectRow, selectCol] = pieces[selectInd];
                                }
                                String check = "";
                                if (pieces[selectInd].color == colors[0]
                                    && !whitInCheck)
                                {
                                    pieces[selectInd].rect = allRects[retted[0], retted[1]];
                                    pieceLocations[retted[0], retted[1]] = pieces[selectInd];
                                    pieces[retted[2]].rect = allRects[selectRow, selectCol];
                                    pieceLocations[selectRow, selectCol] = null;
                                    selected = false;
                                    test2 = false;
                                    whiteInCheck = isWhiteInCheck();
                                    blackInCheck = isBlackInCheck();
                                    turn = 1;
                                    moveCount++;
                                    notation = moveCount + ". ";
                                    switch (pieces[selectInd].type)
                                    {
                                        case ChessPiece.ROOK:
                                            notation += "Rx"; break;
                                        case ChessPiece.KNIGHT:
                                            notation += "Nx"; break;
                                        case ChessPiece.BISHOP:
                                            notation += "Bx"; break;
                                        case ChessPiece.QUEEN:
                                            notation += "Qx"; break;
                                        case ChessPiece.KING:
                                            notation += "Kx"; break;
                                    }
                                    if (blackInCheck)
                                        check = "+";
                                    notation += letters[retted[1]] + (8 - retted[0]) + check + "  ";
                                    Debug.Write(notation);
                                    notation = " ";
                                }
                                else if (pieces[selectInd].color == colors[1]
                                         && !blacInCheck)
                                {
                                    pieces[selectInd].rect = allRects[retted[0], retted[1]];
                                    pieceLocations[retted[0], retted[1]] = pieces[selectInd];
                                    pieces[retted[2]].rect = allRects[selectRow, selectCol];
                                    pieceLocations[selectRow, selectCol] = null;
                                    selected = false;
                                    test2 = false;
                                    whiteInCheck = isWhiteInCheck();
                                    blackInCheck = isBlackInCheck();
                                    turn = 0;
                                    switch (pieces[selectInd].type)
                                    {
                                        case ChessPiece.ROOK:
                                            notation += "Rx"; break;
                                        case ChessPiece.KNIGHT:
                                            notation += "Nx"; break;
                                        case ChessPiece.BISHOP:
                                            notation += "Bx"; break;
                                        case ChessPiece.QUEEN:
                                            notation += "Qx"; break;
                                        case ChessPiece.KING:
                                            notation += "Kx"; break;
                                    }
                                    if (whiteInCheck)
                                        check = "+";
                                    notation += letters[retted[1]] + (8 - retted[0]) + check + "  ";
                                    Debug.Write(notation);
                                }
                            }
                        }
                    }
                }
                if (mouse.X > 900 && mouse.Y > 900)
                    test3 = false;
                else
                    test3 = true;
                full.Width = screenWidth;
                full.Height = screenHeight;
                oldKB = kb;
                oldM = mouse;
                timer++;
            }
            else
            {
                locMouse.X = mouse.X;
                locMouse.Y = mouse.Y;
                if (mouse.LeftButton == ButtonState.Pressed)
                {
                    for (int i = 0; i < boardRects.Length; i++)
                    {
                        if (locMouse.Intersects(boardRects[i]))
                        {
                            board = i;
                            start = true;
                        }
                    }
                }
            }
        }
        public void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            if (started)
            {
                spriteBatch.Draw(boards[board], full, Color.White);
                if (!test3)
                {
                    if (selected)
                    {
                        for (int i = 0; i < 32; i++)
                        {
                            if (i != selectInd)
                                spriteBatch.Draw(pieces[i].image, pieces[i].rect, Color.White);
                            else
                            {
                                if (flashing)
                                    spriteBatch.Draw(pieces[i].image, pieces[i].rect, Color.White);
                                else
                                {
                                    spriteBatch.Draw(pieces[i].image, pieces[i].rect, Color.Transparent);
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 32; i++)
                        {
                            spriteBatch.Draw(pieces[i].image, pieces[i].rect, Color.White);
                        }
                    }
                }
                else
                {
                    if (selected)
                    {
                        for (int i = 0; i < 8; i++)
                            for (int j = 0; j < 8; j++)
                                if (pieceLocations[i, j] != null)
                                {
                                    if (i == selectRow && j == selectCol)
                                    {
                                        if (flashing)
                                            spriteBatch.Draw(pieceLocations[i, j].image, pieceLocations[i, j].rect, Color.White);
                                        else
                                        {
                                            spriteBatch.Draw(pieceLocations[i, j].image, pieceLocations[i, j].rect, Color.Transparent);
                                        }
                                    }
                                    else
                                        spriteBatch.Draw(pieceLocations[i, j].image, pieceLocations[i, j].rect, Color.White);
                                }
                    }
                    else
                    {
                        for (int i = 0; i < 8; i++)
                            for (int j = 0; j < 8; j++)
                                if (pieceLocations[i, j] != null)
                                    spriteBatch.Draw(pieceLocations[i, j].image, pieceLocations[i, j].rect, Color.White);
                    }
                }
                //spriteBatch.DrawString(font, "Row: " + selectRow + "\nCol: " + selectCol + "\n" + selectInd + "\nX: " + x + "   Y: " + y +
                //                   "\n\nSelectRow: " + selectRow + "\nselectcol: " + selectCol + "\nselectind: " + selectInd + "\nselected: " + selected +
                //                   "\nWhite in check: "+whiteInCheck+"\nBlack in check: "+blackInCheck
                //                   +"\nw: "+wKingI+" "+wKingR+" "+wKingC+"\nb: "+bKingI+" "+bKingR+" "+bKingC, vec, Color.Blue);
                if (selectRow >= 0 && selectRow < 8 && selectCol >= 0 && selectCol < 8)
                {
                    String add = "";
                    if (selected)
                        add = letters[selectCol] + (8 - selectRow);
                    else
                        add = "NONE";
                    spriteBatch.DrawString(font, "Current Piece Selected: " + add, bottomOfScreen, Color.White);
                }
                spriteBatch.Draw(turnIndicator, lowerRight, turnn[turn]);
            }
            else
            {
                for (int i = 0; i < boards.Length; i++)
                {
                    spriteBatch.Draw(boards[i], boardRects[i], Color.White);
                }
                spriteBatch.DrawString(font2, "Click the mouse on the board you want.", startVec, Color.White);
            }
            spriteBatch.End();
        }








        public int getIndex(int r, int c)
        {
            Piece look = pieceLocations[r, c];
            int size = pieces.Length;
            for (int i = 0; i < size; i++)
            {
                if (pieces[i] == look)
                {
                    return i;
                }
            }
            return -1;
        }
        public bool isBlackInCheck()
        {
            bKingI = getIndex(bKingR, bKingC);
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (pieceLocations[i, j] != null)
                    {
                        if (pieceLocations[i, j].color == Colour.WHITE)
                        {
                            if (legalMove(new int[3] { bKingR, bKingC, bKingI }, i, j, getIndex(i, j)))
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
        public bool isWhiteInCheck()
        {
            wKingI = getIndex(wKingR, wKingC);
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (pieceLocations[i, j] != null)
                    {
                        if (pieceLocations[i, j].color == Colour.BLACK)
                        {
                            if (legalMove(new int[3] { wKingR, wKingC, wKingI }, i, j, getIndex(i, j)))
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
        public bool isBlackInCheck(Piece[,] pieceLocations)
        {
            bKingI = getIndex(bKingR, bKingC);
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (pieceLocations[i, j] != null)
                    {
                        if (pieceLocations[i, j].color == Colour.WHITE)
                        {
                            if (legalMove(new int[3] { bKingR, bKingC, bKingI }, i, j, getIndex(i, j)))
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
        public bool isWhiteInCheck(Piece[,] pieceLocations)
        {
            wKingI = getIndex(wKingR, wKingC);
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (pieceLocations[i, j] != null)
                    {
                        if (pieceLocations[i, j].color == Colour.BLACK)
                        {
                            if (legalMove(new int[3] { wKingR, wKingC, wKingI }, i, j, getIndex(i, j)))
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
        /*      ATTEMPTS AT RECURSIVE SOLUTION TO FINDING CHECK (PROBLEM WAS STACK OVERFLOW AS IT WOULD GET RETURN FALSE WHEN IT WAS AT
         *      A PIECE OF THE SAME COLOR BUT IT NEEDED TO GET PAST THOSE TO FIND THE PIECES THAT WERE DIFFERENT COLORS BUT COULDNT
         *      DUE TO THE STACK OVERFLOW, THE METHODS WERE ADJUSTED SO THEY ARE NOT EXACTLY WHAT THEY WERE WHEN THEY WOULDVE WORKED
         *      IF NOT FOR THE STACK OVERFLOW ERRORS, BLACKCHECKING IS CLOSER TO THAT SOLUTION THAN WHITECHECKING
        public bool whiteChecking(int r, int c)
        {
            if (r < 0 || r > 7 || c < 0 || c > 7)
                return false;
            if (pieceLocations[r, c] == null)
                return false;
            if (pieceLocations[r, c].color == Colour.WHITE)
                return false;
            if (legalMove(new int[3] { getIndex(r, c), r, c }, wKingR, wKingC, wKingI))
                return true;
            return whiteChecking(r + 1, c) || whiteChecking(r - 1, c) || whiteChecking(r, c + 1) || whiteChecking(r, c - 1)
                   || whiteChecking(r + 1, c + 1) || whiteChecking(r + 1, c - 1) || whiteChecking(r - 1, c + 1) || whiteChecking(r - 1, c - 1);
        }
        public bool blackChecking(int r, int c)
        {
            if (r < 0 || r > 7 || c < 0 || c > 7)
                return false;
            if (pieceLocations[r, c] == null)
                return false;
            if (legalMove(new int[3] { bKingR, bKingC, bKingI }, r, c, getIndex(r, c)))
            {
                Debug.Write("ALERTTTTTTTTTTT");
                return true;
            }
            return (blackChecking(r + 1, c) || blackChecking(r - 1, c) || blackChecking(r, c + 1) || blackChecking(r, c - 1)
                   || blackChecking(r + 1, c + 1) || blackChecking(r + 1, c - 1) || blackChecking(r - 1, c + 1) || blackChecking(r - 1, c - 1));
        }*/
        public void forceTake(int r, int c)
        {
            pieceLocations[r, c] = null;
        }
        public bool legalMove(int[] arr, int selectRow, int selectCol, int selectInd)
        {
            int row = arr[0];
            int col = arr[1];
            int ind = arr[2];
            if (selectInd < 0)
                return false;
            ChessPiece type = pieces[selectInd].type;
            Colour color = pieces[selectInd].color;
            if (color == pieces[ind].color)
                return false;
            switch (type)
            {
                case ChessPiece.ROOK:
                    int temp = 0;
                    if (row != selectRow)
                    {
                        if (col == selectCol)
                        {
                            if (row < selectRow)
                            {
                                temp = row + 1;
                                while (temp != selectRow)
                                {
                                    if (pieceLocations[temp, col] != null)
                                        return false;
                                    temp++;
                                }
                            }
                            else
                            {
                                temp = row - 1;
                                while (temp != selectRow)
                                {
                                    if (pieceLocations[temp, col] != null)
                                        return false;
                                    temp--;
                                }
                            }
                            return true;
                        }
                    }
                    if (col != selectCol)
                    {
                        if (row == selectRow)
                        {
                            if (col < selectCol)
                            {
                                temp = col + 1;
                                while (temp != selectCol)
                                {
                                    if (pieceLocations[row, temp] != null)
                                        return false;
                                    temp++;
                                }
                            }
                            else
                            {
                                temp = col - 1;
                                while (temp != selectCol)
                                {
                                    if (pieceLocations[row, temp] != null)
                                        return false;
                                    temp--;
                                }
                            }
                            if (color == Colour.WHITE)
                            {
                                if (selectRow == 7)
                                {
                                    if (selectCol == 0)
                                    {
                                        canWhiteCastleLeft = false;
                                    }
                                    if (selectCol == 7)
                                    {
                                        canWhiteCastleRight = false;
                                    }
                                }
                            }
                            if (color == Colour.BLACK)
                            {
                                if (selectRow == 0)
                                {
                                    if (selectCol == 0)
                                    {
                                        canBlackCastleLeft = false;
                                    }
                                    if (selectCol == 7)
                                    {
                                        canBlackCastleRight = false;
                                    }
                                }
                            }
                            return true;
                        }
                    }
                    return false;
                case ChessPiece.KNIGHT:
                    if (Math.Abs(selectRow - row) == 2)
                        if (col + 1 == selectCol || col - 1 == selectCol)
                            return true;
                    if (Math.Abs(selectCol - col) == 2)
                        if (row + 1 == selectRow || row - 1 == selectRow)
                            return true;
                    return false;
                case ChessPiece.BISHOP:
                    if (Math.Abs(col - selectCol) == 0)
                        return false;
                    if (Math.Abs(row - selectRow) / Math.Abs(col - selectCol) == 1)
                    {
                        int temp3 = 0; //temp row
                        int temp4 = 0; //temp col
                        if (row < selectRow)
                        {
                            if (col > selectCol)
                            {
                                temp3 = row + 1;
                                temp4 = col - 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3++;
                                    temp4--;
                                }
                                return true;
                            }
                            if (col < selectCol)
                            {
                                temp3 = row + 1;
                                temp4 = col + 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3++;
                                    temp4++;
                                }
                                return true;
                            }
                        }
                        if (row > selectRow)
                        {
                            if (col > selectCol)
                            {
                                temp3 = row - 1;
                                temp4 = col - 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3--;
                                    temp4--;
                                }
                                return true;
                            }
                            if (col < selectCol)
                            {
                                temp3 = row - 1;
                                temp4 = col + 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3--;
                                    temp4++;
                                }
                                return true;
                            }
                        }
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case ChessPiece.QUEEN:
                    int temp2 = 0;
                    if (row != selectRow)
                    {
                        if (col == selectCol)
                        {
                            if (row < selectRow)
                            {
                                temp2 = row + 1;
                                while (temp2 != selectRow)
                                {
                                    if (pieceLocations[temp2, col] != null)
                                        return false;
                                    temp2++;
                                }
                            }
                            else
                            {
                                temp2 = row - 1;
                                while (temp2 != selectRow)
                                {
                                    if (pieceLocations[temp2, col] != null)
                                        return false;
                                    temp2--;
                                }
                            }
                            return true;
                        }
                    }
                    if (col != selectCol)
                    {
                        if (row == selectRow)
                        {
                            if (col < selectCol)
                            {
                                temp2 = col + 1;
                                while (temp2 != selectCol)
                                {
                                    if (pieceLocations[row, temp2] != null)
                                        return false;
                                    temp2++;
                                }
                            }
                            else
                            {
                                temp2 = col - 1;
                                while (temp2 != selectCol)
                                {
                                    if (pieceLocations[row, temp2] != null)
                                        return false;
                                    temp2--;
                                }
                            }
                            return true;
                        }
                    }
                    if (Math.Abs(col - selectCol) == 0)
                        return false;
                    if (Math.Abs(row - selectRow) / (double)Math.Abs(col - selectCol) == 1)
                    {
                        int temp3 = 0; //temp row
                        int temp4 = 0; //temp col
                        if (row < selectRow)
                        {
                            if (col > selectCol)
                            {
                                temp3 = row + 1;
                                temp4 = col - 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3++;
                                    temp4--;
                                }
                                return true;
                            }
                            if (col < selectCol)
                            {
                                temp3 = row + 1;
                                temp4 = col + 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3++;
                                    temp4++;
                                }
                                return true;
                            }
                        }
                        if (row > selectRow)
                        {
                            if (col > selectCol)
                            {
                                temp3 = row - 1;
                                temp4 = col - 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3--;
                                    temp4--;
                                }
                                return true;
                            }
                            if (col < selectCol)
                            {
                                temp3 = row - 1;
                                temp4 = col + 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3--;
                                    temp4++;
                                }
                                return true;
                            }
                        }
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case ChessPiece.KING:
                    if (row == selectRow + 1 && col == selectCol
                        || row == selectRow && col == selectCol + 1
                        || row == selectRow + 1 && col == selectCol + 1
                        || row == selectRow && col == selectCol - 1
                        || row == selectRow - 1 && col == selectCol
                        || row == selectRow + 1 && col == selectCol - 1
                        || row == selectRow - 1 && col == selectCol + 1
                        || row == selectRow - 1 && col == selectCol - 1)
                    {
                        return true;
                    }
                    return false;
                case ChessPiece.PAWN:
                    if (pieceLocations[row, col] != null)
                        if (col == selectCol)
                            return false;
                    if (color == Colour.WHITE) //dependent on white on the bottom
                    {
                        if (selectRow == 6)
                        {
                            if (row == selectRow - 2 && col == selectCol)
                                return true;
                        }
                        if (row == selectRow - 1 && col == selectCol)
                            return true;
                        if (row == selectRow - 1 && col == selectCol - 1
                            || row == selectRow - 1 && col == selectCol + 1)
                        {
                            if (pieceLocations[row, col] != null)
                                if (pieceLocations[row, col].color == Colour.BLACK)
                                    return true;
                        }
                    }
                    else
                    {
                        if (selectRow == 1)
                        {
                            if (row == selectRow + 2 && col == selectCol)
                                return true;
                        }
                        if (row == selectRow + 1 && col == selectCol)
                            return true;
                        if (row == selectRow + 1 && col == selectCol + 1
                            || row == selectRow + 1 && col == selectCol - 1)
                        {
                            if (pieceLocations[row, col] != null)
                                if (pieceLocations[row, col].color == Colour.WHITE)
                                    return true;
                        }
                    }
                    return false;
            }
            return false;
        }
        public bool legalMove(int[] arr)
        {
            int row = arr[0];
            int col = arr[1];
            int ind = arr[2];
            ChessPiece type = pieces[selectInd].type;
            Colour color = pieces[selectInd].color;
            switch (type)
            {
                case ChessPiece.ROOK:
                    int temp = 0;
                    if (row != selectRow)
                    {
                        if (col == selectCol)
                        {
                            if (row < selectRow)
                            {
                                temp = row + 1;
                                while (temp != selectRow)
                                {
                                    if (pieceLocations[temp, col] != null)
                                        return false;
                                    temp++;
                                }
                            }
                            else
                            {
                                temp = row - 1;
                                while (temp != selectRow)
                                {
                                    if (pieceLocations[temp, col] != null)
                                        return false;
                                    temp--;
                                }
                            }
                            if (color == Colour.WHITE)
                            {
                                if (selectRow == 7)
                                {
                                    if (selectCol == 0)
                                    {
                                        canWhiteCastleLeft = false;
                                    }
                                    if (selectCol == 7)
                                    {
                                        canWhiteCastleRight = false;
                                    }
                                }
                            }
                            if (color == Colour.BLACK)
                            {
                                if (selectRow == 0)
                                {
                                    if (selectCol == 0)
                                    {
                                        canBlackCastleLeft = false;
                                    }
                                    if (selectCol == 7)
                                    {
                                        canBlackCastleRight = false;
                                    }
                                }
                            }
                            return true;
                        }
                    }
                    if (col != selectCol)
                    {
                        if (row == selectRow)
                        {
                            if (col < selectCol)
                            {
                                temp = col + 1;
                                while (temp != selectCol)
                                {
                                    if (pieceLocations[row, temp] != null)
                                        return false;
                                    temp++;
                                }
                            }
                            else
                            {
                                temp = col - 1;
                                while (temp != selectCol)
                                {
                                    if (pieceLocations[row, temp] != null)
                                        return false;
                                    temp--;
                                }
                            }
                            if (color == Colour.WHITE)
                            {
                                if (selectRow == 7)
                                {
                                    if (selectCol == 0)
                                    {
                                        canWhiteCastleLeft = false;
                                    }
                                    if (selectCol == 7)
                                    {
                                        canWhiteCastleRight = false;
                                    }
                                }
                            }
                            if (color == Colour.BLACK)
                            {
                                if (selectRow == 0)
                                {
                                    if (selectCol == 0)
                                    {
                                        canBlackCastleLeft = false;
                                    }
                                    if (selectCol == 7)
                                    {
                                        canBlackCastleRight = false;
                                    }
                                }
                            }
                            return true;
                        }
                    }
                    return false;
                case ChessPiece.KNIGHT:
                    if (Math.Abs(selectRow - row) == 2)
                        if (col + 1 == selectCol || col - 1 == selectCol)
                            return true;
                    if (Math.Abs(selectCol - col) == 2)
                        if (row + 1 == selectRow || row - 1 == selectRow)
                            return true;
                    return false;
                case ChessPiece.BISHOP:
                    if (Math.Abs(col - selectCol) == 0)
                        return false;
                    if (Math.Abs(row - selectRow) / Math.Abs(col - selectCol) == 1)
                    {
                        int temp3 = 0; //temp row
                        int temp4 = 0; //temp col
                        if (row < selectRow)
                        {
                            if (col > selectCol)
                            {
                                temp3 = row + 1;
                                temp4 = col - 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3++;
                                    temp4--;
                                }
                                return true;
                            }
                            if (col < selectCol)
                            {
                                temp3 = row + 1;
                                temp4 = col + 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3++;
                                    temp4++;
                                }
                                return true;
                            }
                        }
                        if (row > selectRow)
                        {
                            if (col > selectCol)
                            {
                                temp3 = row - 1;
                                temp4 = col - 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3--;
                                    temp4--;
                                }
                                return true;
                            }
                            if (col < selectCol)
                            {
                                temp3 = row - 1;
                                temp4 = col + 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3--;
                                    temp4++;
                                }
                                return true;
                            }
                        }
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case ChessPiece.QUEEN:
                    int temp2 = 0;
                    if (row != selectRow)
                    {
                        if (col == selectCol)
                        {
                            if (row < selectRow)
                            {
                                temp2 = row + 1;
                                while (temp2 != selectRow)
                                {
                                    if (pieceLocations[temp2, col] != null)
                                        return false;
                                    temp2++;
                                }
                            }
                            else
                            {
                                temp2 = row - 1;
                                while (temp2 != selectRow)
                                {
                                    if (pieceLocations[temp2, col] != null)
                                        return false;
                                    temp2--;
                                }
                            }
                            return true;
                        }
                    }
                    if (col != selectCol)
                    {
                        if (row == selectRow)
                        {
                            if (col < selectCol)
                            {
                                temp2 = col + 1;
                                while (temp2 != selectCol)
                                {
                                    if (pieceLocations[row, temp2] != null)
                                        return false;
                                    temp2++;
                                }
                            }
                            else
                            {
                                temp2 = col - 1;
                                while (temp2 != selectCol)
                                {
                                    if (pieceLocations[row, temp2] != null)
                                        return false;
                                    temp2--;
                                }
                            }
                            return true;
                        }
                    }
                    if (Math.Abs(col - selectCol) == 0)
                        return false;
                    if (Math.Abs(row - selectRow) / (double)Math.Abs(col - selectCol) == 1)
                    {
                        int temp3 = 0; //temp row
                        int temp4 = 0; //temp col
                        if (row < selectRow)
                        {
                            if (col > selectCol)
                            {
                                temp3 = row + 1;
                                temp4 = col - 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3++;
                                    temp4--;
                                }
                                return true;
                            }
                            if (col < selectCol)
                            {
                                temp3 = row + 1;
                                temp4 = col + 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3++;
                                    temp4++;
                                }
                                return true;
                            }
                        }
                        if (row > selectRow)
                        {
                            if (col > selectCol)
                            {
                                temp3 = row - 1;
                                temp4 = col - 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3--;
                                    temp4--;
                                }
                                return true;
                            }
                            if (col < selectCol)
                            {
                                temp3 = row - 1;
                                temp4 = col + 1;
                                while (temp3 != selectRow)
                                {
                                    if (pieceLocations[temp3, temp4] != null)
                                        return false;
                                    temp3--;
                                    temp4++;
                                }
                                return true;
                            }
                        }
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case ChessPiece.KING:
                    if (row == selectRow + 1 && col == selectCol
                        || row == selectRow && col == selectCol + 1
                        || row == selectRow + 1 && col == selectCol + 1
                        || row == selectRow && col == selectCol - 1
                        || row == selectRow - 1 && col == selectCol
                        || row == selectRow + 1 && col == selectCol - 1
                        || row == selectRow - 1 && col == selectCol + 1
                        || row == selectRow - 1 && col == selectCol - 1)
                    {
                        if (color == Colour.WHITE)
                        {
                            canWhiteCastleLeft = false;
                            canWhiteCastleRight = false;
                            wKingR = row;
                            wKingC = col;
                        }
                        else
                        {
                            canBlackCastleLeft = false;
                            canBlackCastleRight = false;
                            bKingR = row;
                            bKingC = col;
                        }
                        return true;
                    }
                    if (color == Colour.WHITE)
                    {
                        if (canWhiteCastleLeft
                            && row == selectRow && selectRow == 7
                            && (col == selectCol - 2 || col == selectCol - 3))
                        {
                            if (pieceLocations[7, 1] == null
                                && pieceLocations[7, 2] == null
                                && pieceLocations[7, 3] == null)
                            {
                                pieces[selectInd].rect = allRects[7, 2];
                                pieceLocations[7, 2] = pieces[selectInd];
                                pieceLocations[selectRow, selectCol] = null;
                                pieces[24].rect = allRects[7, 3];
                                pieceLocations[7, 3] = pieces[24];
                                pieceLocations[7, 0] = null;
                                notation = moveCount + ". ";
                                notation += "0-0-0  ";
                                Debug.Write(notation);
                                notation = " ";
                                canWhiteCastleLeft = false;
                                canWhiteCastleRight = false;
                                turn = 1;
                                selected = false;
                                test2 = false;
                                wKingR = 7; wKingC = 2;
                            }
                        }
                        if (canWhiteCastleRight
                            && row == selectRow && selectRow == 7
                            && col == selectCol + 2)
                        {
                            if (pieceLocations[7, 5] == null
                                && pieceLocations[7, 6] == null)
                            {
                                pieces[selectInd].rect = allRects[7, 6];
                                pieceLocations[7, 6] = pieces[selectInd];
                                pieceLocations[selectRow, selectCol] = null;
                                pieces[31].rect = allRects[7, 5];
                                pieceLocations[7, 5] = pieces[31];
                                pieceLocations[7, 7] = null;
                                notation = moveCount + ". ";
                                notation += "0-0  ";
                                Debug.Write(notation);
                                notation = " ";
                                canWhiteCastleLeft = false;
                                canWhiteCastleRight = false;
                                turn = 1;
                                selected = false;
                                test2 = false;
                                wKingR = 7; wKingC = 6;
                            }
                        }
                    }
                    if (color == Colour.BLACK)
                    {
                        if (canBlackCastleLeft
                            && row == selectRow && selectRow == 0
                            && (col == selectCol - 2 || col == selectCol - 3))
                        {
                            if (pieceLocations[0, 1] == null
                                && pieceLocations[0, 2] == null
                                && pieceLocations[0, 3] == null)
                            {
                                pieces[selectInd].rect = allRects[0, 2];
                                pieceLocations[0, 2] = pieces[selectInd];
                                pieceLocations[selectRow, selectCol] = null;
                                pieces[0].rect = allRects[0, 3];
                                pieceLocations[0, 3] = pieces[0];
                                pieceLocations[0, 0] = null;
                                notation += "0-0-0  ";
                                Debug.Write(notation);
                                canBlackCastleLeft = false;
                                canBlackCastleRight = false;
                                turn = 0;
                                selected = false;
                                test2 = false;
                                bKingR = 0; bKingC = 2;
                            }
                        }
                        if (canBlackCastleRight
                            && row == selectRow && selectRow == 0
                            && col == selectCol + 2)
                        {
                            if (pieceLocations[0, 5] == null
                                && pieceLocations[0, 6] == null)
                            {
                                pieces[selectInd].rect = allRects[0, 6];
                                pieceLocations[0, 6] = pieces[selectInd];
                                pieceLocations[selectRow, selectCol] = null;
                                pieces[7].rect = allRects[0, 5];
                                pieceLocations[0, 5] = pieces[7];
                                pieceLocations[0, 7] = null;
                                notation += "0-0  ";
                                Debug.Write(notation);
                                canBlackCastleLeft = false;
                                canBlackCastleRight = false;
                                turn = 0;
                                selected = false;
                                test2 = false;
                                bKingR = 0; bKingC = 6;
                            }
                        }
                    }
                    moveCount++;
                    return false;
                case ChessPiece.PAWN:
                    if (pieceLocations[row, col] != null)
                        if (col == selectCol)
                            return false;
                    if (color == Colour.WHITE) //dependent on white on the bottom
                    {
                        if (selectRow == 6)
                        {
                            if (row == selectRow - 2 && col == selectCol)
                                return true;
                        }
                        if (row == selectRow - 1 && col == selectCol)
                            return true;
                        if (row == selectRow - 1 && col == selectCol - 1
                            || row == selectRow - 1 && col == selectCol + 1)
                        {
                            if (pieceLocations[row, col] != null)
                                if (pieceLocations[row, col].color == Colour.BLACK)
                                    return true;
                            if (pieceLocations[row + 1, col] != null)
                                if (pieceLocations[row + 1, col].color == Colour.BLACK
                                    && pieceLocations[row + 1, col].type == ChessPiece.PAWN)
                                {
                                    forceTake(row + 1, col);
                                    return true;
                                }
                        }
                    }
                    else
                    {
                        if (selectRow == 1)
                        {
                            if (row == selectRow + 2 && col == selectCol)
                                return true;
                        }
                        if (row == selectRow + 1 && col == selectCol)
                            return true;
                        if (row == selectRow + 1 && col == selectCol + 1
                            || row == selectRow + 1 && col == selectCol - 1)
                        {
                            if (pieceLocations[row, col] != null)
                                if (pieceLocations[row, col].color == Colour.WHITE)
                                    return true;
                            if (pieceLocations[row - 1, col] != null)
                                if (pieceLocations[row - 1, col].color == Colour.WHITE
                                    && pieceLocations[row - 1, col].type == ChessPiece.PAWN)
                                {
                                    forceTake(row - 1, col);
                                    return true;
                                }
                        }
                    }
                    return false;
            }
            return false;
        }
        /*
         * will return true if mouse clicked on a piece
         * will return false if mouse clicked out of bounds
         * */
        public bool selectPiece(int x, int y)
        {
            if (x < 100 || x > 900) //out of bounds left and right
                return false;
            if (y < 100 || y > 900) //out of bounds up and down)
                return false;
            if (y < 200)
            {
                selectRow = 0;
            }
            else if (y < 300)
            {
                selectRow = 1;
            }
            else if (y < 400)
            {
                selectRow = 2;
            }
            else if (y < 500)
            {
                selectRow = 3;
            }
            else if (y < 600)
            {
                selectRow = 4;
            }
            else if (y < 700)
            {
                selectRow = 5;
            }
            else if (y < 800)
            {
                selectRow = 6;
            }
            else if (y < 900)
            {
                selectRow = 7;
            }
            if (x < 200)
            {
                selectCol = 0;
            }
            else if (x < 300)
            {
                selectCol = 1;
            }
            else if (x < 400)
            {
                selectCol = 2;
            }
            else if (x < 500)
            {
                selectCol = 3;
            }
            else if (x < 600)
            {
                selectCol = 4;
            }
            else if (x < 700)
            {
                selectCol = 5;
            }
            else if (x < 800)
            {
                selectCol = 6;
            }
            else if (x < 900)
            {
                selectCol = 7;
            }
            for (int i = 0; i < pieces.Length; i++)
            {
                if (pieces[i] == pieceLocations[selectRow, selectCol])
                    selectInd = i;
            }
            return true;
        }
        public int[] getPos(int x, int y)
        {
            int[] ret = new int[3];
            int selectRow = -1;
            int selectCol = -1;
            int selectInd = -1;
            if (x < 100 || x > 900) //out of bounds left and right
                return ret;
            if (y < 100 || y > 900) //out of bounds up and down)
                return ret;
            if (y < 200)
            {
                selectRow = 0;
            }
            else if (y < 300)
            {
                selectRow = 1;
            }
            else if (y < 400)
            {
                selectRow = 2;
            }
            else if (y < 500)
            {
                selectRow = 3;
            }
            else if (y < 600)
            {
                selectRow = 4;
            }
            else if (y < 700)
            {
                selectRow = 5;
            }
            else if (y < 800)
            {
                selectRow = 6;
            }
            else if (y < 900)
            {
                selectRow = 7;
            }
            if (x < 200)
            {
                selectCol = 0;
            }
            else if (x < 300)
            {
                selectCol = 1;
            }
            else if (x < 400)
            {
                selectCol = 2;
            }
            else if (x < 500)
            {
                selectCol = 3;
            }
            else if (x < 600)
            {
                selectCol = 4;
            }
            else if (x < 700)
            {
                selectCol = 5;
            }
            else if (x < 800)
            {
                selectCol = 6;
            }
            else if (x < 900)
            {
                selectCol = 7;
            }
            for (int i = 0; i < pieces.Length; i++)
            {
                if (pieces[i] == pieceLocations[selectRow, selectCol])
                    selectInd = i;
            }
            ret[0] = selectRow;
            ret[1] = selectCol;
            ret[2] = selectInd;
            return ret;
        }
    }
}