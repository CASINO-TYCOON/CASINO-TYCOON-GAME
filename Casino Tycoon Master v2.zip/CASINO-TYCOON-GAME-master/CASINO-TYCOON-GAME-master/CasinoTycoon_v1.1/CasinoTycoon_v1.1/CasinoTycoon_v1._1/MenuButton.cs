﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class MenuButton
    {
        public Rectangle rect;
        public String name;
        SpriteFont font;

        public MenuButton(String n, ContentManager Content)
        {
            name = n;
            Load(Content);
        }

        public void setRectangle(Rectangle r)
        {
            rect = r;
        }

        public void Load(ContentManager Content)
        {
            font = Content.Load<SpriteFont>("Menu/SpriteFont1");
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.DrawString(font, name, new Vector2(rect.X, rect.Y), Color.Black);
        }
    }
}
