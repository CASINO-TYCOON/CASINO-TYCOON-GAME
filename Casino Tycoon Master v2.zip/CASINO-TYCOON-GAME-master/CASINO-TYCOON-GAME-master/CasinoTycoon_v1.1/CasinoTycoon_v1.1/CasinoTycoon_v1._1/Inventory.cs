﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace CasinoTycoon_v1._1
{
    class Inventory
    {
        private PowerUp[] items; //array of powerUps in the inventory
        public int selectedIndex; //the powerUp currently selected

        public List<PowerUp> activeItems;

        private int nextIndex; //The next open index for adding an item
        private static int SIZE = 9;

        private Texture2D background;
        private Texture2D slotBackground;

        public enum InventoryStatus
        {
            inactive, //the player is not looking through the inventory right now
            active //the player is navigating the inventory
        }

        public InventoryStatus status;

        public Inventory()
        {
            items = new PowerUp[SIZE];
            selectedIndex = 0;

            activeItems = new List<PowerUp>();

            nextIndex = 0;

            status = InventoryStatus.inactive;
        }

        public void loadContent(ContentManager Content)
        {
            //Better assets can come later, right now I am just using a basic white texture that I recolor
            background = Content.Load<Texture2D>("Inventory/background");
            slotBackground = Content.Load<Texture2D>("Inventory/WhiteColor");
        }

        public bool addItem(PowerUp item) //adds an item. If there is no space, returns false
        {
            if (nextIndex < SIZE)
            {
                items[nextIndex] = item;
                nextIndex++;
                return true;
            }
            return false;
        }

        private void removeItem(int index) //removes an item and shifts all items to account for empty space
        {
            items[index] = null;
            for (int i = index; i < items.Length - 1; i++)
            {
                items[i] = items[i + 1];
            }
            items[SIZE - 1] = null;
        }

        private void activate()
        {
            if (items[selectedIndex] != null)
            {
                items[selectedIndex].activate();
                activeItems.Add(items[selectedIndex]);
                removeItem(selectedIndex);
            }
        }

        private void cleanActive() //removes any fully used items from the activeItems list
        {
            List<int> used = new List<int>();

            for (int i = 0; i < activeItems.Count; i++)
            {
                if (activeItems[i].status == PowerUp.powerUpStatus.used)
                {
                    activeItems[i] = null;
                    used.Add(i);
                }
            }

            for (int i = 0; i < used.Count; i++)
            {
                activeItems.RemoveAt(used[i]);
            }
        }

        public void update(KeyboardState kb, KeyboardState oldKb)
        {
            //if (status == InventoryStatus.inactive && toDo == "Inventory")
            //{
            //    //open inventory
            //    if ((kb.IsKeyDown(Keys.Enter) && !oldKb.IsKeyDown(Keys.Enter)))
            //    {
            //        selectedIndex = 0;
            //        status = InventoryStatus.active;
            //    }
            //}
            if (status == InventoryStatus.active)
            {
                //move left
                if ((kb.IsKeyDown(Keys.A) && !oldKb.IsKeyDown(Keys.A)) || (kb.IsKeyDown(Keys.Left) && !oldKb.IsKeyDown(Keys.Left)))
                {
                    if (selectedIndex > 0)
                    {
                        selectedIndex--;
                    }
                }
                //move right
                if ((kb.IsKeyDown(Keys.D) && !oldKb.IsKeyDown(Keys.D)) || (kb.IsKeyDown(Keys.Right) && !oldKb.IsKeyDown(Keys.Right)))
                {
                    if (items[selectedIndex + 1] != null)
                    {
                        selectedIndex++;
                    }
                }
                //use item
                if ((kb.IsKeyDown(Keys.Enter) && !oldKb.IsKeyDown(Keys.Enter)))
                {
                    activate();
                    while (items[selectedIndex] == null && selectedIndex != 0)
                    {
                        selectedIndex--;
                    }
                    nextIndex--;
                }
                //close inventory
                if ((kb.IsKeyDown(Keys.Escape) && !oldKb.IsKeyDown(Keys.Escape)))
                {
                    status = InventoryStatus.inactive;
                }
            }

            //important!!!
            cleanActive();
        }

        public void setActive()
        {
            status = InventoryStatus.active;
        }

        public void draw(SpriteBatch spriteBatch, SpriteFont spriteFont)
        {
            if (status == InventoryStatus.active)
            {
                spriteBatch.Draw(background, new Rectangle(0, 450, 700, 150), Color.White);
                for (int i = 0; i < items.Length; i++)
                {
                    //draw the slots (selected one is in yellow)
                    if (i == selectedIndex && items[0] != null)
                    {
                        spriteBatch.Draw(background, new Rectangle(25 + 75 * i, 500, 50, 50), Color.Yellow);
                    }
                    else
                    {
                        spriteBatch.Draw(background, new Rectangle(25 + 75 * i, 500, 50, 50), Color.Gray);
                    }

                    //add the images to show what it is (if there are any)
                    if (items[i] != null)
                    {
                        spriteBatch.Draw(items[i].currentTexture, new Rectangle(25 + 75 * i, 500, 50, 50), Color.White);
                    }

                    spriteBatch.DrawString(spriteFont, "Inventory", new Vector2(25, 460), Color.Black);
                    if (items[selectedIndex] != null)
                    {
                        spriteBatch.DrawString(spriteFont, items[selectedIndex].name, new Vector2(25, 560), Color.Black);
                    }
                }
            }
        }
    }
}
