﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Input
    {

        public static bool right(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.Right) || kb.IsKeyDown(Keys.D) || gp.ThumbSticks.Left.X > 0);
        }

        public static bool left(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.Left) || kb.IsKeyDown(Keys.A) || gp.ThumbSticks.Left.X < 0);
        }

        public static bool up(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.Up) || kb.IsKeyDown(Keys.W) || gp.ThumbSticks.Left.Y < 0);
        }

        public static bool down(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.Down) || kb.IsKeyDown(Keys.S) || gp.ThumbSticks.Left.Y > 0);
        }

        public static bool shift(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.LeftShift) || gp.IsButtonDown(Buttons.LeftShoulder));
        }

        public static bool enter(KeyboardState kb, GamePadState gp)
        {
            return (kb.IsKeyDown(Keys.Enter) || kb.IsKeyDown(Keys.E) || gp.IsButtonDown(Buttons.A));
        }


        // Key Presses
        
        public static bool keyPressRight(KeyboardState kb, GamePadState gp, KeyboardState oldKb, GamePadState oldGp)
        {
            return ((kb.IsKeyDown(Keys.Right) || kb.IsKeyDown(Keys.D) || gp.ThumbSticks.Left.X > 0) && !(oldKb.IsKeyDown(Keys.Right) || oldKb.IsKeyDown(Keys.D) || oldGp.ThumbSticks.Left.X > 0));
        }

        public static bool keyPressLeft(KeyboardState kb, GamePadState gp, KeyboardState oldKb, GamePadState oldGp)
        {
            return ((kb.IsKeyDown(Keys.Left) || kb.IsKeyDown(Keys.A) || gp.ThumbSticks.Left.X < 0) && !(oldKb.IsKeyDown(Keys.Left) || oldKb.IsKeyDown(Keys.A) || oldGp.ThumbSticks.Left.X < 0));
        }

        public static bool keyPressUp(KeyboardState kb, GamePadState gp, KeyboardState oldKb, GamePadState oldGp)
        {
            return ((kb.IsKeyDown(Keys.Up) || kb.IsKeyDown(Keys.W) || gp.ThumbSticks.Left.Y < 0) && !(oldKb.IsKeyDown(Keys.Up) || oldKb.IsKeyDown(Keys.W) || oldGp.ThumbSticks.Left.Y < 0));
        }

        public static bool keyPressDown(KeyboardState kb, GamePadState gp, KeyboardState oldKb, GamePadState oldGp)
        {
            return ((kb.IsKeyDown(Keys.Down) || kb.IsKeyDown(Keys.S) || gp.ThumbSticks.Left.Y > 0) && !(oldKb.IsKeyDown(Keys.Down) || oldKb.IsKeyDown(Keys.S) || oldGp.ThumbSticks.Left.Y > 0));
        }

        public static bool keyPressEnter(KeyboardState kb, GamePadState gp, KeyboardState oldKb, GamePadState oldGp)
        {
            return ((kb.IsKeyDown(Keys.Enter) || kb.IsKeyDown(Keys.E) || gp.IsButtonDown(Buttons.A)) && !(oldKb.IsKeyDown(Keys.Enter) || oldKb.IsKeyDown(Keys.E) || oldGp.IsButtonDown(Buttons.A)));
        }

        public static bool keyPressEscape(KeyboardState kb, GamePadState gp, KeyboardState oldKb, GamePadState oldGp)
        {
            return ((kb.IsKeyDown(Keys.Escape) || gp.IsButtonDown(Buttons.Back)) && !(oldKb.IsKeyDown(Keys.Escape) || oldGp.IsButtonDown(Buttons.Back)));
        }
    }
}
