﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
//using System.Runtime.Remoting.Contexts;

namespace CasinoTycoon_v1._1
{
    class Blackjack
    {
        SpriteFont font;
        Texture2D bjBoard;
        Rectangle bjRect;
        Deck bjDeck;
        
        SpriteBatch spriteBatch;
        GameState state;
        enum GameState { play, lost, won }
        //Vector2 deckLocation;

        Deck mainDeck;
        Rectangle[] mainDeckLocations;

        Deck dealerCards;
        Rectangle[] dealerCardLocations;

        Deck playerCards;
        Rectangle[] playerCardLocations;

        enum Hand { Nothing, Hit, Stay, Surrender }
        Hand handState;
        int hitCount;
        KeyboardState oldKB;
        string welcome;
        public double bet;
        //Surrender = get half reward and exit game


        public Blackjack(Texture2D board, Deck deck, SpriteBatch sb, SpriteFont f)
        {
            bjBoard = board;
            bjRect = new Rectangle(-50, 0, 800, 650);
            bjDeck = deck;
            mainDeckLocations = new Rectangle[bjDeck.deck.Length]; fillDefaultLocations(mainDeckLocations);
            spriteBatch = sb;
            //deckLocation = new Vector2(300, 200);
            dealerCards = new _1.Deck();
            playerCards = new _1.Deck();
            hitCount = 0;
            dealerCardLocations = new Rectangle[3];
            playerCardLocations = new Rectangle[3];

            playerCardLocations[0] = new Rectangle(200, 400, 70, 90);
            playerCardLocations[1] = new Rectangle(300, 400, 70, 90);
            playerCardLocations[2] = new Rectangle(400, 400, 70, 90);

            dealerCardLocations[0] = new Rectangle(200, 50, 70, 90);
            dealerCardLocations[1] = new Rectangle(300, 50, 70, 90);
            dealerCardLocations[2] = new Rectangle(400, 50, 70, 90);
            oldKB = Keyboard.GetState();
            font = f;
            bet = 0;
        }

        public void launch()
        {
            welcome = "welcome";
            state = GameState.play;
            mainDeck = bjDeck;
            handState = Hand.Nothing;
        }

        public void fillDefaultLocations(Rectangle[] cardLocations)
        {
            for(int i = 0; i < cardLocations.Length; i++)
            {
                cardLocations[i] = new Rectangle(500, 10, 70, 90);
            }
        }

        public void reset()
        {

        }

        public void Update(GameTime gameTime)
        {
            KeyboardState kb = Keyboard.GetState();
            if(state == GameState.play)
            {
                mainDeck.shuffleDeck();
                //if (kb.IsKeyDown(Keys.P) && !oldKB.IsKeyDown(Keys.P))
                //    state = GameState.pause;
                if(kb.IsKeyDown(Keys.Space) && !oldKB.IsKeyDown(Keys.Space))
                {
                    handState = Hand.Hit;
                    welcome = "";
                }

                if(kb.IsKeyDown(Keys.Enter) && !oldKB.IsKeyDown(Keys.Enter))
                {
                    handState = Hand.Stay;
                    hitCount++;
                }

                if(handState == Hand.Hit && hitCount < 3)
                {
                    hitCount++;
                    //Move card from mainDeck to player (face up)
                    //Maybe include half second timer to mimic real time gameplay
                    
                    Card hitCard = mainDeck.deck[0];
                    mainDeck.remove(mainDeck.deck[0]);

                    playerCards.add(hitCard);
                    

                    //Move card from mainDeck to dealer (face down)
                    Card hitCard2 = mainDeck.deck[0];
                    mainDeck.remove(mainDeck.deck[0]);

                    dealerCards.add(hitCard2);
                    handState = Hand.Nothing;

                    checkIfOver21Player(playerCards);
                    checkIfOver21Dealer(dealerCards);
                }
                if(hitCount == 3)
                {
                    //flip dealer's first card (already done in draw method)
                    //count up dealer's cards and your cards
                    //whoever has the greater value wins!

                    //Dealers Cards
                    int dealerTotal = 0;
                    for (int i = 0; i < dealerCards.deck.Length - 1; i++)
                        if(dealerCards.deck[i]!=null)
                            dealerTotal += dealerCards.deck[i].getValue();

                    //Player Cards
                    int playerTotal = 0;
                    for (int i = 0; i < playerCards.deck.Length - 1; i++)
                        if (playerCards.deck[i] != null)
                            playerTotal += playerCards.deck[i].getValue();

                    checkIfOver21Player(playerCards);
                    checkIfOver21Dealer(dealerCards);

                    if (playerTotal > dealerTotal)
                        state = GameState.won;
                    else
                        state = GameState.lost;

                }

                if(handState == Hand.Stay)
                {
                    Card hitCard2 = mainDeck.deck[0];
                    mainDeck.remove(mainDeck.deck[0]);

                    dealerCards.add(hitCard2);
                    handState = Hand.Nothing;
                }
            }
            oldKB = kb;
        }

        public void checkIfOver21Player(Deck playerCards)
        {
            int total = 0;
            for(int i = 0; i < playerCards.deck.Length-1; i++)
            {
                if (playerCards.deck[i] != null)
                    total += playerCards.deck[i].getValue();
            }
            if (total > 21)
                state = GameState.lost;
            if (total == 21)
                state = GameState.won;
        }

        public void checkIfOver21Dealer(Deck dealerCards)
        {
            int total = 0;
            for (int i = 0; i < dealerCards.deck.Length - 1; i++)
            {
                if (dealerCards.deck[i] != null)
                    total += dealerCards.deck[i].getValue();
            }
            if (total > 21)
                state = GameState.won;
            if (total == 21)
                state = GameState.lost;
        }

        public void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            switch(state)
            {
                case GameState.play:
                    spriteBatch.Draw(bjBoard, bjRect, Color.White);
                    drawMainDeck();
                    //Draw dealerCards
                    //For first dealer card, draw card back
                    drawDealerDeck();
                    //Draw playerCards
                    drawPlayerDeck();
                    break;
                case GameState.lost:
                    spriteBatch.Draw(bjBoard, bjRect, Color.White);
                    drawMainDeck();
                    //Draw dealerCards
                    //For first dealer card, draw card back
                    drawDealerDeck();
                    //Draw playerCards
                    drawPlayerDeck();
                    //print "GAME OVER"
                    spriteBatch.DrawString(font, "GAME OVER", new Vector2(200, 250), Color.Red);
                    bet = -200;
                    spriteBatch.DrawString(font, "You lost $" + Math.Abs(bet), new Vector2(140, 300), Color.Red);
                    
                    break;
                case GameState.won:
                    spriteBatch.Draw(bjBoard, bjRect, Color.White);
                    drawMainDeck();
                    //Draw dealerCards
                    //For first dealer card, draw card back
                    drawDealerDeck();
                    //Draw playerCards
                    drawPlayerDeck();
                    //print "YOU WON!!"
                    spriteBatch.DrawString(font, "YOU WON!!", new Vector2(200, 250), Color.Red);
                    bet = 200;
                    spriteBatch.DrawString(font, "You won $" + Math.Abs(bet), new Vector2(140, 300), Color.Red);
                    break;
            }
            spriteBatch.End();
        }

        public void drawMainDeck()
        {
            for(int i = 0; i < mainDeck.deck.Length-1; i++)
            {
                spriteBatch.Draw(mainDeck.backOfCards, mainDeckLocations[i], Color.White);
            }
        }

        public void drawDealerDeck()
        {
            if(hitCount>0 && hitCount < 3)
            {
                for (int i = 0; i < dealerCards.deck.Length - 1; i++)
                {
                    if (i == 0)
                        spriteBatch.Draw(mainDeck.backOfCards, dealerCardLocations[i], Color.White);
                    else
                        if (dealerCards.deck[i] != null && i < 3)
                        spriteBatch.Draw(dealerCards.deck[i].getImage(), dealerCardLocations[i], Color.White);
                }
            }
            if(hitCount >= 3)
            {
                for (int i = 0; i < dealerCards.deck.Length - 1; i++)
                {
                    if (dealerCards.deck[i] != null && i < 3)
                        spriteBatch.Draw(dealerCards.deck[i].getImage(), dealerCardLocations[i], Color.White);
                }
            }
        }

        public void drawPlayerDeck()
        {
            if (hitCount > 0)
            {
                for (int i = 0; i < playerCards.deck.Length - 1; i++)
                {
                    if(playerCards.deck[i] != null)
                        spriteBatch.Draw(playerCards.deck[i].getImage(), playerCardLocations[i], Color.White);
                }
            }
        }
    }
}
