﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace CasinoTycoon_v1._1
{
    class Player
    {
        // Sprite Sheet Dimensions -> Width: 96 : Height: 128

        // Src rectangles
        Rectangle[] locs;
        int current;
        // Main Rectangle
        public Vector2 position;
        // Texture
        public Texture2D spriteSheet;

        Animation playerAnimation;
        Vector2 tempCurrentFrame;
        KeyboardState kb;
        GamePadState gp;
        float moveSpeed;

        int screenWidth;
        int screenHeight;

        public int width;
        public int height;

        public Player(int sW, int sH) {
            width = height = 50;
            position = new Vector2(100, 100);
            screenWidth = sW;
            screenHeight = sH;
            //current = 1;
            //locs = new Rectangle[] {new Rectangle(0, 0, 32, 32), new Rectangle(32, 0, 32, 32), new Rectangle(64, 0, 32, 32),
            //                        new Rectangle(0, 32, 32, 32), new Rectangle(32, 32, 32, 32), new Rectangle(64, 32, 32, 32),
            //                        new Rectangle(0, 64, 32, 32), new Rectangle(32, 64, 32, 32), new Rectangle(64, 64, 32, 32),
            //                        new Rectangle(0, 96, 32, 32), new Rectangle(32, 96, 32, 32), new Rectangle(64, 96, 32, 32)};

            playerAnimation = new Animation(position, new Vector2(3, 4), width, height);        
            tempCurrentFrame = Vector2.Zero;
            moveSpeed = 100f;
        }

        public void loadContent(ContentManager Content)
        {
            spriteSheet = Content.Load<Texture2D>("Player/playerMale");
            playerAnimation.AnimationImage = spriteSheet;
        }

        public void Update(GameTime gameTime)
        {
            kb = Keyboard.GetState();
            gp = GamePad.GetState(PlayerIndex.One);
            playerAnimation.Active = true;

            position = playerAnimation.Position;

            if ((kb.IsKeyDown(Keys.Down) || gp.ThumbSticks.Left.Y < 0 || kb.IsKeyDown(Keys.S)) && position.Y + height < screenHeight)
            {
                position.Y += moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                tempCurrentFrame.Y = 0;
            }
            else if ((kb.IsKeyDown(Keys.Up) || gp.ThumbSticks.Left.Y > 0 || kb.IsKeyDown(Keys.W)) && position.Y > 0)
            {
                position.Y -= moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                tempCurrentFrame.Y = 3;
            }
            else if ((kb.IsKeyDown(Keys.Right) || gp.ThumbSticks.Left.X > 0 || kb.IsKeyDown(Keys.D)) && position.X + width < screenWidth)
            {
                position.X += moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                tempCurrentFrame.Y = 2;
            }
            else if ((kb.IsKeyDown(Keys.Left) || gp.ThumbSticks.Left.X < 0 || kb.IsKeyDown(Keys.A)) && position.Y + height < screenHeight)
            {
                position.X-= moveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                tempCurrentFrame.Y = 1;
            }
            else
            {
                playerAnimation.Active = false;
            }
            tempCurrentFrame.X = playerAnimation.CurrentFrame.X;


            playerAnimation.Position = position;
            playerAnimation.CurrentFrame = tempCurrentFrame;

            playerAnimation.Update(gameTime);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            playerAnimation.Draw(spriteBatch);
        }

        public Vector2 Origin
        {
            get { return new Vector2(position.X + width / 2, position.Y + width / 2); }
        }
    }
}
